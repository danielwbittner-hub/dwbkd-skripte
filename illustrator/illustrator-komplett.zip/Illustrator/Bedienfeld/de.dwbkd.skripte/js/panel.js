/**
 * panel.js – Oberflaeche des dwbkd-Skripte-Panels.
 *
 * Spricht ueber die von CEP eingehaengte Bruecke window.__adobe_cep__ mit
 * Illustrator. Bewusst ohne CSInterface.js: gebraucht werden nur evalScript()
 * und die Theme-Info, alles Weitere erledigt jsx/host.jsx.
 */
(function () {
  'use strict';

  /**
   * Ausserhalb von Illustrator (z. B. Layoutkontrolle im Browser) fehlt die
   * CEP-Bruecke. Dann laeuft das Panel mit Beispieldaten weiter, statt zu
   * zerlegen – im Panel selbst greift dieser Zweig nie.
   */
  var cep = window.__adobe_cep__ || {
    evalScript: function (code, cb) {
      if (code.indexOf('list') === 0 || code.indexOf('dwbkd.list') === 0) {
        cb('OK|Aus Fläche ausschneiden\tdemo1\nDarunterliegende aufteilen\tdemo2\n' +
           'Duplizieren und versetzt einfügen\tdemo3\nFlächen vereinen\tdemo4\nSiebdruckraster\tdemo5');
      } else {
        cb('ERR|Vorschau ohne Illustrator – hier passiert nichts.');
      }
    },
    getHostEnvironment: function () { throw new Error('kein CEP'); },
    addEventListener: function () {}
  };

  var DEFAULT_FOLDER = '/Users/danielbittner/Nextcloud/BDG Austausch/Scripte/Illustrator';
  var STORE_KEY = 'dwbkd.skriptordner';

  var elList = document.getElementById('list');
  var elStatus = document.getElementById('status');
  var elFolder = document.getElementById('folder');

  var scripts = [];
  var folder = localStorage.getItem(STORE_KEY) || DEFAULT_FOLDER;

  /* ---------------------------------------------------------------- Bruecke */

  /** host.jsx aufrufen; Argumente werden URI-kodiert durchgereicht. */
  function callHost(fn, arg) {
    var code = 'dwbkd.' + fn + '(' +
      (arg === undefined ? '' : JSON.stringify(encodeURIComponent(arg))) + ')';
    return new Promise(function (resolve) {
      cep.evalScript(code, resolve);
    });
  }

  /** "OK|Nutzlast" aufteilen. Antwortet Illustrator gar nicht, ist es ein Fehler. */
  function split(res) {
    if (!res || res === 'EvalScript error.') {
      return { status: 'ERR', body: 'Illustrator hat nicht geantwortet.\nPanel neu öffnen?' };
    }
    var i = res.indexOf('|');
    return i < 0
      ? { status: 'ERR', body: res }
      : { status: res.slice(0, i), body: res.slice(i + 1) };
  }

  /* ----------------------------------------------------------------- Status */

  var statusTimer = null;

  function setStatus(text, kind) {
    clearTimeout(statusTimer);
    elStatus.textContent = text || '';
    elStatus.className = kind || '';
    if (kind === 'ok') {
      statusTimer = setTimeout(function () {
        elStatus.textContent = '';
        elStatus.className = '';
      }, 2500);
    }
  }

  /* ------------------------------------------------------------------ Liste */

  function render() {
    elList.innerHTML = '';
    // Fussleiste kuerzt den Pfad vorne (direction: rtl); das LRM haelt den
    // fuehrenden Schraegstrich davon ab, ans Ende zu rutschen.
    elFolder.textContent = '‎' + folder;
    elFolder.title = folder;

    if (!scripts.length) {
      var empty = document.createElement('div');
      empty.className = 'empty';
      empty.textContent = 'Keine .jsx-Datei in diesem Ordner.\n\nÜber 📁 einen anderen Ordner wählen.';
      elList.appendChild(empty);
      return;
    }

    scripts.forEach(function (s, i) {
      var btn = document.createElement('button');
      btn.className = 'script';
      btn.title = decodeURIComponent(s.path);

      var num = document.createElement('span');
      num.className = 'num';
      num.textContent = i < 9 ? (i + 1) : '';

      var label = document.createElement('span');
      label.className = 'label';
      label.textContent = s.name;

      btn.appendChild(num);
      btn.appendChild(label);
      btn.addEventListener('click', function () { run(s); });
      elList.appendChild(btn);
    });
  }

  function load() {
    setStatus('Lese Ordner …');
    return callHost('list', folder).then(function (res) {
      var r = split(res);
      if (r.status !== 'OK') {
        scripts = [];
        render();
        setStatus(r.body, 'err');
        return;
      }
      scripts = r.body ? r.body.split('\n').map(function (line) {
        var parts = line.split('\t');
        return { name: parts[0], path: parts[1] };
      }) : [];
      render();
      setStatus(scripts.length === 1 ? '1 Skript' : scripts.length + ' Skripte');
    });
  }

  /* ---------------------------------------------------------------- Aktionen */

  function run(s) {
    setStatus('▸ ' + s.name);
    callHost('run', decodeURIComponent(s.path)).then(function (res) {
      var r = split(res);
      if (r.status === 'OK') setStatus(s.name + ' ✓', 'ok');
      else setStatus(r.body, 'err');
    });
  }

  function chooseFolder() {
    callHost('choose', folder).then(function (res) {
      var r = split(res);
      if (r.status !== 'OK') return;
      folder = decodeURIComponent(r.body);
      localStorage.setItem(STORE_KEY, folder);
      load();
    });
  }

  /* ------------------------------------------------------------------ Theme */

  /** Panel an Illustrators Helligkeitsstufe angleichen (Menü: Voreinstellungen ▸ Benutzeroberfläche). */
  function applyTheme() {
    try {
      var skin = JSON.parse(cep.getHostEnvironment()).appSkinInfo;
      var c = skin.panelBackgroundColor.color;
      var r = Math.round(c.red), g = Math.round(c.green), b = Math.round(c.blue);
      var light = (0.299 * r + 0.587 * g + 0.114 * b) > 128;
      var css = document.documentElement.style;

      css.setProperty('--bg', 'rgb(' + r + ',' + g + ',' + b + ')');
      css.setProperty('--bg-btn', light ? 'rgba(0,0,0,.06)' : 'rgba(255,255,255,.07)');
      css.setProperty('--bg-btn-hover', light ? 'rgba(0,0,0,.12)' : 'rgba(255,255,255,.13)');
      css.setProperty('--line', light ? 'rgba(0,0,0,.15)' : 'rgba(0,0,0,.35)');
      css.setProperty('--fg', light ? '#1f1f1f' : '#d8d8d8');
      css.setProperty('--fg-dim', light ? '#6b6b6b' : '#8a8a8a');
    } catch (e) { /* Standard-Dunkeldesign behalten */ }
  }

  /* -------------------------------------------------------------- Verdrahtung */

  document.getElementById('btn-reload').addEventListener('click', load);
  document.getElementById('btn-folder').addEventListener('click', chooseFolder);

  // Zifferntasten 1–9 starten das entsprechende Skript.
  document.addEventListener('keydown', function (e) {
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    var n = parseInt(e.key, 10);
    if (n >= 1 && n <= 9 && scripts[n - 1]) run(scripts[n - 1]);
  });

  /* -------------------------------------------------------- Neuzeichnen */

  /**
   * Illustrator vergisst unter macOS regelmaessig, die Panel-Flaeche zu
   * zeichnen (grauer Rahmen trotz fertigem DOM). Ein erzwungener Reflow
   * holt das nach – der einzige Weg, der laut Adobe-Forum verlaesslich hilft.
   */
  function forceRedraw() {
    var body = document.body;
    body.style.display = 'none';
    void body.offsetHeight;
    body.style.display = '';
  }

  window.addEventListener('resize', forceRedraw);
  setTimeout(forceRedraw, 300);
  setTimeout(forceRedraw, 1200);

  applyTheme();
  try {
    cep.addEventListener('com.adobe.csxs.events.ThemeColorChanged', applyTheme);
    cep.addEventListener('com.adobe.csxs.events.WindowVisibilityChanged', function () {
      setTimeout(forceRedraw, 60);
    });
  } catch (e) {}

  load();
})();
