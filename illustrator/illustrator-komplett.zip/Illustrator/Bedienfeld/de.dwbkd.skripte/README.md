# dwbkd Skripte – Illustrator-Bedienfeld

Ein CEP-Bedienfeld für Adobe Illustrator, das die `.jsx`-Skripte eines Ordners
als Schaltflächen anzeigt und unverändert ausführt.

Aufruf in Illustrator: **Fenster ▸ Erweiterungen ▸ dwbkd Skripte**

## Warum CEP und nicht UXP

UXP ist für Illustrator bis heute nicht für Dritte freigegeben (Adobe nutzt es
dort nur intern), und UXP stellt bewusst kein `evalScript` bereit – ein
UXP-Plug-in könnte bestehende `.jsx` also gar nicht aufrufen. CEP kann genau
das und ist in Illustrator 2026 (30.7) vorhanden. CEP 12 ist allerdings
Adobes letzte große CEP-Version; fällt es künftig weg, bleiben die Skripte
über **Datei ▸ Skripten** erreichbar (Symlinks im Presets-Ordner).

## Aufbau

| Datei | Aufgabe |
|---|---|
| `CSXS/manifest.xml` | Registrierung als Panel, Host `ILST` |
| `index.html` | Oberfläche und Styling |
| `js/panel.js` | Liste, Klicks, Theme; spricht über `__adobe_cep__.evalScript` |
| `jsx/host.jsx` | Ordner lesen und Skript per `$.evalFile()` starten |
| `.debug` | Remote-Debugging auf Port 8088 |

Bewusst **ohne** `CSInterface.js`: gebraucht werden nur `evalScript()` und die
Theme-Info. Sämtliche Dateizugriffe laufen über ExtendScript, deshalb braucht
das Panel weder Node noch die CEP-Dateisystem-API.

## Installation (bereits erledigt)

```
~/Library/Application Support/Adobe/CEP/extensions/de.dwbkd.skripte
  -> /Users/danielbittner/Claude Code/Illustrator-Panel/de.dwbkd.skripte
```

Unsignierte Erweiterungen müssen erlaubt sein:

```bash
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
```

Rückgängig: `defaults delete com.adobe.CSXS.12 PlayerDebugMode`

## Bedienung

* Klick auf eine Schaltfläche startet das Skript (samt seiner ScriptUI-Dialoge).
* Tasten **1–9** starten das jeweilige Skript, solange das Panel den Fokus hat.
* **⟳** liest den Ordner neu ein, **📁** wechselt den Ordner (wird gemerkt).
* Standardordner: `~/Nextcloud/BDG Austausch/Scripte/Illustrator`

Neue Skripte brauchen keine Registrierung – Datei in den Ordner legen, ⟳ drücken.

## Anzeigenamen

Steht in den ersten Zeilen eines Skripts eine Zeile `Anzeigename: Mein Titel`
(im Kommentar), wird dieser Titel angezeigt, sonst der Dateiname ohne Endung:

```js
// Anzeigename: Flächen vereinen
```

Achtung: kein `@wort`-Marker (z. B. `@name`) — ExtendScript wertet das in
`//`-Kommentaren als Präprozessor-Direktive und bricht beim Ausführen der
Datei mit „Error 8: Syntaxfehler, Zeile 1" ab.

## Debugging

Panel öffnen, in Chrome `http://localhost:8088` aufrufen – dort liegen Konsole
und Elementinspektor. Fehler aus ExtendScript erscheinen zusätzlich rot in der
Fußzeile des Panels.
