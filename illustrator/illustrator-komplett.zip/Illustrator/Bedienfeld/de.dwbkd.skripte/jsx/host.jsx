/**
 * host.jsx – ExtendScript-Seite des dwbkd-Skripte-Panels.
 *
 * Wird von CEP beim Laden des Panels in Illustrators Script-Engine gezogen
 * (siehe <ScriptPath> im manifest.xml). Alle Dateizugriffe passieren hier,
 * damit das Panel selbst ohne Node/CEP-Dateisystem auskommt.
 *
 * Rueckgabewerte sind immer "STATUS|Nutzlast", Pfade sind URI-kodiert –
 * so ueberleben Leerzeichen und Umlaute den Weg durch evalScript().
 */
var dwbkd = (function () {

    /** Umlaute fuer die Sortierung falten, damit "Ä" bei "A" einsortiert wird. */
    function foldForSort(s) {
        return s.toLowerCase()
                .replace(/ä/g, 'a').replace(/ö/g, 'o').replace(/ü/g, 'u')
                .replace(/ß/g, 'ss');
    }

    /**
     * Anzeigename eines Skripts: entweder eine Zeile "Anzeigename: Mein Titel"
     * im Dateikopf oder – falls nicht vorhanden – der Dateiname ohne Endung.
     * (Kein "@wort"-Marker: das wertet ExtendScript als Direktive und wirft
     * beim Ausfuehren der Datei einen Syntaxfehler.)
     */
    function displayName(file) {
        var name = decodeURI(file.name).replace(/\.jsx$/i, '');
        try {
            if (file.open('r')) {
                var head = file.read(600);
                file.close();
                var m = head.match(/Anzeigename:[ \t]*([^\r\n\*]+)/);
                if (m) name = m[1].replace(/[\s]+$/, '');
            }
        } catch (e) { /* Kopf nicht lesbar – Dateiname genuegt */ }
        return name;
    }

    return {

        /** Alle .jsx eines Ordners auflisten – je Zeile "Anzeigename\tPfad". */
        list: function (encodedFolder) {
            var path = decodeURIComponent(encodedFolder);
            var folder = new Folder(path);
            if (!folder.exists) return 'ERR|Ordner nicht gefunden:\n' + path;

            var files = folder.getFiles(function (f) {
                return (f instanceof File) && /\.jsx$/i.test(f.name);
            });

            var rows = [];
            for (var i = 0; i < files.length; i++) {
                rows.push({ name: displayName(files[i]), path: files[i].fsName });
            }
            rows.sort(function (a, b) {
                var x = foldForSort(a.name), y = foldForSort(b.name);
                return x < y ? -1 : (x > y ? 1 : 0);
            });

            var out = [];
            for (var j = 0; j < rows.length; j++) {
                out.push(rows[j].name + '\t' + encodeURIComponent(rows[j].path));
            }
            return 'OK|' + out.join('\n');
        },

        /** Ein Skript ausfuehren – unveraendert, inklusive seiner ScriptUI-Dialoge. */
        run: function (encodedFile) {
            var file = new File(decodeURIComponent(encodedFile));
            if (!file.exists) return 'ERR|Datei existiert nicht mehr:\n' + file.fsName;
            try {
                $.evalFile(file);
                return 'OK|';
            } catch (e) {
                return 'ERR|' + e.message + (e.line ? '  (Zeile ' + e.line + ')' : '');
            }
        },

        /** Ordnerauswahl ueber Illustrators eigenen Dialog. */
        choose: function (encodedStart) {
            var start = null;
            try {
                var f = new Folder(decodeURIComponent(encodedStart));
                if (f.exists) start = f;
            } catch (e) {}
            var picked = (start ? start : Folder.myDocuments)
                            .selectDlg('Ordner mit deinen Illustrator-Skripten waehlen');
            return picked ? 'OK|' + encodeURIComponent(picked.fsName) : 'CANCEL|';
        }
    };
})();
