#target illustrator
#targetengine "main"

// Anzeigename: Skriptleiste (Palette)
//
// ACHTUNG Konvention: KEIN "@wort" in //-Kommentaren verwenden! ExtendScript
// wertet das als Praeprozessor-Direktive aus und bricht mit "Error 8:
// Syntaxfehler, Zeile 1" ab. Darum heisst der Titel-Marker "Anzeigename:".
//
// Schwebende Skript-Startleiste OHNE CEP – Ersatz fuer das CEP-Bedienfeld,
// solange Illustrator 2026 CEP-Panels auf macOS nicht zeichnet (bekannter
// Adobe-Bug, CEP-Resources #553: Inhalt wird komponiert, aber nie angezeigt).
//
// Start: Datei > Skripten (Symlink) oder "Anderes Skript..." (Cmd+F12).
// Liest alle .jsx dieses Ordners (ausser _*-Dateien) und zeigt je Skript
// einen Knopf. Klick startet das Skript per BridgeTalk-Nachricht an
// Illustrator selbst – der einzige Weg, auf dem Paletten-Klicks vollen
// Zugriff aufs Dokument behalten (direkte onClick-Handler verlieren in
// Illustrator die DOM-Verbindung, "no document").
// Die #targetengine-"main"-Direktive oben ist Pflicht: ohne sie laeuft das
// Skript in einer Wegwerf-Engine und die Palette schliesst sich sofort beim
// Skriptende wieder. Mit ihr ueberlebt das Fenster dank der globalen
// Referenz am Schluss bis zum Illustrator-Neustart.

(function () {
    var FOLDER = new Folder('~/Nextcloud/BDG Austausch/Scripte/Illustrator');
    var SELF = new File($.fileName);

    /** Umlaute fuer die Sortierung falten, damit "Ä" bei "A" landet. */
    function foldSort(s) {
        return s.toLowerCase()
                .replace(/ä/g, 'a').replace(/ö/g, 'o').replace(/ü/g, 'u')
                .replace(/ß/g, 'ss');
    }

    /** Anzeigename: Zeile "Anzeigename: Mein Titel" im Dateikopf, sonst Dateiname. */
    function displayName(file) {
        var name = decodeURI(file.name).replace(/\.jsx$/i, '');
        try {
            if (file.open('r')) {
                var head = file.read(600);
                file.close();
                var m = head.match(/Anzeigename:[ \t]*([^\r\n\*]+)/);
                if (m) name = m[1].replace(/[\s]+$/, '');
            }
        } catch (e) { /* Kopf nicht lesbar - Dateiname genuegt */ }
        return name;
    }

    /**
     * Skript ueber BridgeTalk an Illustrator selbst schicken. Laeuft dadurch
     * im normalen Skript-Kontext (wie ueber Datei > Skripten), inklusive
     * eigener ScriptUI-Dialoge des Skripts.
     */
    function runViaBridgeTalk(file) {
        var bt = new BridgeTalk();
        bt.target = BridgeTalk.appSpecifier;
        bt.body = "$.evalFile(new File('" + file.absoluteURI + "'))";
        bt.onError = function (m) { alert('Skript-Fehler:\n' + m.body); };
        bt.send();
    }

    function makeHandler(file) {
        return function () { runViaBridgeTalk(file); };
    }

    // Bei erneutem Start eine schon offene Leiste schliessen.
    try { if ($.global.__dwbkdLeiste) $.global.__dwbkdLeiste.close(); } catch (e) {}

    var files = FOLDER.getFiles(function (f) {
        return (f instanceof File) && /\.jsx$/i.test(f.name) && !/^_/.test(f.name);
    });

    var rows = [], i;
    for (i = 0; i < files.length; i++) {
        rows.push({ name: displayName(files[i]), file: files[i] });
    }
    rows.sort(function (a, b) {
        var x = foldSort(a.name), y = foldSort(b.name);
        return x < y ? -1 : (x > y ? 1 : 0);
    });

    var win = new Window('palette', 'dwbkd Skripte', undefined);
    win.orientation = 'column';
    win.alignChildren = ['fill', 'top'];
    win.spacing = 4;
    win.margins = 10;

    if (!rows.length) {
        win.add('statictext', undefined,
            'Keine Skripte gefunden in:\n' + FOLDER.fsName, { multiline: true });
    }
    for (i = 0; i < rows.length; i++) {
        var btn = win.add('button', undefined, rows[i].name);
        btn.onClick = makeHandler(rows[i].file);
    }

    win.add('panel', undefined, '');
    var reload = win.add('button', undefined, 'Neu einlesen');
    reload.onClick = function () { win.close(); $.evalFile(SELF); };

    // Globale Referenz haelt die Palette am Leben (sonst raeumt der
    // Garbage Collector das Fenster nach Skriptende sofort wieder ab).
    $.global.__dwbkdLeiste = win;
    win.show();
})();
