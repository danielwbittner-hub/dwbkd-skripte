# Werkzeuge — sechs Alltagshelfer fürs Skriptbedienfeld

Alle sechs sind klassische JSX-Skripte: Doppelklick unter
**Fenster ▸ Hilfsprogramme ▸ Skripte ▸ Benutzer** (der Installer im
Elternordner verknüpft sie dort). Unter **Bearbeiten ▸ Tastaturbefehle ▸
Produktbereich „Skripte“** lässt sich jedem ein Kürzel geben.

---

## Typo-Putz.jsx

Typografische Reinigung für deutsche Texte. Jede Regel ist einzeln abwählbar,
gearbeitet wird im ganzen Dokument (samt Musterseiten und Fußnoten) oder nur
im Textabschnitt der Auswahl. Alles zusammen ist **ein Rückgängig-Schritt**;
am Ende steht, welche Regel wie oft gegriffen hat.

* Apostroph im Wort: `geht's` → `geht’s`
* `"…"` → `„…“` und `'…'` → `‚…‘`
* Drei Punkte → Auslassungszeichen (…)
* Mehrfache Leerzeichen → eines · Leerzeichen vor Satzzeichen weg ·
  Leerzeichen am Absatzende weg
* ` - ` → ` – ` (Halbgeviertstrich)
* Bis-Strich zwischen Zahlen (`3-4` → `3–4`) — **ab Werk aus**, weil
  Telefonnummern und Datumsangaben mitgetroffen würden
* Schmales geschütztes Leerzeichen (U+202F) vor %, €, mm, cm, kg, Uhr …

## Aufraeumen.jsx

Macht ein Dokument übergabefertig: findet unbenutzte Absatz- und
Zeichenformate, unbenutzte Farbfelder und leere Ebenen — zeigt **erst den
Bericht** und löscht dann auf Wunsch (ein Rückgängig-Schritt). Geschützt
bleibt alles, was gebraucht wird: angewendete Formate (auch auf Musterseiten,
in Fußnoten und auf versteckten Ebenen), Grundlagen/Folgeformate bleibender
Formate, Verweise aus Objekt-/Zellenformaten, die eingebauten Felder und
Ebenen mit Hilfslinien (werden nur gemeldet). Objektformate prüft das Script
nicht — sie bleiben unangetastet.

## Version-sichern.jsx

Sichert das Dokument und legt eine datierte Kopie in den Unterordner
**„Versionen“** neben der Dokumentdatei (`Name_2026-09-01.indd`, bei Bedarf
numeriert). Überschrieben oder gelöscht wird nie etwas.

## Neues-Dokument.jsx

Neues Dokument aus einer Vorlage: Visitenkarte 85 × 55, Flyer DIN lang / A5,
Bogen A4, Broschüre A4, Plakat A3/A2/A1 oder frei — mit Anschnitt, Rändern,
Seitenzahl, auf Wunsch Doppelseiten, dazu ein Farbfeld **Reichschwarz**
(40/30/30/100) und zwei schlichte Absatzformate (Grundtext, Überschrift).
Eigene Vorlagen: einfach die Tabelle `VORLAGEN` oben im Script ergänzen
(alle Maße in Millimetern).

## Kontaktabzug.jsx

Alle Seiten des Dokuments als Miniaturen-Übersicht (A4 quer, Spaltenzahl
wählbar, wahlweise mit Seitenname) als PDF **neben der Dokumentdatei** —
praktisch für Freigaben per Mail. Technischer Weg: ein offenes INDD lässt
sich nicht selbst platzieren, deshalb exportiert das Script erst ein
unsichtbares Zwischen-PDF, platziert dessen Seiten ins Raster und wirft
Zwischen-PDF und Rasterdokument danach wieder weg. Das eigene Dokument
bleibt unangetastet, InDesigns PDF-Platziervorgaben (Seite, Zuschnitt,
transparenter Hintergrund) werden seit 1.1 wieder zurückgestellt.

## Bilder-in-Rahmen.jsx

Füllt einen Bildrahmen der Reihe nach mit Bildern — **eine Seite je Bild**.
Rahmen auf einer Seite auswählen (Auswahl- oder Direktauswahl-Werkzeug),
Script starten, im Dateidialog beliebig viele Bilder, PDFs oder AI-Dateien
wählen (weitere Dateien oder ganze Ordner kommen in der Übersicht dazu).
Bei 6 Bildern kommen 5 neue Seiten direkt dahinter — oder ans Dokumentende,
oder vorhandene Folgeseiten werden befüllt. Alles von der Originalseite wird
exakt an dieselbe Stelle kopiert (auch Flächen, die über die Seitenkante auf
die Montagefläche ragen, gesperrte Ebenen, Hilfslinien, Musterseite,
Seitenformat) und jeder Rahmen bekommt ein Bild.

Vor dem Platzieren zeigt eine **Übersicht**:

* **Vorschaubilder** aller Motive im Raster — anklicken wählt aus,
  **ziehen sortiert um**. Auf dem Mac liefert ein kleines Hilfsprogramm
  (JXA, in jedem macOS enthalten) die Vorschau für JPEG, TIFF, PSD, PNG, HEIC
  mit richtiger **EXIF-Drehung** (Handyfotos) und für PDF/AI-Seiten samt
  gedrehter Seiten; zwischengespeichert, beim nächsten Mal sofort da.
  Nicht lesbare Dateien werden **rot mit „!“** markiert, EPS/INDD zeigen
  ihre Endung. Jede Kachel zeigt den **Ausschnitt**: was der Rahmen
  abschneidet, ist abgedunkelt.
* Liste Seite → Bild → **ppi** mit ▲ / ▼, **Entfernen**, **Dateien …** und
  **Ordner …**. Die ppi-Spalte zeigt die **effektive Auflösung** bei der
  gewählten Einpassung, unter 250 ppi mit ⚠.
* **Ordner …** liest alle Bilder eines Ordners ein — versteckte Dateien,
  Programmpakete und `__MACOSX` bleiben außen vor. Hat der Ordner
  Unterordner, fragt das Script, ob sie mit sollen; die Liste zeigt dann
  „Unterordner/Datei“ und sortiert „Ordner, dann Dateiname“. Ab 300 Bildern
  fragt es nach. Auf dem Mac liest `find` den Ordner (tausende Dateien in
  Sekunden statt über einer Minute).
* **Doppelte Bilder:** inhaltsgleiche Dateien (auch unter anderem Namen)
  bekommen in der Liste ein „=“ und in der Vorschau eine orange Marke mit der
  Seite des ersten; Bilder, die schon im Dokument platziert sind, ein „●“
  und eine grüne Marke („im Dok.“, nur Name und Größe gleich: „im Dok.?“).
  Markieren nennt unten, wo das Gegenstück steht. **Doppelte entfernen**
  nimmt die Wiederholungen aus der Liste, auf Wunsch auch schon platzierte —
  das Dokument bleibt unberührt. Verglichen wird auf dem Mac per Prüfsumme,
  nur bei gleicher Dateigröße; bei sehr großen Mengen (über 2 GB) erst auf
  Knopfdruck („Doppelte suchen“). Unter Windows zählen gleiche Pfade und
  schon platzierte Dateien.
* **PDF-Seiten** (auch mehrseitige AI, INDD ohne Seitenzahl): Eintrag wählen —
  das Feld zeigt, welche Seiten der Datei gerade in der Liste stehen (zuerst
  „1“) —, „1-3, 7“ oder „alle“ eintippen, **Aufteilen**: jede Seite wird ein
  eigener Eintrag mit eigener Vorschau und eigener Dokumentseite, als
  geschlossener Block an der Stelle des Eintrags. Das Feld steht immer für
  den **ganzen Bestand** dieser Datei: aus „1-6“ „1-4, 6“ machen nimmt
  Seite 5 heraus, „6-4“ dreht die Reihenfolge (Sortierung springt auf „Von
  Hand“). Die Eingabetaste im Feld teilt auf; eine getippte, nicht
  aufgeteilte Seitenwahl und mehrseitige PDFs, von denen nur Seite 1 käme,
  fragt „Platzieren“ noch einmal nach.
* **Sortieren** nach Dateiname mit richtigen Zahlen (Bild_2 vor Bild_10),
  rückwärts, nach Änderungsdatum oder „Ordner, dann Dateiname“ — Seiten eines
  PDFs bleiben dabei aufsteigend zusammen; jede Handänderung stellt auf
  „Von Hand“.
* **Einpassung** für alle Bilder: ab Werk in der Höhe passend skaliert (was
  seitlich übersteht, schneidet der Rahmen ab); wahlweise „Rahmen füllen“
  oder „Ganz einpassen“.
* **Ausrichtung je Bild** über den 3×3-Bezugspunkt neben der Einpassung:
  Klick setzt sie für das markierte Bild, ⌥-Klick oder **Für alle** für alle
  (gilt dann auch für neu hinzugefügte). Die Liste zeigt die Richtung als
  Pfeil, die Kachel den Ausschnitt. Ausgerichtet wird nach dem, was man
  sieht — auch in gedrehten und gespiegelten Rahmen.
* **Neue Seiten:** direkt dahinter · am Dokumentende · leere Folgeseiten
  befüllen · Folgeseiten ersetzen. Zum Befüllen sucht das Script auf den
  Folgeseiten einen Rahmen an derselben Stelle (auf Gegenseiten gespiegelt,
  auch Musterrahmen); belegte, gesperrte oder mehrdeutige Rahmen werden
  übersprungen (beim Ersetzen zählen belegte mit), was übrig bleibt, kommt
  als neue Seiten ans Dokumentende. Die Infozeile nennt die Zielseiten.
  „Direkt dahinter“ mit ungerader Seitenzahl bei Doppelseiten fragt vorher
  nach, weil die Seiten dahinter links und rechts tauschen.
* **Texte aus den Metadaten:** Liegen auf der Seite oder ihrer Musterseite
  Textrahmen namens **Titel**, **Stadt**, **Copyright** und
  **Bildunterschrift** (auch „Bilderunterschrift“, „Caption“, „Ort“ …),
  liest das Script die passenden Angaben aus den Bildern und zeigt sie unter
  der Vorschau zum Ändern — je Bild, mit „alle“ für alle Bilder. Titel,
  Bildunterschrift (Beschreibung) und Stadt kommen aus den gleichnamigen
  Feldern von Lightroom/Photoshop; das Feld **Copyright** zeigt den **Autor**
  aus IPTC „Ersteller“ (mehrere Ersteller mit Komma). Den Copyright-Vermerk
  der Datei übernimmt es nicht: Fehlt der Ersteller, bleibt das Feld leer,
  die Kurzinfo am Feld nennt dann den Vermerk der Datei, und die Infozeile
  zählt die Bilder „ohne Autor“. Änderungen gelten **nur fürs Layout, die
  Bilddateien bleiben unverändert**. Je Seite wird ein Musterrahmen nur
  gelöst, wenn er dort einen Text bekommt; Übersatz und doppelt vergebene
  Rahmennamen auf einer Seite meldet der Bericht.
* **Präfix vor dem Autor:** Vor dem Autorfeld steht ein kleines Feld mit der
  Vorgabe „Foto: “ (mit Leerzeichen am Ende). In den Copyright-Rahmen kommt
  Präfix + Autor, also „Foto: Daniel Bittner“. Das Präfix gilt für alle
  Bilder, lässt sich frei ändern („Bild: “, „© “ oder leer) und wird gemerkt;
  beim Tippen zeigt die Statuszeile, was im Rahmen stehen wird. Ergänzt wird
  nichts — ohne das Leerzeichen steht dort „Foto:Daniel Bittner“. Ohne Autor
  bleibt der Rahmen leer (nie ein einsames „Foto: “); beginnt der Autor schon
  mit dem Präfix, kommt es nicht doppelt.
* **Gleiche Texte auf die Musterseite** (Schalter unter den Texten, ab Werk
  an, gemerkt): Ist ein Text bei allen Bildern gleich — typischerweise
  Copyright, Stadt und Bildunterschrift einer Serie —, kommt er **einmal in
  den Rahmen der Musterseite** statt auf jede einzelne Seite. Schrift, Größe
  und Lage passt man dann nur noch auf der Musterseite an, alle Seiten
  folgen. Texte, die sich unterscheiden (meist der Titel), kommen wie bisher
  auf die einzelnen Seiten; bei nur einem Bild ebenso. Die Zeile neben dem
  Schalter zeigt, welche Felder auf die Musterseite gehen und ob die
  Musterseite auch andere Seiten des Dokuments betrifft. Zeigen Seiten
  außerhalb der Bildstrecke denselben Musterrahmen oder steht darin ein
  Platzhalter, fragt „Platzieren“ nach: **Überschreiben** schreibt auf die
  Musterseite (die anderen Seiten zeigen den Text dann mit), **Stehen
  lassen** lässt einen Platzhalter stehen; zeigen nur andere Seiten den
  Rahmen, kommen die Texte dieser Bildstrecke auf die einzelnen Seiten.
  Rahmen, die ein früherer Lauf auf den Seiten gelöst hat, setzt das Script
  zur Musterseite zurück — ein gelöster Rahmen folgt der Musterseite nicht
  mehr, auch nicht bei Schrift oder Größe. Rahmen, die du auf einer Seite von
  Hand verschoben, umformatiert oder geleert hast, bleiben gelöst und
  bekommen ihren Text dort; auch bei ausgeblendeten Musterobjekten bleibt
  alles auf der Seite. Der Bericht nennt zurückgesetzte und gelöst
  gebliebene Rahmen.
* **Doppelseiten: Gegenseiten spiegeln** (ab Werk an, nur bei Doppelseiten
  wählbar) — siehe unten.

Beim Platzieren:

* **Doppelseiten:** Wechselt eine neue Seite die Lage (links ↔ rechts), wird
  die Lage **aller** Objekte und senkrechten Hilfslinien an der Seitenmitte
  gespiegelt — ein Anschnitt bleibt außen, Text innen bleibt innen, nichts
  überdeckt sich. Gespiegelt wird nur die Lage, nicht die Form (Text und
  Bilder stehen nie seitenverkehrt); Gruppen wandern als Ganzes. Wer das
  nicht will, nimmt den Haken „Gegenseiten spiegeln“ heraus.
* **Tastenkürzel** (H oder „?“ blendet sie in der Vorschau ein):
  1–9 Ausrichtung des markierten Bilds (1 2 3 = oben, 7 8 9 = unten),
  ⌥ + Ziffer für alle, 0 überträgt auf alle · ⌘↑ / ⌘↓ verschieben, mit ⇧
  ganz nach vorn/hinten · ⌫ entfernen · E Einpassung wechseln · ⌘O Dateien,
  ⇧⌘O Ordner · ⇧⌘D Doppelte entfernen · ⌘J Feld „PDF-Seiten“. In Textfeldern
  bleiben Ziffern und Buchstaben normale Eingabe. Nach einer Datei- oder
  Ordnerwahl einmal in die Liste klicken — macOS gibt den Tastaturfokus
  danach nicht an die Übersicht zurück. Unter Windows Strg statt ⌘.
* **Musterseiten:** Musterobjekte, die auf der Originalseite gelöst oder
  gelöscht sind — auch aus einer Basis-Mustervorlage —, erscheinen auf den
  neuen Seiten nicht doppelt bzw. nicht wieder. Auf Gegenseiten wird das
  Gegenstück über Art, Größe und die gespiegelte Stelle gefunden, nur bei
  genau einem Treffer; sonst ein Hinweis im Bericht. „Musterseitenobjekte
  ausblenden“ am Druckbogen wird auf die neuen Druckbögen übertragen — teilt
  sich eine neue Seite den Druckbogen mit einer vorhandenen, werden die
  Musterobjekte nur auf der neuen Seite entfernt. Wurde das Seitenformat
  nach dem Anlegen des Dokuments geändert oder nur die Originalseite
  vergrößert, zeigen die neuen Seiten die Musterseite genauso wie die
  Originalseite, und Rahmen, die für einen eigenen Text gelöst werden,
  bleiben genau an dieser Stelle (InDesign selbst legt sie beim Lösen dann
  seitlich daneben — auch bei Musterseiten, die auf einer anderen
  basieren). Textrahmen, die ältere Versionen so versetzt abgelegt haben
  und die seitdem niemand bewegt hat, rückt das Script auf der
  Originalseite und den befüllten Seiten an die Musterlage; der Bericht
  nennt sie. Fehlt einer Seite ein Textrahmen für ein Feld mit Text, steht
  auch das im Bericht.
* **Vorhandener Text in den Textrahmen:** Steht in einem dieser Rahmen schon
  Text — von Hand getippt, nach einem früheren Lauf von Hand geändert oder
  aus der Musterseite — und würde der Lauf ihn ersetzen, fragt „Platzieren“
  einmal nach: **Stehen lassen** (Eingabetaste) · **Überschreiben** ·
  **Zurück** (Esc; die Übersicht bleibt mit allen Änderungen offen). Gefragt wird
  auch, wenn ein gleicher Text auf eine Musterseite käme, die Seiten
  außerhalb der Bildstrecke zeigen. Das Fenster nennt je Feld die Seiten und ein Beispiel „alt → neu“; die Antwort
  gilt für alle Seiten dieses Laufs. Neue Seiten sind Kopien der
  Originalseite und tragen deren Text — „Überschreiben“ leert ihn dort auch,
  wenn das Bild für das Feld nichts liefert. Nicht gefragt wird bei Text, den
  das Script selbst eingesetzt hat und der seitdem unverändert ist (das
  Weiterfüllen einer eigenen Strecke läuft still), bei Text, der schon genau
  so dasteht, und bei Rahmen mit nur Leerzeichen. Ein leeres Feld löscht nie
  fremden Text auf der Originalseite oder auf vorhandenen Seiten. Fallen nach
  der Übersicht Dateien weg und verschiebt das die Zuordnung, prüft das
  Script noch einmal (Ja = stehen lassen). Was stehen blieb und Seiten ohne
  Autor nennt der Bericht.
* Dateien, die seit der Auswahl verschwunden sind (Netzlaufwerk getrennt),
  werden **vorher** gemeldet und auf Wunsch übersprungen. Was sich nicht
  platzieren lässt — auch eine „.jpg“, die in Wahrheit Text ist (etwa eine
  gespeicherte Fehlerseite) —, meldet der Bericht; der Rahmen bleibt ein
  leerer Bildrahmen, Texte kommen dort keine hinein (Texte auf der
  Musterseite sind dort trotzdem zu sehen).
* Ein altes Bild im Rahmen wird vorher entfernt (sonst erbte das neue seine
  Drehung). PDF-Seite und Zuschnitt werden je Eintrag gesetzt und danach
  wieder auf InDesigns Vorgabe zurückgestellt.
* **Fortschrittsanzeige**, Esc hält an; der Bericht nennt Probleme mit
  Seitenzahl. Danach springt das Fenster zur Bildstrecke.
* **Intelligenter Textumfluss** wird während des Befüllens angehalten und
  danach zurückgestellt — sonst hängte InDesign bei Übersatz in einem
  gelösten Musterrahmen hinterher selbst Seiten an.
* Ein Rückgängig-Schritt. Ordner, Sortierung, Einpassung, Ausrichtung,
  „Neue Seiten“, das Präfix vor dem Autor und „Gleiche Texte auf die
  Musterseite“ merkt sich das Script
  („Folgeseiten ersetzen“ und die Antwort zu vorhandenem Text nicht — beides
  wählt man jedes Mal bewusst). Ist „Seiten verschieben“ ausgeschaltet
  (Wickelfalz), warnt es.

---

**Stand:** 2026-09-13 · geprüft mit InDesign 21.5.1 (2026), macOS
