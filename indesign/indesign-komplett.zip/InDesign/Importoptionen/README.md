# Importoptionen nachträglich ändern — InDesign-Script

InDesign fragt die Importoptionen nur ein einziges Mal: beim Platzieren.
Danach sind die Seite eines PDFs, der Beschnitt („Zuschneiden auf“) und der
transparente Hintergrund festgeschrieben. Wer sie ändern will, muss die Datei
neu platzieren und Rahmen, Größe und Position von Hand nachbauen.

Dieses Script holt das nach — für einen Rahmen, für eine Auswahl oder für das
ganze Dokument auf einmal.

**Stand:** 2026-08-30 · Version 1.0 · geprüft mit InDesign 21.5.1 (2026), macOS

---

## Wie man es aufruft

Drei Wege — alle bereits eingerichtet:

| Weg | Wo |
|---|---|
| **Menü** | Objekt ▸ Importoptionen ändern … (direkt unter „Objektebenenoptionen …“) |
| **Knopf** | Bedienfeld *Ansicht dwb*, unterste Reihe |
| Skriptbedienfeld | Fenster ▸ Hilfsprogramme ▸ Skripte ▸ Benutzer ▸ Importoptionen.jsx |

Die Palette darf offen bleiben, während weitergearbeitet wird — sie ist kein
modaler Dialog.

### Der Menüeintrag

`Menue-Startup.jsx` legt ihn an. InDesign führt diese Datei bei jedem
Programmstart aus, weil sie im Ordner `startup scripts` liegt. Der Eintrag ist
danach ein ganz normaler Menübefehl und lässt sich unter **Bearbeiten ▸
Tastaturbefehle** (Produktbereich „Skripte“) mit einem Tastenkürzel belegen.

Wo im Menü er landet, steht oben in `Menue-Startup.jsx` in einer Zeile:

```js
var MENUE_ORT = "objekt";   // "objekt" | "fenster" | "eigenes"
```

`"fenster"` hängt ihn unten ans Fenster-Menü, `"eigenes"` legt ein eigenes
Hauptmenü „dwbkd“ neben „Hilfe“ an. Nach einer Änderung InDesign neu starten.

### Der Knopf im Bedienfeld

Das UXP-Bedienfeld *Ansicht dwb* (siehe `../Bedienfelder/`) hat in der
zweiten Reihe den Knopf **„Importoptionen …“**. Er ruft den Menübefehl auf;
fehlt der, startet er die Datei aus dem Skriptbedienfeld.

### Einrichtung auf einem anderen Rechner

Den Installer nehmen — er verknüpft Skript und Startskript in **jedem**
Versions- und Sprachordner, den InDesign auf dem Rechner angelegt hat, die
Pfade muss niemand von Hand zusammensetzen:

```bash
"/Users/danielbittner/Claude Code/InDesign/installieren.command"
```

Danach InDesign neu starten. Von Hand ginge auch je eine Verknüpfung nach
`~/Library/Preferences/Adobe InDesign/Version <x>/<Sprache>/Scripts/Scripts Panel/`
bzw. `…/Scripts/startup scripts/`.

---

## Was das Script kann

| | PDF · Illustrator | InDesign-Datei | PSD · TIFF | andere Bilder |
|---|---|---|---|---|
| Seite wechseln | ✅ | ✅ | – | – |
| Zuschneiden auf | ✅ | ✅ | – | – |
| Transparenter Hintergrund | ✅ | – | – | – |
| Ebenen ein-/ausblenden | ✅ (bei Ebenen-PDF/AI) | ✅ | ✅ | – |
| Beschnittpfad, Alphakanal | – | – | ✅ | ✅ |

### Liste
Oben stehen alle Platzierungen — wahlweise nur die aktuelle Auswahl oder das
ganze Dokument. Die Reihenfolge folgt der Leserichtung: erst Dokumentseite,
dann von oben nach unten, dann von links nach rechts. Alle Aktionen wirken auf
**alle markierten Zeilen** zugleich.

* **Im Dokument zeigen** wählt die markierten Rahmen im Layout aus.
* **Gleiche Datei markieren** greift alle Vorkommen derselben Datei.
* **der Auswahl folgen** aktualisiert die Liste, sobald im Layout etwas
  angeklickt wird.

### Reiter „Seite & Beschnitt“
* **◀ ▶** blättert alle markierten Platzierungen eine Seite vor oder zurück —
  jede von ihrem eigenen Stand aus. Am Anfang und Ende der Datei ist Schluss.
* **Zuschneiden auf** — Inhalt, Grafik, Objektrahmen, Endformat, Anschnitt,
  Medien. Genau die Liste aus dem Importdialog, plus die Unterscheidung
  „sichtbare“ / „alle Ebenen“, die InDesign nur im Skriptmodell führt.
* **Nach dem Ändern** bestimmt, was mit der Grafik im Rahmen geschieht.
  Standard ist „unverändert lassen“: Größe, Drehung und Position bleiben, nur
  der Inhalt wechselt.
* **Seiten fortlaufend verteilen** legt aufsteigende Seiten auf die markierten
  Rahmen — für Katalogseiten, Korrekturbögen, Ausschießen. Ein negativer
  Schritt zählt rückwärts.

### Reiter „Ebenen“
Klick auf eine Zeile schaltet die Ebene um — in allen markierten Platzierungen
gleichzeitig. Das ist der Unterschied zu InDesigns eigenem Dialog
„Objektebenenoptionen“, der immer nur ein Objekt bedient.

* **Auf gleiche Datei übertragen** überträgt die Ebeneneinstellung der ersten
  markierten Platzierung auf jedes weitere Vorkommen derselben Datei im
  Dokument.
* **Beim Aktualisieren der Verknüpfung** entspricht der gleichnamigen Option:
  Ebeneneinstellung beibehalten oder die Sichtbarkeit aus der Datei übernehmen.

### Reiter „Bild“
Photoshop-Beschnittpfad und Alphakanal. „Einstellen“ hinterlegt die Werte am
Objekt (sie greifen beim nächsten Aktualisieren), „Einstellen und neu einlesen“
wendet sie sofort an. Die Vorschauauflösung zeigt das Script nur an — InDesign
hält sie schreibgeschützt.

---

## Was erhalten bleibt

Rahmen, Skalierung, Drehung, Position, Objektstil, Textumfluss, Farbprofil und
Renderpriorität, Ebenensichtbarkeit, Objektname und Etikett, Anzeigeleistung,
„nicht drucken“.

Jede Aktion ist **ein** Rückgängig-Schritt: Ein Cmd+Z nimmt auch eine
Verteilung über zwanzig Rahmen komplett zurück.

## Was nicht geht

* **Eingebettete Grafiken** haben keine Datei mehr, aus der neu importiert
  werden könnte. Ebenen lassen sich trotzdem umschalten, Seite und Beschnitt
  nicht. Solche Zeilen sind in der Liste gekennzeichnet.
* **Fehlende Verknüpfungen** werden übersprungen und gemeldet.
* Ein **von Hand gezeichneter Beschnittpfad** (Objekt ▸ Beschnittpfad ▸ Pfad
  erkennen) überlebt das Neueinlesen nicht. Pfade aus der Datei schon.
* Die **Vorschauauflösung** ist im Objektmodell schreibgeschützt.

---

## Warum es so gebaut ist

Vier Dinge waren beim Bauen nicht offensichtlich — geprüft in InDesign 21.5.1:

1. **`link.relink(dieselbeDatei)` bringt gar nichts.** InDesign erkennt, dass
   sich die Datei nicht geändert hat, und behält die alten Importoptionen. Was
   wirkt, ist ein erneutes `rahmen.place(datei)` in den vorhandenen Rahmen —
   das liest die Datei mit den aktuellen Voreinstellungen neu ein und übernimmt
   Skalierung und Drehung der bisherigen Grafik von selbst.

2. **Jede Ebenenänderung baut die Grafik neu auf.** Eine gemerkte Referenz auf
   `graphicLayers` ist danach wertlos („Objekt existiert nicht mehr“, oder
   kryptisch: „Error: length“). Deshalb holt das Script die Grafik vor jedem
   Zugriff frisch über den Rahmen und setzt immer nur eine Ebene auf einmal.
   `itemByID()` hilft nicht — die ID stammt aus der PSD, nicht aus InDesign.

3. **In einer eigenen Skript-Umgebung (`#targetengine`) versagen zwei Dinge,
   die sonst funktionieren:** der Zugriff auf Aufzählungen über eckige Klammern
   (`PDFCrop["CROP_MEDIA"]`) und `constructor.name` (jede Grafik heißt dort
   „InDesign“). Beides ohne Fehlermeldung — die Zuweisung eines undefinierten
   Werts schluckt InDesign kommentarlos. Das Script sammelt deshalb alle
   Enum-Zahlen einmal mit Punkt-Notation in eine Tabelle und erkennt die Art
   einer Grafik über die Dateiendung.

4. **Platzierte InDesign-Dateien melden ihren Zustand in `pdfAttributes`** —
   gesetzt wird er aber über `app.importedPageAttributes`, und zwar mit einem
   anderen Aufzählungstyp. Beim Anzeigen müssen beide Wertetabellen abgeklopft
   werden.

Eine Palette (kein modaler Dialog) ist Pflicht: Solange ein modaler
ScriptUI-Dialog offen ist, setzt InDesign `app.modalState = true` und weist
jede Dokumentänderung ab.

Der Menübefehl braucht ebenfalls eine eigene, dauerhafte Skript-Umgebung:
`ScriptMenuAction`s leben nur so lange wie die Umgebung, in der sie angelegt
wurden — in der Standardumgebung wäre der Eintrag nach dem nächsten
Skriptaufruf wieder weg.

---

## Prüfung

```bash
python3 ../../PDF-UA/pruefe-jsx.py Importoptionen.jsx
```

Findet die ExtendScript-Falle, die Klick-Handler wortlos sterben lässt: eine
Variable, die benutzt wird, bevor ihr `var` steht.
