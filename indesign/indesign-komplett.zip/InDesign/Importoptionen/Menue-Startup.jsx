﻿// ============================================================================
// Menue-Startup.jsx  —  Adobe InDesign               ·            Version 1.0
// ----------------------------------------------------------------------------
// Hängt „Importoptionen ändern …“ fest ins Menü. InDesign führt dieses Script
// bei jedem Programmstart aus, sobald es im Ordner „startup scripts“ liegt:
//
//   ~/Library/Preferences/Adobe InDesign/Version 21.0/de_DE/Scripts/
//       startup scripts/Menue-Startup.jsx
//
// Der Eintrag ist danach ein ganz normaler Menübefehl — er lässt sich unter
// Bearbeiten ▸ Tastaturbefehle (Produktbereich „Skripte“) auch mit einem
// Tastenkürzel belegen.
//
// Der Ort im Menü lässt sich unten einstellen.
// ----------------------------------------------------------------------------
// © 2026 dwbkd · www.dwbkd.de
// ============================================================================

#target indesign

// Menübefehle leben nur so lange wie die Skript-Umgebung, in der sie angelegt
// wurden. In der Standard-Umgebung wäre der Eintrag nach dem ersten Aufruf
// eines beliebigen anderen Scripts wieder weg — deshalb eine eigene, dauerhafte.
#targetengine "dwbkd_menue"

(function () {

// ---------------------------------------------------------------- Einstellung
// "objekt"  = Menü Objekt, direkt unter „Objektebenenoptionen …“   (Standard)
// "fenster" = Menü Fenster, ganz unten
// "eigenes" = eigenes Hauptmenü „dwbkd“ neben Hilfe
var MENUE_ORT  = "objekt";
var EINTRAG    = "Importoptionen ändern …";
var EIGENES_MENUE = "dwbkd";

// ------------------------------------------------------------- Hauptscript
// Erst neben dieser Datei suchen, dann im Skriptbedienfeld. Symlinks werden
// aufgelöst — im Ordner „startup scripts“ liegt in aller Regel nur eine
// Verknüpfung, und deren Nachbarschaft ist der Projektordner, nicht der
// Ordner, in dem die Verknüpfung steht.
function hauptscriptFinden() {
    var kandidaten = [];
    try {
        var selbst = File($.fileName);
        var echt = selbst.resolve() || selbst;
        kandidaten.push(File(echt.parent.fsName + "/Importoptionen.jsx"));
        kandidaten.push(File(selbst.parent.fsName + "/Importoptionen.jsx"));
    } catch (e) {}
    try {
        var panel = Folder(app.scriptPreferences.scriptsFolder.fsName + "/Scripts Panel");
        kandidaten.push(File(panel.fsName + "/Importoptionen.jsx"));
    } catch (e) {}
    for (var i = 0; i < kandidaten.length; i++) {
        var f = kandidaten[i];
        if (!f) continue;
        var echt = f.resolve() || f;
        if (echt.exists) return echt;
    }
    return null;
}

// ------------------------------------------------------------------- Menü
function zielMenue() {
    var haupt = app.menus.item("$ID/Main");
    if (MENUE_ORT === "fenster") {
        var f = haupt.submenus.item("$ID/&Window");
        if (f.isValid) return { menue: f, nach: null };
    }
    if (MENUE_ORT === "eigenes") {
        var e = haupt.submenus.item(EIGENES_MENUE);
        if (!e.isValid) e = haupt.submenus.add(EIGENES_MENUE);
        return { menue: e, nach: null };
    }
    var obj = haupt.submenus.item("$ID/&Object");
    if (!obj.isValid) return { menue: haupt.submenus.item("$ID/&Window"), nach: null };
    // Direkt unter dem verwandten Befehl einhängen, wenn er auffindbar ist.
    var nach = null;
    try {
        var kandidat = obj.menuItems.item("$ID/Object Layer Options...");
        if (kandidat.isValid) nach = kandidat;
    } catch (e) {}
    if (!nach) {
        try {
            for (var i = 0; i < obj.menuElements.length; i++) {
                var n = "";
                try { n = obj.menuElements[i].name; } catch (e2) { continue; }
                if (/Objektebenenoptionen|Object Layer Options/i.test(n)) { nach = obj.menuElements[i]; break; }
            }
        } catch (e) {}
    }
    return { menue: obj, nach: nach };
}

function aufraeumen() {
    // Bei einem zweiten Durchlauf (Script von Hand gestartet) sonst doppelt.
    try {
        var vorhanden = app.scriptMenuActions.itemByName(EINTRAG);
        while (vorhanden.isValid) {
            vorhanden.remove();
            vorhanden = app.scriptMenuActions.itemByName(EINTRAG);
        }
    } catch (e) {}
}

function anlegen() {
    aufraeumen();

    var aktion = app.scriptMenuActions.add(EINTRAG);
    aktion.eventListeners.add("onInvoke", function () {
        var f = hauptscriptFinden();
        if (!f) {
            alert("Importoptionen.jsx wurde nicht gefunden.\n\n" +
                  "Die Datei muss neben „Menue-Startup.jsx“ liegen oder im\n" +
                  "Skriptbedienfeld (Fenster ▸ Hilfsprogramme ▸ Skripte).");
            return;
        }
        // doScript startet die Datei als eigenständiges Script — die
        // targetengine-Angabe in ihrem Kopf bleibt dabei wirksam.
        app.doScript(f, ScriptLanguage.JAVASCRIPT);
    });

    var ziel = zielMenue();
    if (!ziel.menue || !ziel.menue.isValid) return false;

    if (ziel.nach) ziel.menue.menuItems.add(aktion, LocationOptions.AFTER, ziel.nach);
    else           ziel.menue.menuItems.add(aktion, LocationOptions.AT_END);
    return true;
}

// Beim Start darf nichts hochkommen, was InDesign aufhält.
try { anlegen(); } catch (e) {}

// Von Hand gestartet soll man sehen, ob es geklappt hat.
$.global.dwbkdMenue = { eintrag: EINTRAG, anlegen: anlegen, hauptscript: hauptscriptFinden };

})();
