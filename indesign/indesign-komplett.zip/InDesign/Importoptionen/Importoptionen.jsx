﻿// ============================================================================
// Importoptionen.jsx  —  Adobe InDesign                ·            Version 1.2
// ----------------------------------------------------------------------------
// Importoptionen nachträglich ändern — das, was InDesign selbst nicht anbietet.
//
// InDesign fragt die Importoptionen nur einmal: beim Platzieren. Danach ist
// die Seite eines PDFs, der Beschnitt („Zuschneiden auf“) oder der
// transparente Hintergrund festgeschrieben. Dieses Script holt das nach —
// für einzelne Rahmen, für eine Auswahl oder für das ganze Dokument.
//
// Was geht:
//   • PDF / Illustrator      Seite, Zuschneiden auf, transparenter Hintergrund
//   • InDesign-Dateien       Seite, Zuschneiden auf
//   • PSD / TIFF / AI / INDD Ebenen ein- und ausblenden (auch mehrere Rahmen
//                            auf einmal — das kann InDesigns eigener Dialog
//                            „Objektebenenoptionen“ nicht)
//   • PSD / TIFF             Photoshop-Beschnittpfad, Alphakanal,
//                            Vorschauauflösung
//   • Seiten verteilen       fortlaufende PDF-Seiten auf mehrere Rahmen
//                            legen (Katalog, Ausschießen, Korrekturbogen) —
//                            wahlweise nach Seitenliste („2, 5, 8-12“), mit
//                            Vorschau vor dem ernsthaften Verteilen
//   • Datei tauschen         neue Dateiversion in markierte Rahmen legen,
//                            Seite/Beschnitt/Ebenen bleiben erhalten
//
// Alles bleibt erhalten: Rahmen, Skalierung, Drehung, Position, Objektstil,
// Textumfluss, Farbprofil, Ebenensichtbarkeit. Jede Aktion ist ein einzelner
// Rückgängig-Schritt (Cmd+Z).
//
// Verwendung:
//   Fenster ▸ Hilfsprogramme ▸ Skripte ▸ Doppelklick auf dieses Script
//   (oder Datei ▸ Skripten). Das Fenster ist eine Palette und darf offen
//   bleiben, während weitergearbeitet wird.
//
// Hinweise:
//   • Eingebettete Grafiken haben keine Datei mehr, aus der neu importiert
//     werden könnte. Ebenen lassen sich trotzdem umschalten, die übrigen
//     Importoptionen nicht — solche Zeilen sind in der Liste gekennzeichnet.
//   • Beim Ändern der Importoptionen wird die Grafik neu eingelesen. Ein
//     manuell gezeichneter Beschnittpfad (Objekt ▸ Beschnittpfad ▸ Pfad
//     erkennen) überlebt das nicht; Pfade aus der Datei schon.
// ----------------------------------------------------------------------------
// © 2026 dwbkd · www.dwbkd.de
// ============================================================================

#target indesign

// Das Fenster muss eine nicht-modale Palette sein: solange ein modaler
// ScriptUI-Dialog offen ist, setzt InDesign app.modalState = true und weist
// jede Änderung am Dokument ab. Paletten brauchen eine dauerhafte
// Skript-Umgebung — daher targetengine.
#targetengine "dwbkd_importoptionen"

(function () {

var TITEL   = "Importoptionen";
var VERSION = "1.2";

// ------------------------------------------------------- Enum-Werte einsammeln
// InDesigns Aufzählungen vertragen in einer eigenen Skript-Umgebung
// (targetengine) keinen Zugriff über eckige Klammern: PDFCrop["CROP_MEDIA"]
// scheitert dort, während PDFCrop.CROP_MEDIA funktioniert — und die
// Zuweisung eines undefinierten Werts schluckt InDesign kommentarlos. Also
// werden die Zahlen einmal mit Punkt-Notation eingesammelt; danach ist es
// eine gewöhnliche Tabelle, die jeden Zugriff verträgt.
var CROP_WERT = {
    CROP_CONTENT_VISIBLE_LAYERS: PDFCrop.CROP_CONTENT_VISIBLE_LAYERS,
    CROP_CONTENT_ALL_LAYERS:     PDFCrop.CROP_CONTENT_ALL_LAYERS,
    CROP_ART:                    PDFCrop.CROP_ART,
    CROP_PDF:                    PDFCrop.CROP_PDF,
    CROP_TRIM:                   PDFCrop.CROP_TRIM,
    CROP_BLEED:                  PDFCrop.CROP_BLEED,
    CROP_MEDIA:                  PDFCrop.CROP_MEDIA
};
var CROP_WERT_INDD = {
    CROP_CONTENT: ImportedPageCropOptions.CROP_CONTENT,
    CROP_BLEED:   ImportedPageCropOptions.CROP_BLEED,
    CROP_SLUG:    ImportedPageCropOptions.CROP_SLUG
};
var FIT_WERT = {
    PROPORTIONALLY:              FitOptions.PROPORTIONALLY,
    FILL_PROPORTIONALLY:         FitOptions.FILL_PROPORTIONALLY,
    CENTER_CONTENT:              FitOptions.CENTER_CONTENT,
    APPLY_FRAME_FITTING_OPTIONS: FitOptions.APPLY_FRAME_FITTING_OPTIONS,
    FRAME_TO_CONTENT:            FitOptions.FRAME_TO_CONTENT
};
var STATUS_EINGEBETTET = LinkStatus.LINK_EMBEDDED;
var STATUS_FEHLT       = LinkStatus.LINK_MISSING;
var UPDATE_BEIBEHALTEN = UpdateLinkOptions.KEEP_OVERRIDES;
var UPDATE_AUS_DATEI   = UpdateLinkOptions.APPLICATION_SETTINGS;
var CLIP_WERT = {
    NONE:           ClippingPathType.NONE,
    PHOTOSHOP_PATH: ClippingPathType.PHOTOSHOP_PATH
};

// ---------------------------------------------------------------- Zuschneiden
// Reihenfolge und Benennung wie im Importdialog von InDesign. Die beiden
// Inhalt-Varianten trennt InDesign nur im Skript-Modell, nicht in der
// Oberfläche — hier stehen sie einzeln, weil genau das der Grund ist, warum
// man hinterher noch einmal ran will.
var CROPS = [
    ["Inhalt (sichtbare Ebenen)", "CROP_CONTENT_VISIBLE_LAYERS"],
    ["Inhalt (alle Ebenen)",      "CROP_CONTENT_ALL_LAYERS"],
    ["Grafik",                    "CROP_ART"],
    ["Objektrahmen",              "CROP_PDF"],
    ["Endformat",                 "CROP_TRIM"],
    ["Anschnitt",                 "CROP_BLEED"],
    ["Medien",                    "CROP_MEDIA"]
];
// InDesign-Dateien kennen nur diese drei.
var CROPS_INDD = [
    ["Inhalt",     "CROP_CONTENT"],
    ["Anschnitt",  "CROP_BLEED"],
    ["Infobereich","CROP_SLUG"]
];

// Bei gemischter Auswahl (PDF und INDD zugleich markiert) zeigt der Dropdown
// die Tabelle des ERSTEN passenden Eintrags — beim Anwenden braucht aber
// jeder Eintrag den Schlüssel seiner eigenen Tabelle. Sonst landet etwa
// CROP_TRIM in CROP_WERT_INDD, ist dort undefined, und InDesign schluckt
// die Zuweisung kommentarlos — die Zeile zählte trotzdem als „geändert“.
// Deshalb hier die sinngemäße Übersetzung in beide Richtungen.
var CROP_NACH_INDD = {
    CROP_CONTENT_VISIBLE_LAYERS: "CROP_CONTENT",
    CROP_CONTENT_ALL_LAYERS:     "CROP_CONTENT",
    CROP_ART:                    "CROP_CONTENT",
    CROP_PDF:                    "CROP_CONTENT",
    CROP_TRIM:                   "CROP_CONTENT",
    CROP_BLEED:                  "CROP_BLEED",
    CROP_MEDIA:                  "CROP_SLUG",
    CROP_CONTENT:                "CROP_CONTENT",
    CROP_SLUG:                   "CROP_SLUG"
};
var CROP_NACH_PDF = {
    CROP_CONTENT: "CROP_TRIM",
    CROP_BLEED:   "CROP_BLEED",
    CROP_SLUG:    "CROP_MEDIA"
};

function cropFuerTyp(schluessel, typ) {
    if (schluessel === undefined || schluessel === null) return null;
    if (typ === "InDesign") return CROP_NACH_INDD[schluessel] || null;
    if (CROP_WERT[schluessel] !== undefined) return schluessel;
    return CROP_NACH_PDF[schluessel] || null;
}

// Der Rückweg: vom Zahlwert, wie ihn pdfAttributes meldet, zum Schlüssel —
// für Aktionen, die den BESTEHENDEN Beschnitt eines Eintrags weitertragen
// („Datei tauschen“). Erst danach übersetzt cropFuerTyp in die Zieltabelle.
function cropSchluesselVonWert(wert) {
    if (wert === null || wert === undefined) return null;
    var k;
    for (k in CROP_WERT)
        if (CROP_WERT.hasOwnProperty(k) && CROP_WERT[k] === wert) return k;
    for (k in CROP_WERT_INDD)
        if (CROP_WERT_INDD.hasOwnProperty(k) && CROP_WERT_INDD[k] === wert) return k;
    return null;
}

var EINPASSUNG = [
    ["Grafik unverändert lassen",       "nichts"],
    ["Proportional in Rahmen einpassen","PROPORTIONALLY"],
    ["Rahmen proportional füllen",      "FILL_PROPORTIONALLY"],
    ["Grafik im Rahmen zentrieren",     "CENTER_CONTENT"],
    ["Rahmeneinpassung anwenden",       "APPLY_FRAME_FITTING_OPTIONS"],
    ["Rahmen an Grafik anpassen",       "FRAME_TO_CONTENT"]
];

// ============================================================================
//  Grafiken einsammeln
// ============================================================================

// Alles, was aus einer Datei stammt und Importoptionen haben kann.
var GRAFIKTYPEN = { PDF:1, Image:1, ImportedPage:1, EPS:1, WMF:1, PICT:1 };

function klassenName(o) {
    // constructor.name ist unbrauchbar: über rahmen.graphics[0] heißt jede
    // Grafik schlicht „Graphic“, und in einer eigenen Skript-Umgebung kommt
    // sogar „InDesign“ zurück. String(o) liefert „[object PDF]“ & Co. —
    // allerdings auch nicht immer, direkt nach einem Ersetzen steht dort
    // ebenfalls „Graphic“. Deshalb ist das hier nur ein Hinweis, kein Beweis.
    try {
        var m = String(o).match(/^\[object (\w+)\]$/);
        return m ? m[1] : "";
    } catch (e) { return ""; }
}

function istGrafik(o) {
    var k = klassenName(o);
    if (GRAFIKTYPEN[k]) return true;
    // „Graphic“ heißt: eine Grafik ist es, nur welche Art, weiß man noch nicht.
    if (k === "Graphic") return true;
    return false;
}

// Welche Importvoreinstellungen für diese Grafik gelten, entscheidet die
// Dateiart — nicht die Objektklasse. Die Endung ist dabei der verlässlichste
// Hinweis, weil sie auch dann noch stimmt, wenn InDesign die Klasse gerade
// nicht auflöst.
function typVon(g, pfad) {
    var endung = "";
    if (pfad) {
        var m = String(pfad).match(/\.([A-Za-z0-9]+)$/);
        if (m) endung = m[1].toLowerCase();
    }
    if (endung === "indd" || endung === "indl" || endung === "idms") return "InDesign";
    if (endung === "pdf"  || endung === "ai")                        return "PDF";
    if (endung === "eps"  || endung === "epsf" || endung === "ps")   return "EPS";
    if (endung)                                                      return "Bild";

    var k = klassenName(g);
    if (k === "ImportedPage") return "InDesign";
    if (k === "PDF")          return "PDF";
    if (k === "EPS")          return "EPS";
    if (k === "Image")        return "Bild";

    // Letzte Zuflucht: der Formatname, den InDesign selbst führt.
    var t = "";
    try { t = String(g.imageTypeName); } catch (e) {}
    if (/InDesign/i.test(t)) return "InDesign";
    if (/PDF/i.test(t))      return "PDF";
    if (/EPS|PostScript/i.test(t)) return "EPS";
    return "Bild";
}

// Der Rahmen ist der stabile Anker: die Grafik selbst wird bei jedem
// Neu-Import und bei jeder Ebenenänderung durch ein neues Objekt ersetzt.
function rahmenVon(g) {
    try {
        var p = g.parent;
        // Verschachtelte Grafiken (Grafik in Grafik) gibt es nicht, aber
        // Rahmen können in Gruppen oder verankert liegen — das stört nicht.
        return (p && p.isValid) ? p : null;
    } catch (e) { return null; }
}

function grafikVon(rahmen) {
    try {
        if (!rahmen || !rahmen.isValid) return null;
        return rahmen.graphics.length ? rahmen.graphics[0] : null;
    } catch (e) { return null; }
}

function sammleAusAuswahl() {
    var res = [];
    var sel = app.selection;
    for (var i = 0; i < sel.length; i++) {
        var o = sel[i];
        if (istGrafik(o)) { res.push(o); continue; }
        try {
            var ag = o.allGraphics;
            for (var j = 0; j < ag.length; j++) res.push(ag[j]);
        } catch (e) {}
    }
    return res;
}

function sammleAusDokument(doc) {
    try { return doc.allGraphics; } catch (e) { return []; }
}

// Ein Eintrag der Liste: gebündelte Angaben zu einer Platzierung.
function EintragAus(g) {
    var e = {
        rahmen: rahmenVon(g),
        typ: "",            // PDF | Bild | InDesign | EPS | …
        dateiname: "(eingebettet)",
        pfad: "",
        vorhanden: false,
        eingebettet: true,
        seite: 0,
        seitenGesamt: 0,
        crop: null,
        transparent: null,
        ebenen: 0,
        dokSeite: "—",
        fehlt: false,
        warnung: false,     // ⚠ aus dem letzten Lauf (übersprungen/fehlgeschlagen)
        sortSeite: 99999, sortY: 0, sortX: 0
    };
    if (!e.rahmen) return null;

    try {
        var l = g.itemLink;
        if (l && l.isValid) {
            e.dateiname = l.name;
            e.pfad = l.filePath;
            // Eingebettete Grafiken behalten ihren Link-Eintrag samt Pfad,
            // erkennbar sind sie nur am Status.
            e.eingebettet = (l.status === STATUS_EINGEBETTET);
            e.fehlt = (l.status === STATUS_FEHLT);
            e.vorhanden = !e.fehlt && !e.eingebettet && File(e.pfad).exists;
        }
    } catch (er) {}

    e.typ = typVon(g, e.pfad);

    // Seite und Beschnitt stehen auch bei platzierten InDesign-Dateien in
    // pdfAttributes — importedPageAttributes gibt es nur als Voreinstellung
    // der Anwendung, nicht am Objekt.
    try { e.seite = g.pdfAttributes.pageNumber;
          e.crop = g.pdfAttributes.pdfCrop;
          e.transparent = g.pdfAttributes.transparentBackground; } catch (er) {}
    try { e.ebenen = g.graphicLayerOptions.graphicLayers.length; } catch (er) {}

    try {
        var p = e.rahmen.parentPage;
        e.dokSeite = p ? String(p.name) : "MF";   // MF = Montagefläche
        if (p) e.sortSeite = p.documentOffset;
    } catch (er) {}
    try {
        var b = e.rahmen.geometricBounds;
        e.sortY = b[0]; e.sortX = b[1];
    } catch (er) {}

    return e;
}

function sammle(bereich, doc) {
    var roh = (bereich === "auswahl") ? sammleAusAuswahl() : sammleAusDokument(doc);
    var res = [];
    for (var i = 0; i < roh.length; i++) {
        var e = EintragAus(roh[i]);
        if (e) res.push(e);
    }
    // allGraphics liefert die Grafiken in der Reihenfolge des Objektmodells —
    // die hat mit dem, was man auf dem Papier sieht, nichts zu tun. Für
    // „Seiten fortlaufend verteilen“ muss die Liste aber der Leserichtung
    // folgen: erst Dokumentseite, dann von oben nach unten, dann von links
    // nach rechts.
    res.sort(function (a, b) {
        if (a.sortSeite !== b.sortSeite) return a.sortSeite - b.sortSeite;
        if (Math.abs(a.sortY - b.sortY) > 0.5) return a.sortY - b.sortY;
        return a.sortX - b.sortX;
    });
    return res;
}

// ============================================================================
//  Seitenzahl eines PDFs
// ============================================================================
// InDesign verrät nicht, wie viele Seiten die verknüpfte Datei hat. Also
// selbst nachsehen: im Seitenbaum steht „/Type /Pages … /Count n“. Bei
// PDFs mit komprimierten Objekt-Streams steht das nicht im Klartext — dann
// übernimmt Spotlight (mdls), und wenn auch das nichts weiß, bleibt das
// Feld eben ohne Obergrenze.

var seitenCache = {};

function pdfSeitenzahl(pfad) {
    if (seitenCache[pfad] !== undefined) return seitenCache[pfad];
    var n = 0;
    var f = File(pfad);
    if (f.exists) {
        try {
            f.encoding = "BINARY";
            if (f.open("r")) {
                var laenge = f.length, txt;
                if (laenge > 4194304) {
                    // Der Seitenbaum steht am Anfang oder am Ende — die Mitte
                    // ist bei großen Dateien nur Bildmaterial.
                    txt = f.read(2097152);
                    f.seek(laenge - 2097152, 0);
                    txt += f.read(2097152);
                } else {
                    txt = f.read();
                }
                f.close();
                var m = txt.match(/\/Type\s*\/Pages[\s\S]{0,600}?\/Count\s+(\d+)/g);
                if (m) {
                    for (var i = 0; i < m.length; i++) {
                        var c = m[i].match(/\/Count\s+(\d+)/);
                        if (c && Number(c[1]) > n) n = Number(c[1]);
                    }
                }
                if (!n) {
                    var p = txt.match(/\/Type\s*\/Page[^s]/g);
                    if (p) n = p.length;
                }
            }
        } catch (e) { try { f.close(); } catch (e2) {} }
    }
    if (!n) n = seitenzahlVonSpotlight(pfad);
    seitenCache[pfad] = n;
    return n;
}

function seitenzahlVonSpotlight(pfad) {
    try {
        var as = 'do shell script "mdls -raw -name kMDItemNumberOfPages " & quoted form of "' +
                 String(pfad).replace(/"/g, '\\"') + '"';
        var r = String(app.doScript(as, ScriptLanguage.APPLESCRIPT_LANGUAGE));
        var n = parseInt(r, 10);
        return (isNaN(n) || n < 1) ? 0 : n;
    } catch (e) { return 0; }
}

// ============================================================================
//  Zustand sichern und wiederherstellen
// ============================================================================
// Der Neu-Import ersetzt die Grafik durch ein frisches Objekt. Skalierung,
// Drehung und Position übernimmt InDesign dabei von selbst; alles andere
// muss hier durchgereicht werden.

function zustandSichern(g) {
    var s = { ebenen: null, profil: null, intent: null, io: null,
              anzeige: null, nichtDruckend: null, etikett: "", name: "",
              pfadAktiv: "",
              matrix: null, hs: null, vs: null, rot: null, sh: null, mitte: null };
    try { s.matrix = g.transformValuesOf(CoordinateSpaces.PASTEBOARD_COORDINATES)[0]; } catch (e) {}
    try { s.hs = g.horizontalScale; s.vs = g.verticalScale;
          s.rot = g.rotationAngle;  s.sh = g.shearAngle;
          var b = g.geometricBounds;
          s.mitte = [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2]; } catch (e) {}
    try { s.profil = g.profile; s.intent = g.imageRenderingIntent; } catch (e) {}
    try { s.anzeige = g.localDisplaySetting; } catch (e) {}
    try { s.nichtDruckend = g.nonprinting; } catch (e) {}
    try { s.etikett = g.label; } catch (e) {}
    try { s.name = g.name; } catch (e) {}
    try {
        var io = g.imageIOPreferences;
        s.io = { applyPhotoshopClippingPath: io.applyPhotoshopClippingPath,
                 alphaChannelName: io.alphaChannelName,
                 previewResolution: io.previewResolution };
    } catch (e) {}
    // WELCHER Photoshop-Pfad gerade wirkt, steht nur am clippingPath — den
    // Namen mitsichern, damit der Zuschnitt einen Neu-Import überlebt.
    try {
        var cp = g.clippingPath;
        if (cp.clippingType === CLIP_WERT.PHOTOSHOP_PATH)
            s.pfadAktiv = String(cp.appliedPathName);
    } catch (e) {}
    try {
        var gl = g.graphicLayerOptions.graphicLayers, arr = [];
        for (var i = 0; i < gl.length; i++) arr.push({ name: gl[i].name, sichtbar: gl[i].currentVisibility });
        s.ebenen = arr;
        s.updateLink = g.graphicLayerOptions.updateLinkOption;
    } catch (e) {}
    return s;
}

function zustandWiederherstellen(rahmen, s, einpassung) {
    var g = grafikVon(rahmen);
    if (!g) return;

    // Erst einpassen, dann die Feinheiten — Einpassen verändert die Geometrie.
    if (einpassung && einpassung !== "nichts") {
        try { rahmen.fit(FIT_WERT[einpassung]); } catch (e) {}
    } else if (s.matrix && s.hs !== null) {
        // InDesign übernimmt Skalierung und Drehung beim Ersetzen selbst.
        // Falls doch nicht (andere Seitengröße, anderer Beschnitt), hier
        // nachziehen, damit die Grafik nicht springt.
        try {
            if (Math.abs(g.horizontalScale - s.hs) > 0.01 ||
                Math.abs(g.verticalScale   - s.vs) > 0.01) {
                g.rotationAngle   = s.rot;
                g.shearAngle      = s.sh;
                g.horizontalScale = s.hs;
                g.verticalScale   = s.vs;
                var b = g.geometricBounds;
                g.move(undefined, [s.mitte[1] - (b[1] + b[3]) / 2,
                                   s.mitte[0] - (b[0] + b[2]) / 2]);
            }
        } catch (e) {}
    }

    try { if (s.profil !== null) g.profile = s.profil; } catch (e) {}
    try { if (s.intent !== null) g.imageRenderingIntent = s.intent; } catch (e) {}
    try { if (s.anzeige !== null) g.localDisplaySetting = s.anzeige; } catch (e) {}
    try { if (s.nichtDruckend !== null) g.nonprinting = s.nichtDruckend; } catch (e) {}
    try { if (s.etikett) g.label = s.etikett; } catch (e) {}
    try { if (s.name) g.name = s.name; } catch (e) {}
    try { if (s.updateLink) g.graphicLayerOptions.updateLinkOption = s.updateLink; } catch (e) {}

    // Ebenensichtbarkeit nach Namen zurückholen (Reihenfolge kann sich
    // geändert haben, wenn die Datei zwischenzeitlich bearbeitet wurde).
    if (s.ebenen && s.ebenen.length) {
        for (var i = 0; i < s.ebenen.length; i++) {
            if (s.ebenen[i].sichtbar) continue;      // sichtbar ist der Normalfall
            setzeEbeneNachName(rahmen, s.ebenen[i].name, false);
        }
    }
}

// ============================================================================
//  Ebenen schalten
// ============================================================================
// Jede Zuweisung an currentVisibility baut die Grafik neu auf. Deshalb wird
// die Referenz vor jedem Zugriff frisch über den Rahmen geholt und immer nur
// eine Ebene auf einmal gesetzt.

function setzeEbeneNachIndex(rahmen, idx, sichtbar) {
    try {
        var g = grafikVon(rahmen);
        if (!g) return false;
        var gl = g.graphicLayerOptions.graphicLayers;
        if (idx < 0 || idx >= gl.length) return false;
        if (gl[idx].currentVisibility === sichtbar) return true;
        gl[idx].currentVisibility = sichtbar;
        return true;
    } catch (e) { return false; }
}

function setzeEbeneNachName(rahmen, name, sichtbar) {
    try {
        var g = grafikVon(rahmen);
        if (!g) return false;
        var gl = g.graphicLayerOptions.graphicLayers;
        for (var i = 0; i < gl.length; i++) {
            if (gl[i].name === name) {
                if (gl[i].currentVisibility === sichtbar) return true;
                gl[i].currentVisibility = sichtbar;
                return true;
            }
        }
        return false;
    } catch (e) { return false; }
}

function ebenenListe(rahmen) {
    var res = [];
    try {
        var g = grafikVon(rahmen);
        if (!g) return res;
        var gl = g.graphicLayerOptions.graphicLayers;
        for (var i = 0; i < gl.length; i++) {
            res.push({ index: i, name: gl[i].name,
                       sichtbar: gl[i].currentVisibility,
                       gesperrt: sicher(function () { return gl[i].locked; }, false) });
        }
    } catch (e) {}
    return res;
}

function sicher(fn, ersatz) { try { return fn(); } catch (e) { return ersatz; } }

// ============================================================================
//  Importoptionen neu anwenden
// ============================================================================
// Der Kern des Scripts. „link.relink(dieselbeDatei)“ sieht naheliegend aus,
// bringt aber nichts: InDesign erkennt, dass sich die Datei nicht geändert
// hat, und lässt die alten Importoptionen stehen. Was wirkt, ist ein
// erneutes place() in den vorhandenen Rahmen — das ersetzt den Inhalt und
// liest die Datei mit den aktuellen Voreinstellungen neu ein.

function prefsSichern() {
    var s = {};
    try { s.pdf = { pageNumber: app.pdfPlacePreferences.pageNumber,
                    pdfCrop: app.pdfPlacePreferences.pdfCrop,
                    transparentBackground: app.pdfPlacePreferences.transparentBackground }; } catch (e) {}
    try { s.indd = { pageNumber: app.importedPageAttributes.pageNumber,
                     importedPageCrop: app.importedPageAttributes.importedPageCrop }; } catch (e) {}
    try { s.io = { applyPhotoshopClippingPath: app.imageIOPreferences.applyPhotoshopClippingPath,
                   alphaChannelName: app.imageIOPreferences.alphaChannelName,
                   previewResolution: app.imageIOPreferences.previewResolution,
                   allowAutoEmbedding: app.imageIOPreferences.allowAutoEmbedding }; } catch (e) {}
    return s;
}

function prefsZuruecksetzen(s) {
    try { if (s.pdf)  app.pdfPlacePreferences.properties  = s.pdf;  } catch (e) {}
    try { if (s.indd) app.importedPageAttributes.properties = s.indd; } catch (e) {}
    try { if (s.io)   app.imageIOPreferences.properties    = s.io;  } catch (e) {}
}

// opt: { seite, crop, transparent, beschnittpfad, alphakanal, vorschau,
//        einpassung, ebenenErhalten }
// Nur gesetzte Felder werden angefasst — was undefined bleibt, bleibt wie es ist.
function neuImportieren(eintrag, opt) {
    var rahmen = eintrag.rahmen;
    if (!rahmen || !rahmen.isValid) return "Rahmen nicht mehr vorhanden";
    if (eintrag.eingebettet)        return "eingebettet — keine Datei zum Neuladen";
    if (eintrag.fehlt)              return "Verknüpfung fehlt";

    var datei = File(eintrag.pfad);
    if (!datei.exists) return "Datei nicht gefunden";

    var g = grafikVon(rahmen);
    if (!g) return "keine Grafik im Rahmen";

    var zustand = zustandSichern(g);
    if (opt.ebenenErhalten === false) zustand.ebenen = null;

    var alt = prefsSichern();
    try {
        // „(unverändert lassen)“ heißt: der BESTEHENDE Wert des Eintrags —
        // nicht die zufällige App-Voreinstellung. place() kennt aber nur die
        // App-Voreinstellungen, deshalb werden Seite, Beschnitt und
        // Hintergrund hier immer ausdrücklich vorgegeben: aus opt, und wo
        // opt schweigt, aus dem Eintrag selbst. Sonst springt beim bloßen
        // Seitenwechsel der Beschnitt auf das, was der letzte manuelle
        // Import hinterlassen hat.
        if (eintrag.typ === "InDesign") {
            if      (opt.seite !== undefined) app.importedPageAttributes.pageNumber = opt.seite;
            else if (eintrag.seite)           app.importedPageAttributes.pageNumber = eintrag.seite;
            var ci = cropFuerTyp(opt.crop !== undefined ? opt.crop
                                                        : cropSchluesselVonWert(eintrag.crop), "InDesign");
            if (ci) app.importedPageAttributes.importedPageCrop = CROP_WERT_INDD[ci];
        } else {
            if      (opt.seite !== undefined) app.pdfPlacePreferences.pageNumber = opt.seite;
            else if (eintrag.seite)           app.pdfPlacePreferences.pageNumber = eintrag.seite;
            var cp = cropFuerTyp(opt.crop !== undefined ? opt.crop
                                                        : cropSchluesselVonWert(eintrag.crop), "PDF");
            if (cp) app.pdfPlacePreferences.pdfCrop = CROP_WERT[cp];
            if      (opt.transparent !== undefined)
                app.pdfPlacePreferences.transparentBackground = opt.transparent;
            else if (eintrag.transparent === true || eintrag.transparent === false)
                app.pdfPlacePreferences.transparentBackground = eintrag.transparent;
        }
        // place() liest die Datei mit den App-Voreinstellungen — was die
        // Aktion nicht selbst vorgibt, kommt aus dem gesicherten Zustand.
        // Sonst verliert ein PSD beim bloßen Ebenen- oder Seitenwechsel
        // still seinen Alphakanal und den Beschnittpfad.
        if      (opt.beschnittpfad !== undefined) app.imageIOPreferences.applyPhotoshopClippingPath = opt.beschnittpfad;
        else if (zustand.io)                      app.imageIOPreferences.applyPhotoshopClippingPath = zustand.io.applyPhotoshopClippingPath;
        if      (opt.alphakanal !== undefined)    app.imageIOPreferences.alphaChannelName = opt.alphakanal;
        else if (zustand.io)                      app.imageIOPreferences.alphaChannelName = zustand.io.alphaChannelName;

        rahmen.place(datei);
    } catch (e) {
        prefsZuruecksetzen(alt);
        return String(e.message || e);
    }
    prefsZuruecksetzen(alt);

    zustandWiederherstellen(rahmen, zustand, opt.einpassung);
    if (opt.beschnittpfadName) beschnittpfadSetzen(rahmen, opt.beschnittpfadName);
    // Nur wenn die Aktion den Pfad gar nicht angefasst hat, den bisherigen
    // zurückholen — „(keiner)“ (beschnittpfad === false) soll ihn ja entfernen.
    else if (opt.beschnittpfad === undefined && zustand.pfadAktiv)
        beschnittpfadSetzen(rahmen, zustand.pfadAktiv);
    return null;                                     // null = alles gut
}

// WELCHER Photoshop-Pfad gilt, steht nicht in den Importvoreinstellungen
// (dort gibt es nur das Ja/Nein von applyPhotoshopClippingPath), sondern am
// clippingPath der Grafik — deshalb nach dem Import direkt dort setzen.
function beschnittpfadSetzen(rahmen, name) {
    try {
        var g = grafikVon(rahmen);
        if (!g) return false;
        g.clippingPath.clippingType = CLIP_WERT.PHOTOSHOP_PATH;
        g.clippingPath.appliedPathName = name;
        return true;
    } catch (e) { return false; }
}

// Die Gegenrichtung zu beschnittpfadSetzen: „(keiner)“ muss den Pfad auch
// am Objekt wieder wegnehmen — sonst bleibt der Zuschnitt sichtbar stehen
// und der Dropdown springt beim nächsten Befüllen auf den Pfad zurück.
// Nur Photoshop-Pfade anfassen: ein von Hand erzeugter Beschnittpfad
// (Kanten erkennen) bleibt unberührt.
function beschnittpfadEntfernen(rahmen) {
    try {
        var g = grafikVon(rahmen);
        if (!g) return false;
        if (g.clippingPath.clippingType === CLIP_WERT.PHOTOSHOP_PATH)
            g.clippingPath.clippingType = CLIP_WERT.NONE;
        return true;
    } catch (e) { return false; }
}

// Bild-Importoptionen ohne Neu-Import: die stehen am Objekt und lassen sich
// direkt setzen. Beim nächsten Aktualisieren der Verknüpfung greifen sie.
function bildOptionenDirekt(eintrag, opt) {
    var g = grafikVon(eintrag.rahmen);
    if (!g) return "keine Grafik im Rahmen";
    try {
        var io = g.imageIOPreferences;
        if (opt.beschnittpfad !== undefined) io.applyPhotoshopClippingPath = opt.beschnittpfad;
        if (opt.alphakanal    !== undefined) io.alphaChannelName = opt.alphakanal;
        if (opt.beschnittpfadName)               beschnittpfadSetzen(eintrag.rahmen, opt.beschnittpfadName);
        else if (opt.beschnittpfad === false)    beschnittpfadEntfernen(eintrag.rahmen);
        return null;
    } catch (e) { return String(e.message || e); }
}

// Pfad- und Kanalnamen der Datei, dazu was aktuell angewendet ist — die
// Grundlage für die Dropdowns im Bild-Reiter (kein Freitext, kein Tippfehler).
function pfadNamen(e) {
    var res = { pfade: [], alphas: [], pfadAktiv: "", alphaAktiv: "" };
    try {
        var g = grafikVon(e.rahmen);
        if (!g) return res;
        var cp = g.clippingPath;
        res.pfade  = cp.photoshopPathNames    || [];
        res.alphas = cp.alphaChannelPathNames || [];
        if (cp.clippingType === CLIP_WERT.PHOTOSHOP_PATH) res.pfadAktiv = String(cp.appliedPathName);
    } catch (er) {}
    try { res.alphaAktiv = String(grafikVon(e.rahmen).imageIOPreferences.alphaChannelName); } catch (er) {}
    return res;
}

// Bei mehreren markierten Bildern zählt nur, was in ALLEN Dateien existiert.
function schnittmenge(a, b) {
    var res = [];
    for (var i = 0; i < a.length; i++)
        for (var j = 0; j < b.length; j++)
            if (String(a[i]) === String(b[j])) { res.push(String(a[i])); break; }
    return res;
}

// ---------------------------------------------------------------------------
// Alles in einen einzigen Rückgängig-Schritt packen. Ohne das hinterlässt
// jede Änderung mehrere Einträge im Bearbeiten-Menü, weil place() intern
// bereits mehrere Schritte auslöst.
var arbeitet = false;                    // hält den Auswahl-Zuhörer still

function mitUndo(name, fn) {
    arbeitet = true;
    try {
        return app.doScript(fn, ScriptLanguage.JAVASCRIPT, undefined,
                            UndoModes.ENTIRE_SCRIPT, name);
    } catch (e) {
        // Wenn doScript den Rückgängig-Kontext nicht aufbauen kann, ist die
        // Arbeit wichtiger als der saubere Undo-Eintrag.
        return fn();
    } finally {
        arbeitet = false;
    }
}

// ============================================================================
//  Oberfläche
// ============================================================================

var eintraege = [];          // alle gefundenen Platzierungen
var stumm = false;           // verhindert Rückkopplung beim Neubefüllen

// Immer in der Reihenfolge der Liste, nicht in der Reihenfolge, in der
// angeklickt wurde — sonst verteilt „Seiten verteilen“ nach Klickreihenfolge.
function markierte() {
    var res = [];
    if (!liste) return res;
    for (var i = 0; i < liste.items.length; i++)
        if (liste.items[i].selected && liste.items[i].eintrag) res.push(liste.items[i].eintrag);
    return res;
}

// Bei einer Mehrfachauswahl-Liste ergänzt eine Zuweisung die bestehende
// Auswahl, statt sie zu ersetzen — deshalb vorher leeren.
function markiereIndizes(indizes) {
    stumm = true;
    liste.selection = null;
    if (indizes && indizes.length) liste.selection = indizes;
    stumm = false;
    felderFuellen();
}

function status(txt) { statusText.text = txt; statusText.parent.layout.layout(true); }

// Platzierte InDesign-Dateien melden ihren Beschnitt in PDFCrop-Werten
// zurück, obwohl er über ImportedPageCropOptions gesetzt wird — deshalb
// beide Tabellen abklopfen.
function beschnittName(e) {
    if (e.crop === null || e.crop === undefined) return "—";
    for (var i = 0; i < CROPS.length; i++)
        if (CROP_WERT[CROPS[i][1]] === e.crop) return CROPS[i][0];
    for (var i = 0; i < CROPS_INDD.length; i++)
        if (CROP_WERT_INDD[CROPS_INDD[i][1]] === e.crop) return CROPS_INDD[i][0];
    return "—";
}

// Ausreißer auf einen Blick: ⚠ fehlt oder beim letzten Lauf übersprungen,
// 📎 eingebettet, ✓ in Ordnung.
function symbolFuer(e) {
    if (e.fehlt || e.warnung) return "⚠";
    if (e.eingebettet) return "📎";
    return "✓";
}

function zeileText(e) {
    return [ symbolFuer(e),
             e.dateiname,
             e.typ,
             e.seite ? String(e.seite) : "—",
             beschnittName(e),
             e.ebenen ? String(e.ebenen) : "—",
             e.dokSeite ];
}

function listeFuellen(bereich) {
    var doc = app.documents.length ? app.activeDocument : null;
    if (!doc) { eintraege = []; liste.removeAll(); status("Kein Dokument geöffnet."); return; }

    // Die Markierung soll das Neubefüllen überleben — wer bei „der Auswahl
    // folgen“ kurz ins Layout klickt oder „Aktualisieren“ drückt, verliert
    // sonst seine Mehrfachmarkierung. Stabiler Anker ist die Rahmen-ID; die
    // Eintrags-Objekte selbst werden ja neu gebaut.
    var alteIds = {};
    for (var i = 0; i < liste.items.length; i++) {
        var alt = liste.items[i];
        if (alt.selected && alt.eintrag) {
            try { alteIds[alt.eintrag.rahmen.id] = true; } catch (er) {}
        }
    }

    stumm = true;
    liste.removeAll();
    eintraege = sammle(bereich, doc);
    var wieder = [];
    for (var i = 0; i < eintraege.length; i++) {
        var e = eintraege[i];
        var t = zeileText(e);
        var it = liste.add("item", t[0]);
        for (var c = 1; c < t.length; c++) it.subItems[c - 1].text = t[c];
        it.eintrag = e;
        try { if (alteIds[e.rahmen.id]) wieder.push(i); } catch (er) {}
    }
    stumm = false;

    if (wieder.length) {
        markiereIndizes(wieder);
    } else if (liste.items.length) {
        markiereIndizes([0]);
    } else {
        felderFuellen();
    }
    status(eintraege.length + " Platzierung" + (eintraege.length === 1 ? "" : "en") +
           (bereich === "auswahl" ? " in der Auswahl." : " im Dokument."));
}

function zeileAktualisieren(e) {
    for (var i = 0; i < liste.items.length; i++) {
        if (liste.items[i].eintrag === e) {
            var neu = EintragAus(grafikVon(e.rahmen));
            if (neu) {
                neu.dokSeite = e.dokSeite;
                neu.warnung  = e.warnung;        // ⚠ vom letzten Lauf behalten
                liste.items[i].eintrag = neu;
                for (var k in neu) if (neu.hasOwnProperty(k)) e[k] = neu[k];
            }
            var t = zeileText(liste.items[i].eintrag);
            liste.items[i].text = t[0];
            for (var c = 1; c < t.length; c++) liste.items[i].subItems[c - 1].text = t[c];
            return;
        }
    }
}

// ---------------------------------------------------------------- Felder füllen
// Der erste markierte Eintrag, auf den die Prüfung zutrifft. Die Reiter
// richten sich danach, was in der Markierung VORKOMMT — nicht danach, was
// zufällig obenauf liegt. Sonst ist bei gemischter Auswahl (ein Bild zuerst,
// darunter PDFs) der Seiten-Reiter tot.
function ersterMit(pruefung) {
    var m = markierte();
    for (var i = 0; i < m.length; i++) if (pruefung(m[i])) return m[i];
    return null;
}

function felderFuellen() {
    var eSeite = ersterMit(function (x) {
        return (x.typ === "PDF" || x.typ === "InDesign") && !x.eingebettet && !x.fehlt;
    });
    var eBild   = ersterMit(function (x) { return x.typ === "Bild"; });
    var eEbenen = ersterMit(function (x) { return x.ebenen > 0; });

    // ---- Seiten & Beschnitt
    tabSeiten.enabled = !!eSeite;
    if (eSeite) {
        var e = eSeite;
        cropListe = (e.typ === "InDesign") ? CROPS_INDD : CROPS;
        stumm = true;
        ddCrop.removeAll();
        // Der erste Eintrag lässt den Beschnitt in Ruhe — so überschreibt
        // eine Batch-Aktion („nur die Seite wechseln“) nicht ungefragt
        // abweichende Beschnitte. Was aktuell gilt, zeigt die Spalte
        // „Beschnitt“ in der Liste.
        ddCrop.add("item", "(unverändert lassen)");
        for (var i = 0; i < cropListe.length; i++) ddCrop.add("item", cropListe[i][0]);
        ddCrop.selection = 0;
        txtSeite.text = String(e.seite || 1);
        var ges = (e.typ === "PDF" && e.pfad) ? pdfSeitenzahl(e.pfad) : 0;
        lblVon.text = ges ? "von " + ges : "";
        gesamtSeiten = ges;
        // Der Hintergrund gilt nur für PDFs — aber nicht nur dann, wenn
        // zufällig ein PDF obenauf liegt: sobald IRGENDEIN markiertes PDF
        // dabei ist, bleibt der Dropdown bedienbar (INDD-Einträge ignorieren
        // ihn beim Anwenden ohnehin).
        ddTransparent.enabled = !!ersterMit(function (x) {
            return x.typ === "PDF" && !x.eingebettet && !x.fehlt;
        });
        ddTransparent.selection = 0;
        stumm = false;
    }

    // ---- Ebenen
    tabEbenen.enabled = !!eEbenen;
    ebenenFuellen();

    // ---- Bild
    tabBild.enabled = !!eBild;
    if (eBild) {
        stumm = true;
        // Pfad- und Kanalnamen kommen aus der Datei selbst — bei mehreren
        // markierten Bildern zählt die Schnittmenge, damit die Auswahl in
        // jeder Datei existiert.
        var m2 = markierte(), bilder = [];
        for (var i = 0; i < m2.length; i++) if (m2[i].typ === "Bild") bilder.push(m2[i]);
        var pfade = null, alphas = null, info0 = null;
        for (var i = 0; i < bilder.length; i++) {
            var info = pfadNamen(bilder[i]);
            if (!info0) info0 = info;
            pfade  = (pfade  === null) ? info.pfade  : schnittmenge(pfade,  info.pfade);
            alphas = (alphas === null) ? info.alphas : schnittmenge(alphas, info.alphas);
        }
        ddBeschnitt.removeAll();
        ddBeschnitt.add("item", "(keiner)");
        if (pfade) for (var i = 0; i < pfade.length; i++) ddBeschnitt.add("item", pfade[i]);
        ddBeschnitt.selection = 0;
        if (info0 && info0.pfadAktiv)
            for (var i = 1; i < ddBeschnitt.items.length; i++)
                if (ddBeschnitt.items[i].text === info0.pfadAktiv) { ddBeschnitt.selection = i; break; }
        ddAlpha.removeAll();
        ddAlpha.add("item", "(keiner)");
        if (alphas) for (var i = 0; i < alphas.length; i++) ddAlpha.add("item", alphas[i]);
        ddAlpha.selection = 0;
        if (info0 && info0.alphaAktiv)
            for (var i = 1; i < ddAlpha.items.length; i++)
                if (ddAlpha.items[i].text === info0.alphaAktiv) { ddAlpha.selection = i; break; }
        try { txtVorschau.text = String(grafikVon(eBild.rahmen).imageIOPreferences.previewResolution); } catch (er) {}
        stumm = false;
    }

    var n = markierte().length;
    lblZiel.text = n ? (n === 1 ? "Ziel: 1 Platzierung" : "Ziel: " + n + " Platzierungen") : "Nichts markiert";
}

// Die Ebenenliste bündelt ALLE markierten Platzierungen: sind fünf Vorkommen
// derselben PSD markiert und die Ebene ist nur in dreien sichtbar, steht dort
// „3/5“ statt eines falschen ☑. Ein Klick auf so einen Mischzustand
// vereinheitlicht auf sichtbar; ☑/☐ schalten wie gewohnt um.
function ebenenFuellen() {
    stumm = true;
    ebListe.removeAll();
    aktuelleEbenen = [];
    var m = markierte(), reihenfolge = [], proName = {}, erster = null;
    for (var i = 0; i < m.length; i++) {
        var ll = ebenenListe(m[i].rahmen);
        if (!ll.length) continue;
        if (!erster) erster = m[i];
        for (var j = 0; j < ll.length; j++) {
            var l = ll[j];
            if (!proName[l.name]) {
                proName[l.name] = { name: l.name, sichtbar: 0, vorkommen: 0, gesperrt: false };
                reihenfolge.push(l.name);
            }
            proName[l.name].vorkommen++;
            if (l.sichtbar) proName[l.name].sichtbar++;
            if (l.gesperrt) proName[l.name].gesperrt = true;
        }
    }
    for (var i = 0; i < reihenfolge.length; i++) {
        var l = proName[reihenfolge[i]];
        aktuelleEbenen.push(l);
        var zeichen = (l.sichtbar === l.vorkommen) ? "☑"
                    : (l.sichtbar === 0)           ? "☐"
                    : l.sichtbar + "/" + l.vorkommen;
        var it = ebListe.add("item", zeichen);
        it.subItems[0].text = l.name + (l.gesperrt ? "  (gesperrt)" : "");
        it.ebene = l;
    }
    if (erster) {
        try { ddUpdate.selection =
              (grafikVon(erster.rahmen).graphicLayerOptions.updateLinkOption === UPDATE_BEIBEHALTEN) ? 0 : 1; }
        catch (er) {}
    }
    stumm = false;
}

// ============================================================================
//  Aktionen
// ============================================================================

function ganzeZahl(txt, standard) {
    var n = parseInt(String(txt).replace(/[^\d\-]/g, ""), 10);
    return isNaN(n) ? standard : n;
}

function begrenzen(n, max) {
    if (n < 1) n = 1;
    if (max && n > max) n = max;
    return n;
}

// Eintrag 0 ist „(unverändert lassen)“ — dann bleibt der Beschnitt unangetastet.
function cropSchluessel() {
    if (!cropListe || !ddCrop.selection || ddCrop.selection.index === 0) return undefined;
    return cropListe[ddCrop.selection.index - 1][1];
}

// unverändert / transparent / deckend — undefined heißt: nicht anfassen.
function transparentWert() {
    if (!ddTransparent.enabled || !ddTransparent.selection) return undefined;
    if (ddTransparent.selection.index === 1) return true;
    if (ddTransparent.selection.index === 2) return false;
    return undefined;
}

function einpassungSchluessel() {
    return EINPASSUNG[ddEinpassung.selection.index][1];
}

// ------------------------------------------------------------- Fortschritt
// Bei großen Läufen tickert nicht nur die Statuszeile: der Balken samt
// Dateiname zeigt, dass InDesign arbeitet und nicht hängt.
function fortschrittStart(max) {
    if (max <= 4) return;
    pbFortschritt.maxvalue = max;
    pbFortschritt.value = 0;
    pbFortschritt.visible = true;
    lblFortschritt.visible = true;
}

function fortschrittSchritt(wert, max, name) {
    if (max <= 4) return;
    pbFortschritt.value = wert;
    lblFortschritt.text = wert + "/" + max + "  " + name;
    w.update();
}

function fortschrittEnde() {
    pbFortschritt.visible = false;
    lblFortschritt.visible = false;
    lblFortschritt.text = "";
}

// ------------------------------------------------------------------ Fehler
// Die Statuszeile fasst nur zusammen — die komplette Liste der
// übersprungenen Platzierungen hält letzteFehler fest, „Details …“ zeigt sie.
function fehlerHinweis() {
    btnDetails.enabled = (letzteFehler.length > 0);
    if (!letzteFehler.length) return ".";
    return ", " + letzteFehler.length + " übersprungen — „Details …“ zeigt alle.";
}

function fehlerZeigen() {
    if (!letzteFehler.length) { status("Keine Fehler beim letzten Lauf."); return; }
    // Ein Dialog ist hier unbedenklich: er ändert nichts am Dokument,
    // sondern zeigt nur Text an.
    var d = new Window("dialog", "Übersprungene Platzierungen");
    d.orientation = "column";
    d.alignChildren = ["fill", "top"];
    d.margins = 12;
    var t = d.add("edittext", undefined, letzteFehler.join("\n"),
                  { multiline: true, scrolling: true, readonly: true });
    t.preferredSize = [460, 220];
    d.add("button", undefined, "Schließen", { name: "ok" });
    d.show();
}

// Wendet Importoptionen auf alle markierten Platzierungen an.
// seitenFn liefert je Eintrag die gewünschte Seite (oder undefined).
function anwenden(titel, seitenFn, mitCrop) {
    var ziele = markierte();
    if (!ziele.length) { status("Nichts markiert."); return; }

    letzteFehler = [];
    var geaendert = 0, unveraendert = 0;
    fortschrittStart(ziele.length);
    mitUndo(titel, function () {
        for (var i = 0; i < ziele.length; i++) {
            var e = ziele[i];
            // Vor der Arbeit melden — so tickt der Balken auch bei
            // übersprungenen Zeilen weiter und friert nicht scheinbar ein.
            fortschrittSchritt(i + 1, ziele.length, e.dateiname);
            if (e.typ !== "PDF" && e.typ !== "InDesign") continue;
            if (e.eingebettet || e.fehlt) {
                letzteFehler.push(e.dateiname + ": " + (e.fehlt ? "Verknüpfung fehlt" : "eingebettet"));
                e.warnung = true;
                zeileAktualisieren(e);
                continue;
            }

            var opt = { einpassung: einpassungSchluessel(), ebenenErhalten: true };
            var s = seitenFn ? seitenFn(e) : undefined;
            if (s !== undefined) opt.seite = begrenzen(s, e.typ === "PDF" ? pdfSeitenzahl(e.pfad) : 0);
            if (mitCrop) {
                opt.crop = cropSchluessel();
                if (e.typ === "PDF") opt.transparent = transparentWert();
            }
            // Alles auf „(unverändert lassen)“ und keine Seite? Dann gibt es
            // nichts neu einzulesen — die Zeile zählt auch nicht als geändert.
            if (opt.seite === undefined && opt.crop === undefined && opt.transparent === undefined) {
                unveraendert++;
                continue;
            }

            var f = neuImportieren(e, opt);
            if (f) { letzteFehler.push(e.dateiname + ": " + f); e.warnung = true; }
            else   { geaendert++; e.warnung = false; }
            zeileAktualisieren(e);
        }
    });
    fortschrittEnde();

    felderFuellen();
    status(geaendert + " geändert" +
           (unveraendert ? ", " + unveraendert + " unverändert" : "") +
           fehlerHinweis());
}

function blaettern(delta) {
    anwenden(delta > 0 ? "Seite vor" : "Seite zurück",
             function (e) { return (e.seite || 1) + delta; }, false);
}

function seiteSetzen() {
    var s = ganzeZahl(txtSeite.text, 1);
    anwenden("Seite setzen", function () { return s; }, false);
}

// „2, 5, 8-12“ → [2, 5, 8, 9, 10, 11, 12]. Absteigende Bereiche („12-8“)
// zählen rückwärts, Unlesbares wird übergangen.
function seitenlisteParsen(txt) {
    var res = [];
    // „8 - 12“ mit Leerzeichen um den Strich soll wie „8-12“ zählen — das
    // Aufteilen an Leerraum würde den Bereich sonst in Einzelseiten zerlegen.
    var teile = String(txt || "").replace(/\s*([-–])\s*/g, "$1").split(/[,;\s]+/);
    for (var i = 0; i < teile.length; i++) {
        var teil = teile[i];
        if (!teil) continue;
        var m = teil.match(/^(\d+)\s*[-–]\s*(\d+)$/);
        if (m) {
            var a = parseInt(m[1], 10), b = parseInt(m[2], 10);
            if (a <= b) { for (var n = a; n <= b; n++) res.push(n); }
            else        { for (var n = a; n >= b; n--) res.push(n); }
        } else {
            var z = parseInt(teil, 10);
            if (!isNaN(z) && z >= 1) res.push(z);
        }
    }
    return res;
}

// Liefert die Funktion, die je Ziel die nächste Seite ausgibt — entweder aus
// der Seitenliste (zyklisch wiederholt, wenn mehr Rahmen als Seiten markiert
// sind) oder klassisch ab Startseite mit Schrittweite.
function verteilFolge() {
    var folge   = seitenlisteParsen(txtSeitenliste.text);
    var start   = ganzeZahl(txtStart.text, 1);
    var schritt = ganzeZahl(txtSchritt.text, 1);
    var lauf = { i: 0 };
    return function () {
        var s = folge.length ? folge[lauf.i % folge.length] : start + lauf.i * schritt;
        lauf.i++;
        return s;
    };
}

function verteilen() {
    if (!markierte().length) { status("Nichts markiert."); return; }
    anwenden("Seiten fortlaufend verteilen", verteilFolge(), false);
}

// Trockenlauf: schreibt die geplanten Seiten nur in die Seiten-Spalte der
// Liste („3 → 7“), ohne place() auszulösen — erst „Verteilen“ macht ernst.
// Übersprungen wird genau, was auch anwenden() überspringen würde.
function vorschauVerteilen() {
    if (!markierte().length) { status("Nichts markiert."); return; }
    var naechste = verteilFolge();
    var geplant = 0;
    for (var i = 0; i < liste.items.length; i++) {
        var it = liste.items[i];
        if (!it.selected || !it.eintrag) continue;
        var e = it.eintrag;
        if (e.typ !== "PDF" && e.typ !== "InDesign") continue;
        if (e.eingebettet || e.fehlt) continue;
        var s = begrenzen(naechste(), e.typ === "PDF" ? pdfSeitenzahl(e.pfad) : 0);
        it.subItems[2].text = (e.seite || 1) + " → " + s;
        geplant++;
    }
    status(geplant ? "Vorschau: " + geplant + " Seitenzuordnung(en) geplant — „Verteilen“ wendet an, „Aktualisieren“ verwirft."
                   : "Nichts zu verteilen in der Markierung.");
}

// ------------------------------------------------------------ Datei tauschen
// Der klassische Nachbarfall: das Korrektur-PDF kommt in Version 2, aber
// Seite, Beschnitt, Transparenz und Ebenensichtbarkeit sollen bleiben.
// Funktioniert auch bei „Verknüpfung fehlt“ — statt die Zeile nur zu
// überspringen, bekommt sie hier direkt eine neue Datei.
function dateiTauschen() {
    var ziele = markierte();
    if (!ziele.length) { status("Nichts markiert."); return; }
    var datei = File.openDialog("Neue Datei für " + ziele.length + " Platzierung" +
                                (ziele.length === 1 ? "" : "en") + " wählen");
    if (!datei) return;
    var neuerTyp  = typVon(null, datei.fsName);
    var seitenNeu = (neuerTyp === "PDF") ? pdfSeitenzahl(datei.fsName) : 0;

    letzteFehler = [];
    var n = 0;
    fortschrittStart(ziele.length);
    mitUndo("Datei tauschen", function () {
        for (var i = 0; i < ziele.length; i++) {
            var e = ziele[i];
            fortschrittSchritt(i + 1, ziele.length, e.dateiname);
            if (!e.rahmen || !e.rahmen.isValid) { letzteFehler.push(e.dateiname + ": Rahmen nicht mehr vorhanden"); continue; }
            var g = grafikVon(e.rahmen);
            if (!g) { letzteFehler.push(e.dateiname + ": keine Grafik im Rahmen"); continue; }

            var zustand = zustandSichern(g);
            var alt = prefsSichern();
            try {
                // Der gemerkte Beschnitt liegt in PDFCrop-Werten vor (auch
                // bei platzierten InDesign-Dateien) — für das Ziel jeweils
                // in die eigene Tabelle übersetzen, sonst schluckt InDesign
                // die Zuweisung eines fremden Werts kommentarlos.
                var cropAlt = cropSchluesselVonWert(e.crop);
                if (neuerTyp === "InDesign") {
                    if (e.seite) app.importedPageAttributes.pageNumber = e.seite;
                    var ci = cropFuerTyp(cropAlt, "InDesign");
                    if (ci) { try { app.importedPageAttributes.importedPageCrop = CROP_WERT_INDD[ci]; } catch (er2) {} }
                } else if (neuerTyp === "PDF") {
                    if (e.seite) app.pdfPlacePreferences.pageNumber = begrenzen(e.seite, seitenNeu);
                    var cp = cropFuerTyp(cropAlt, "PDF");
                    if (cp) { try { app.pdfPlacePreferences.pdfCrop = CROP_WERT[cp]; } catch (er2) {} }
                    try { if (e.transparent !== null) app.pdfPlacePreferences.transparentBackground = e.transparent; } catch (er2) {}
                }
                // Bild-Importoptionen (Alphakanal, Beschnittpfad) übernimmt
                // place() nicht von selbst — ohne Vorgabe gälten die
                // zufälligen App-Voreinstellungen.
                if (zustand.io) {
                    try { app.imageIOPreferences.applyPhotoshopClippingPath = zustand.io.applyPhotoshopClippingPath; } catch (er2) {}
                    try { app.imageIOPreferences.alphaChannelName = zustand.io.alphaChannelName; } catch (er2) {}
                }
                e.rahmen.place(datei);
                prefsZuruecksetzen(alt);
                zustandWiederherstellen(e.rahmen, zustand, einpassungSchluessel());
                if (zustand.pfadAktiv) beschnittpfadSetzen(e.rahmen, zustand.pfadAktiv);
                e.warnung = false;
                n++;
            } catch (er) {
                prefsZuruecksetzen(alt);
                letzteFehler.push(e.dateiname + ": " + String(er.message || er));
                e.warnung = true;
            }
            zeileAktualisieren(e);
        }
    });
    fortschrittEnde();
    felderFuellen();
    status(n + " Platzierung" + (n === 1 ? "" : "en") + " auf „" + datei.displayName + "“ getauscht" + fehlerHinweis());
}

// ------------------------------------------------------------------- Ebenen
// Wirkt auf alle markierten Platzierungen, die eine Ebene dieses Namens
// haben — genau das, was InDesigns eigener Dialog nicht kann.
function ebeneSchalten(name, sichtbar) {
    var ziele = markierte();
    if (!ziele.length) return;
    var n = 0;
    mitUndo("Ebene " + (sichtbar ? "einblenden" : "ausblenden"), function () {
        for (var i = 0; i < ziele.length; i++) {
            if (setzeEbeneNachName(ziele[i].rahmen, name, sichtbar)) n++;
            zeileAktualisieren(ziele[i]);
        }
    });
    status("„" + name + "“ " + (sichtbar ? "eingeblendet" : "ausgeblendet") +
           " in " + n + " Platzierung" + (n === 1 ? "" : "en") + ".");
}

function alleEbenen(wert) {
    var ziele = markierte();
    if (!ziele.length || !aktuelleEbenen.length) return;
    mitUndo("Alle Ebenen " + (wert ? "einblenden" : "ausblenden"), function () {
        for (var i = 0; i < ziele.length; i++) {
            var namen = ebenenListe(ziele[i].rahmen);
            for (var j = 0; j < namen.length; j++) {
                var soll = (wert === "umkehren") ? !namen[j].sichtbar : wert;
                setzeEbeneNachName(ziele[i].rahmen, namen[j].name, soll);
            }
            zeileAktualisieren(ziele[i]);
        }
    });
    ebenenFuellen();
    status("Ebenen aktualisiert.");
}

// Den Ebenenzustand der ersten Markierung auf jedes weitere Vorkommen
// derselben Datei im Dokument übertragen.
function ebenenUebertragen() {
    var m = markierte();
    if (!m.length) { status("Nichts markiert."); return; }
    var quelle = m[0];
    var soll = ebenenListe(quelle.rahmen);
    if (!soll.length) { status("Diese Grafik hat keine Ebenen."); return; }

    var doc = app.activeDocument;
    var alle = sammle("dokument", doc);
    var n = 0;
    mitUndo("Ebenensichtbarkeit übertragen", function () {
        for (var i = 0; i < alle.length; i++) {
            var e = alle[i];
            if (e.rahmen === quelle.rahmen) continue;
            if (e.eingebettet || e.pfad !== quelle.pfad) continue;
            for (var j = 0; j < soll.length; j++) setzeEbeneNachName(e.rahmen, soll[j].name, soll[j].sichtbar);
            n++;
        }
    });
    status(n + " weitere Platzierung" + (n === 1 ? "" : "en") + " von „" + quelle.dateiname + "“ angeglichen.");
}

function updateOptionSetzen() {
    var ziele = markierte();
    if (!ziele.length) return;
    var wert = (ddUpdate.selection.index === 0) ? UPDATE_BEIBEHALTEN : UPDATE_AUS_DATEI;
    mitUndo("Verhalten beim Aktualisieren", function () {
        for (var i = 0; i < ziele.length; i++) {
            try { grafikVon(ziele[i].rahmen).graphicLayerOptions.updateLinkOption = wert; } catch (e) {}
        }
    });
    status("Verhalten beim Aktualisieren gesetzt.");
}

// -------------------------------------------------------------------- Bild
function bildAnwenden(neuLaden) {
    var ziele = markierte();
    if (!ziele.length) { status("Nichts markiert."); return; }
    var pfadName  = (ddBeschnitt.selection && ddBeschnitt.selection.index > 0) ? ddBeschnitt.selection.text : "";
    var alphaName = (ddAlpha.selection     && ddAlpha.selection.index > 0)     ? ddAlpha.selection.text     : "";
    var opt = { beschnittpfad: !!pfadName,
                beschnittpfadName: pfadName || undefined,
                alphakanal: alphaName,
                einpassung: einpassungSchluessel(),
                ebenenErhalten: true };
    letzteFehler = [];
    var n = 0;
    fortschrittStart(ziele.length);
    mitUndo("Bild-Importoptionen", function () {
        for (var i = 0; i < ziele.length; i++) {
            fortschrittSchritt(i + 1, ziele.length, ziele[i].dateiname);
            if (ziele[i].typ !== "Bild") continue;
            var f = neuLaden ? neuImportieren(ziele[i], opt) : bildOptionenDirekt(ziele[i], opt);
            if (f) { letzteFehler.push(ziele[i].dateiname + ": " + f); ziele[i].warnung = true; }
            else   { n++; ziele[i].warnung = false; }
            zeileAktualisieren(ziele[i]);
        }
    });
    fortschrittEnde();
    felderFuellen();
    status(n + " Bild" + (n === 1 ? "" : "er") + " aktualisiert" + fehlerHinweis());
}

// ------------------------------------------------------------------- Zeigen
function imDokumentZeigen() {
    var m = markierte();
    if (!m.length) return;
    try {
        var rahmen = [];
        for (var i = 0; i < m.length; i++) if (m[i].rahmen && m[i].rahmen.isValid) rahmen.push(m[i].rahmen);
        if (!rahmen.length) return;
        app.select(rahmen);
        app.activeWindow.zoom(ZoomOptions.FIT_SPREAD);
        status(rahmen.length + " im Dokument ausgewählt.");
    } catch (e) { status("Konnte nicht auswählen: " + e); }
}

// ============================================================================
//  Fenster
// ============================================================================

var w, liste, statusText, lblZiel, btnDetails;
var tabs, tabSeiten, tabEbenen, tabBild;
var txtSeite, lblVon, ddCrop, ddTransparent, ddEinpassung, txtStart, txtSchritt, txtSeitenliste;
var ebListe, ddUpdate;
var ddBeschnitt, ddAlpha, txtVorschau;
var pbFortschritt, lblFortschritt;
var cbFolgen;
var cropListe = CROPS, gesamtSeiten = 0, aktuelleEbenen = [];
var letzteFehler = [];                     // alle Meldungen des letzten Laufs
var eigeneAuswahl = false;                 // unterdrückt die Rückkopplung

function bereich() { return rbAuswahl.value ? "auswahl" : "dokument"; }
var rbAuswahl, rbDokument;

function fensterBauen() {

    w = new Window("palette", TITEL + "  " + VERSION, undefined, { resizeable: true });
    w.orientation = "column";
    w.alignChildren = ["fill", "top"];
    w.margins = 12;
    w.spacing = 8;

    // ---------------------------------------------------------------- Bereich
    var gTop = w.add("group");
    gTop.alignChildren = ["left", "center"];
    gTop.add("statictext", undefined, "Anzeigen:");
    rbAuswahl  = gTop.add("radiobutton", undefined, "Auswahl");
    rbDokument = gTop.add("radiobutton", undefined, "Ganzes Dokument");
    rbAuswahl.value = true;
    cbFolgen = gTop.add("checkbox", undefined, "der Auswahl folgen");
    cbFolgen.value = true;
    var btnNeu = gTop.add("button", undefined, "Aktualisieren");
    btnNeu.preferredSize.width = 100;

    rbAuswahl.onClick = rbDokument.onClick = function () { listeFuellen(bereich()); };
    btnNeu.onClick = function () { seitenCache = {}; listeFuellen(bereich()); };

    // ----------------------------------------------------------------- Liste
    liste = w.add("listbox", undefined, [], {
        numberOfColumns: 7, showHeaders: true,
        columnTitles: ["", "Datei", "Art", "Seite", "Beschnitt", "Ebenen", "Dok."],
        columnWidths: [26, 185, 70, 48, 110, 48, 40],
        multiselect: true
    });
    liste.preferredSize = [560, 150];
    // Beim Aufziehen des Fensters soll der Platz in Listenzeilen fließen,
    // nicht in Leerraum unter der Liste.
    liste.alignment = ["fill", "fill"];
    liste.maximumSize = [3000, 3000];
    liste.onChange = function () { if (!stumm) felderFuellen(); };
    liste.onDoubleClick = function () {
        eigeneAuswahl = true;
        try { imDokumentZeigen(); } finally { eigeneAuswahl = false; }
    };

    var gListe = w.add("group");
    gListe.alignChildren = ["left", "center"];
    var btnZeigen = gListe.add("button", undefined, "Im Dokument zeigen");
    var btnAlle   = gListe.add("button", undefined, "Alle markieren");
    var btnGleiche = gListe.add("button", undefined, "Gleiche Datei markieren");
    var btnTauschen = gListe.add("button", undefined, "Datei tauschen …");
    lblZiel = gListe.add("statictext", undefined, "Nichts markiert");
    lblZiel.preferredSize.width = 130;

    // Fortschritt bei großen Läufen — unsichtbar, solange nichts läuft.
    var gFortschritt = w.add("group");
    gFortschritt.alignChildren = ["left", "center"];
    pbFortschritt = gFortschritt.add("progressbar", undefined, 0, 100);
    pbFortschritt.preferredSize = [200, 10];
    lblFortschritt = gFortschritt.add("statictext", undefined, "");
    lblFortschritt.preferredSize.width = 330;
    pbFortschritt.visible = false;
    lblFortschritt.visible = false;

    btnZeigen.onClick = function () {
        eigeneAuswahl = true;
        try { imDokumentZeigen(); } finally { eigeneAuswahl = false; }
    };
    btnAlle.onClick = function () {
        var alle = [];
        for (var i = 0; i < liste.items.length; i++) alle.push(i);
        markiereIndizes(alle);
    };
    btnGleiche.onClick = function () {
        var m = markierte();
        if (!m.length) { status("Erst eine Zeile markieren."); return; }
        var pfad = m[0].pfad;
        var treffer = [];
        for (var i = 0; i < liste.items.length; i++)
            if (pfad && liste.items[i].eintrag.pfad === pfad) treffer.push(i);
        if (treffer.length) markiereIndizes(treffer);
        status(treffer.length + " Platzierung(en) derselben Datei markiert.");
    };
    btnTauschen.onClick = function () { dateiTauschen(); };

    // ------------------------------------------------------------------ Tabs
    tabs = w.add("tabbedpanel");
    tabs.alignChildren = ["fill", "top"];
    tabs.preferredSize.height = 255;

    // ---------------------------------------------- Tab 1: Seiten & Beschnitt
    tabSeiten = tabs.add("tab", undefined, "Seite & Beschnitt");
    tabSeiten.orientation = "column";
    tabSeiten.alignChildren = ["fill", "top"];
    tabSeiten.margins = 14;
    tabSeiten.spacing = 9;

    var g1 = tabSeiten.add("group");
    g1.add("statictext", undefined, "Seite:").preferredSize.width = 105;
    var btnZurueck = g1.add("button", undefined, "◀");
    btnZurueck.preferredSize = [34, 22];
    txtSeite = g1.add("edittext", undefined, "1");
    txtSeite.preferredSize.width = 55;
    var btnVor = g1.add("button", undefined, "▶");
    btnVor.preferredSize = [34, 22];
    lblVon = g1.add("statictext", undefined, "               ");
    lblVon.preferredSize.width = 90;
    var btnSeite = g1.add("button", undefined, "Seite setzen");

    var g2 = tabSeiten.add("group");
    g2.add("statictext", undefined, "Zuschneiden auf:").preferredSize.width = 105;
    ddCrop = g2.add("dropdownlist", undefined, []);
    ddCrop.preferredSize.width = 200;
    g2.add("statictext", undefined, "Hintergrund:");
    // Drei Stellungen statt Häkchen: „(unverändert lassen)“ macht
    // Batch-Aktionen gefahrlos — sonst stempelt der Zustand des ersten
    // Eintrags alle anderen ab.
    ddTransparent = g2.add("dropdownlist", undefined,
        ["(unverändert lassen)", "transparent", "deckend"]);
    ddTransparent.selection = 0;
    ddTransparent.preferredSize.width = 150;

    var g3 = tabSeiten.add("group");
    g3.add("statictext", undefined, "Nach dem Ändern:").preferredSize.width = 105;
    var einNamen = [];
    for (var i = 0; i < EINPASSUNG.length; i++) einNamen.push(EINPASSUNG[i][0]);
    ddEinpassung = g3.add("dropdownlist", undefined, einNamen);
    ddEinpassung.selection = 0;
    ddEinpassung.preferredSize.width = 230;

    var g4 = tabSeiten.add("group");
    g4.alignment = ["right", "top"];
    var btnAnwenden = g4.add("button", undefined, "Beschnitt & Seite anwenden");

    var pnl = tabSeiten.add("panel", undefined, "Seiten fortlaufend verteilen");
    pnl.orientation = "column";
    pnl.alignChildren = ["left", "top"];
    pnl.margins = [12, 16, 12, 12];
    pnl.spacing = 6;
    var pnlZ1 = pnl.add("group");
    pnlZ1.alignChildren = ["left", "center"];
    pnlZ1.add("statictext", undefined, "ab Seite");
    txtStart = pnlZ1.add("edittext", undefined, "1");
    txtStart.preferredSize.width = 45;
    pnlZ1.add("statictext", undefined, "Schritt");
    txtSchritt = pnlZ1.add("edittext", undefined, "1");
    txtSchritt.preferredSize.width = 45;
    pnlZ1.add("statictext", undefined, "oder Seitenliste:");
    txtSeitenliste = pnlZ1.add("edittext", undefined, "");
    txtSeitenliste.preferredSize.width = 130;
    txtSeitenliste.helpTip = "z. B. 2, 5, 8-12 — hat Vorrang vor „ab Seite + Schritt“ " +
                             "und wird zyklisch wiederholt, wenn mehr Rahmen markiert sind";
    var pnlZ2 = pnl.add("group");
    pnlZ2.alignChildren = ["left", "center"];
    pnlZ2.add("statictext", undefined, "in der Reihenfolge der Liste");
    var btnVorschau  = pnlZ2.add("button", undefined, "Vorschau");
    var btnVerteilen = pnlZ2.add("button", undefined, "Verteilen");

    btnZurueck.onClick  = function () { blaettern(-1); };
    btnVor.onClick      = function () { blaettern(1); };
    btnSeite.onClick    = function () { seiteSetzen(); };
    btnAnwenden.onClick = function () {
        var s = ganzeZahl(txtSeite.text, 0);
        anwenden("Importoptionen anwenden", s ? function () { return s; } : null, true);
    };
    btnVorschau.onClick  = function () { vorschauVerteilen(); };
    btnVerteilen.onClick = function () { verteilen(); };

    // Enter setzt die Seite sofort, die Pfeiltasten zählen den Wert hoch
    // und runter wie in InDesigns eigenen Feldern.
    txtSeite.addEventListener("keydown", function (ev) {
        if (ev.keyName === "Up" || ev.keyName === "Down") {
            txtSeite.text = String(begrenzen(ganzeZahl(txtSeite.text, 1) +
                                             (ev.keyName === "Up" ? 1 : -1), gesamtSeiten));
            ev.preventDefault();
        } else if (ev.keyName === "Enter") {
            ev.preventDefault();
            seiteSetzen();
        }
    });

    // -------------------------------------------------------- Tab 2: Ebenen
    tabEbenen = tabs.add("tab", undefined, "Ebenen");
    tabEbenen.orientation = "column";
    tabEbenen.alignChildren = ["fill", "top"];
    tabEbenen.margins = 14;
    tabEbenen.spacing = 8;

    var hinweis = tabEbenen.add("statictext", undefined,
        "Klick schaltet um — in allen markierten Platzierungen zugleich. „3/5“ = gemischt, Klick macht sichtbar.");
    hinweis.graphics.font = ScriptUI.newFont(hinweis.graphics.font.name, "italic",
                                             hinweis.graphics.font.size);

    ebListe = tabEbenen.add("listbox", undefined, [], {
        numberOfColumns: 2, showHeaders: true,
        columnTitles: ["Sichtbar", "Ebene"],
        columnWidths: [60, 380]
    });
    ebListe.preferredSize = [500, 105];
    ebListe.onChange = function () {
        if (stumm || !this.selection || !this.selection.ebene) return;
        var l = this.selection.ebene;
        // Mischzustand („3/5“) vereinheitlicht auf sichtbar, sonst umschalten.
        var gemischt = (l.sichtbar > 0 && l.sichtbar < l.vorkommen);
        var neu = gemischt ? true : (l.sichtbar === 0);
        ebeneSchalten(l.name, neu);
        l.sichtbar = neu ? l.vorkommen : 0;
        stumm = true;
        this.selection.text = neu ? "☑" : "☐";
        this.selection = null;               // damit derselbe Klick wieder zündet
        stumm = false;
    };

    var g5 = tabEbenen.add("group");
    g5.alignChildren = ["left", "center"];
    var btnAlleEin = g5.add("button", undefined, "Alle einblenden");
    var btnAlleAus = g5.add("button", undefined, "Alle ausblenden");
    var btnUmkehr  = g5.add("button", undefined, "Umkehren");
    var btnUeber   = g5.add("button", undefined, "Auf gleiche Datei übertragen");

    btnAlleEin.onClick = function () { alleEbenen(true); };
    btnAlleAus.onClick = function () { alleEbenen(false); };
    btnUmkehr.onClick  = function () { alleEbenen("umkehren"); };
    btnUeber.onClick   = function () { ebenenUebertragen(); };

    var g6 = tabEbenen.add("group");
    g6.alignChildren = ["left", "center"];
    g6.add("statictext", undefined, "Beim Aktualisieren der Verknüpfung:");
    ddUpdate = g6.add("dropdownlist", undefined,
        ["Ebeneneinstellung beibehalten", "Ebenensichtbarkeit der Datei verwenden"]);
    ddUpdate.selection = 0;
    ddUpdate.preferredSize.width = 260;
    ddUpdate.onChange = function () { if (!stumm) updateOptionSetzen(); };

    // ---------------------------------------------------------- Tab 3: Bild
    tabBild = tabs.add("tab", undefined, "Bild");
    tabBild.orientation = "column";
    tabBild.alignChildren = ["fill", "top"];
    tabBild.margins = 14;
    tabBild.spacing = 9;

    // Kein Freitext mehr: die Dropdowns führen nur Namen, die es in der
    // Datei wirklich gibt — ein Tippfehler im Kanalnamen scheiterte vorher
    // wortlos. Bei Mehrfachauswahl steht hier die Schnittmenge.
    var g7a = tabBild.add("group");
    g7a.add("statictext", undefined, "Beschnittpfad:").preferredSize.width = 140;
    ddBeschnitt = g7a.add("dropdownlist", undefined, ["(keiner)"]);
    ddBeschnitt.selection = 0;
    ddBeschnitt.preferredSize.width = 200;
    g7a.add("statictext", undefined, "(aus der Datei)");

    var g7 = tabBild.add("group");
    g7.add("statictext", undefined, "Alphakanal:").preferredSize.width = 140;
    ddAlpha = g7.add("dropdownlist", undefined, ["(keiner)"]);
    ddAlpha.selection = 0;
    ddAlpha.preferredSize.width = 200;
    g7.add("statictext", undefined, "(aus der Datei)");

    var g8 = tabBild.add("group");
    g8.add("statictext", undefined, "Vorschauauflösung:").preferredSize.width = 140;
    // Nur zur Kenntnis: InDesign hält diesen Wert schreibgeschützt, weder am
    // Objekt noch in den Voreinstellungen lässt er sich per Script setzen.
    txtVorschau = g8.add("statictext", undefined, "—");
    txtVorschau.preferredSize.width = 60;
    g8.add("statictext", undefined, "ppi  (von InDesign vorgegeben)");

    var g9 = tabBild.add("group");
    g9.alignChildren = ["left", "center"];
    var btnBildSetzen = g9.add("button", undefined, "Einstellen");
    var btnBildNeu    = g9.add("button", undefined, "Einstellen und neu einlesen");

    var hint2 = tabBild.add("statictext", undefined,
        "„Einstellen“ hinterlegt die Werte am Objekt — sichtbar beim nächsten\n" +
        "Aktualisieren der Verknüpfung. „Neu einlesen“ liest die Datei sofort\n" +
        "neu ein und wendet sie an.",
        { multiline: true });
    hint2.preferredSize.height = 46;

    btnBildSetzen.onClick = function () { bildAnwenden(false); };
    btnBildNeu.onClick    = function () { bildAnwenden(true); };

    // ------------------------------------------------------------- Statuszeile
    var gStatus = w.add("group");
    gStatus.alignChildren = ["left", "center"];
    statusText = gStatus.add("statictext", undefined, "");
    statusText.preferredSize.width = 360;
    btnDetails = gStatus.add("button", undefined, "Details …");
    btnDetails.enabled = false;
    btnDetails.helpTip = "Alle übersprungenen Platzierungen des letzten Laufs";
    btnDetails.onClick = function () { fehlerZeigen(); };
    var btnSchliessen = gStatus.add("button", undefined, "Schließen");
    btnSchliessen.alignment = ["right", "center"];
    btnSchliessen.onClick = function () { w.close(); };

    w.onResizing = w.onResize = function () { try { this.layout.resize(); } catch (e) {} };
    w.onClose = function () { fensterMerken(); listenerAbmelden(); return true; };

    return w;
}

// ============================================================================
//  Fenstergröße merken
// ============================================================================
// Position und Größe wandern beim Schließen in eine kleine Datei unter
// Folder.userData und kommen beim nächsten Start zurück.

var EINSTELLUNGS_DATEI = Folder.userData.fsName + "/dwbkd_importoptionen.json";

function fensterMerken() {
    try {
        var f = File(EINSTELLUNGS_DATEI);
        f.encoding = "UTF-8";
        if (f.open("w")) {
            f.write('{ "x": ' + Math.round(w.location[0]) +
                    ', "y": ' + Math.round(w.location[1]) +
                    ', "breite": ' + Math.round(w.size[0]) +
                    ', "hoehe": ' + Math.round(w.size[1]) + ' }');
            f.close();
        }
    } catch (e) {}
}

function fensterWiederherstellen() {
    try {
        var f = File(EINSTELLUNGS_DATEI);
        if (!f.exists) return;
        f.encoding = "UTF-8";
        if (!f.open("r")) return;
        var txt = f.read();
        f.close();
        var m = txt.match(/"x":\s*(-?\d+)[\s\S]*"y":\s*(-?\d+)[\s\S]*"breite":\s*(\d+)[\s\S]*"hoehe":\s*(\d+)/);
        if (!m) return;
        var x = Number(m[1]), y = Number(m[2]), b = Number(m[3]), h = Number(m[4]);
        if (b < 400 || h < 300) return;              // offensichtlich kaputt
        if (x < 0) x = 0;
        if (y < 22) y = 22;                          // nicht unter die Menüleiste
        w.location = [x, y];
        w.size = [b, h];
        w.layout.resize();
    } catch (e) {}
}

// ============================================================================
//  Auswahl im Dokument verfolgen
// ============================================================================
// Wer im Layout einen Rahmen anklickt, soll ihn sofort in der Liste haben.
// Während das Script selbst arbeitet (place() ändert die Auswahl) bleibt der
// Zuhörer still, sonst baut sich die Liste mitten in der Aktion neu auf.

var listener = null;

function auswahlGeaendert() {
    if (arbeitet || eigeneAuswahl) return;
    if (!cbFolgen || !cbFolgen.value) return;
    if (!rbAuswahl || !rbAuswahl.value) return;
    try { listeFuellen("auswahl"); } catch (e) {}
}

function listenerAnmelden() {
    try {
        if (!listener) listener = app.addEventListener("afterSelectionChanged", auswahlGeaendert);
    } catch (e) { listener = null; }
}

function listenerAbmelden() {
    try {
        if (listener) { app.removeEventListener("afterSelectionChanged", auswahlGeaendert); listener = null; }
    } catch (e) {}
}

// ============================================================================
//  Start
// ============================================================================

function start() {
    // Ein zweiter Aufruf soll das alte Fenster ablösen, nicht danebenlegen.
    try {
        if ($.global.dwbkdImportoptionenFenster && $.global.dwbkdImportoptionenFenster.visible) {
            $.global.dwbkdImportoptionenFenster.close();
        }
    } catch (e) {}
    listenerAbmelden();

    fensterBauen();
    $.global.dwbkdImportoptionenFenster = w;

    listeFuellen(bereich());
    listenerAnmelden();
    w.show();
    fensterWiederherstellen();
}

// Diagnose-Zugang: erlaubt es, die Bausteine aus einem anderen Script heraus
// aufzurufen — dazu dort dieselbe Skript-Umgebung angeben:
//     #targetengine "dwbkd_importoptionen"
$.global.dwbkdImportoptionen = {
    version:            VERSION,
    sammle:             sammle,
    neuImportieren:     neuImportieren,
    bildOptionenDirekt: bildOptionenDirekt,
    ebenenListe:        ebenenListe,
    setzeEbeneNachName: setzeEbeneNachName,
    pdfSeitenzahl:      pdfSeitenzahl,
    fenster:            function () { return w; },
    markiereIndizes:    function (ix) { markiereIndizes(ix); }
};

start();

})();
