# Von Hand einrichten — ganz ohne Installer

Für Rechner, auf denen `installieren.command` oder `installieren.ps1` nicht
laufen darf oder kann: gesperrter Firmen-Mac, fremdes Notebook, blockierte
PowerShell, kein Terminal. **Alles hier geht mit Finder bzw. Explorer und
einem Texteditor.** Es wird kein Administratorrecht gebraucht — jeder Pfad
liegt im eigenen Benutzerordner.

Nur ein einziger Schritt ist fummelig: der Eintrag in der Verzeichnisdatei
`ID.json` (Schritt A2). Der fertige Text zum Einsetzen steht dort.

---

## Das Zielbild

Vier Dinge müssen an ihren Platz — dann findet InDesign sie beim Start:

| Was | Wohin (macOS) | Ergebnis im Programm |
|---|---|---|
| drei Plugin-Ordner | `~/Library/Application Support/Adobe/UXP/Plugins/External/` | **Plug-ins ▸ …** |
| Eintrag je Plugin | `~/Library/Application Support/Adobe/UXP/PluginsInfo/v1/ID.json` | ohne ihn bleibt das Bedienfeld unsichtbar |
| sieben `.jsx` | `…/Scripts/Scripts Panel/` | **Fenster ▸ Hilfsprogramme ▸ Skripte ▸ Benutzer** |
| `Menue-Startup.jsx` | `…/Scripts/startup scripts/` | **Objekt ▸ Importoptionen ändern …** |

Die Windows-Pfade stehen in [Teil C](#teil-c--dasselbe-unter-windows).
**InDesign muss dabei beendet sein** — es liest all das nur beim Start.

---

## Teil A — die drei Bedienfelder

### A1 · Ordner kopieren und umbenennen

Im Finder **⇧⌘G** (*Gehe zu ▸ Gehe zum Ordner…*) und diesen Pfad einsetzen:

```
~/Library/Application Support/Adobe/UXP/Plugins/External
```

Gibt es den Ordner `External` noch nicht, leg ihn an (er darf leer sein, der
übergeordnete Pfad existiert nach dem ersten InDesign-Start).

Jetzt die drei Ordner aus `Bedienfelder/` **dorthin kopieren und umbenennen**.
Der Zielname ist immer `Kennung_Version` — genau so, sonst findet InDesign
nichts:

| Quellordner | Zielname im `External`-Ordner |
|---|---|
| `Bedienfelder/ansicht/` | `de.dwb.ansicht_1.3.7` |
| `Bedienfelder/export/` | `de.dwb.export_1.3.5` |
| `Bedienfelder/pruefung/` | `de.dwb.pruefung_1.0.3` |

In jedem Zielordner müssen anschließend die vier Dateien `manifest.json`,
`index.html`, `stil.css` und `index.js` direkt nebeneinanderliegen — kein
Zwischenordner. Fremde Ordner im `External`-Ordner bleiben unberührt.

> **Die Versionsnummer nicht aus dieser Tabelle abschreiben, sondern
> nachsehen.** Sie steht in der jeweiligen `manifest.json` in der Zeile
> `"version": "…"` und ändert sich mit jeder neuen Fassung. Sie muss an
> **drei** Stellen gleich lauten: im Ordnernamen, und gleich zweimal in der
> `ID.json` (`path` und `versionString`).

### A2 · Die Verzeichnisdatei `ID.json`

InDesign nimmt ein Plugin nur, wenn es auch in dieser Liste steht. Wieder
**⇧⌘G**:

```
~/Library/Application Support/Adobe/UXP/PluginsInfo/v1
```

**Fall 1 — die Datei `ID.json` fehlt.** Dann eine neue anlegen (siehe
[Fallen](#fallen--was-beim-tippen-schiefgeht) zum Anlegen mit TextEdit) und
komplett diesen Inhalt hineinschreiben:

```json
{
  "plugins": [
    {
      "hostMinVersion": "18.5.0",
      "name": "Ansicht dwb",
      "path": "$localPlugins/External/de.dwb.ansicht_1.3.7",
      "pluginId": "de.dwb.ansicht",
      "status": "enabled",
      "type": "uxp",
      "versionString": "1.3.7"
    },
    {
      "hostMinVersion": "18.5.0",
      "name": "Export dwb",
      "path": "$localPlugins/External/de.dwb.export_1.3.5",
      "pluginId": "de.dwb.export",
      "status": "enabled",
      "type": "uxp",
      "versionString": "1.3.5"
    },
    {
      "hostMinVersion": "18.5.0",
      "name": "Prüfung dwb",
      "path": "$localPlugins/External/de.dwb.pruefung_1.0.3",
      "pluginId": "de.dwb.pruefung",
      "status": "enabled",
      "type": "uxp",
      "versionString": "1.0.3"
    }
  ]
}
```

Das `$localPlugins` ist **kein Platzhalter zum Ersetzen** — es steht so in der
Datei, InDesign löst es selbst auf.

**Fall 2 — die Datei gibt es schon** (der Normalfall, andere Plugins stehen
drin). Dann **erst eine Sicherungskopie** danebenlegen (`ID.json` kopieren,
Kopie in `ID.json.bak` umbenennen) — der Installer tut genau dasselbe. Danach
die drei Blöcke von oben in die vorhandene Liste einfügen: vor die schließende
`]` setzen und darauf achten, dass **zwischen** zwei `}` `{`-Blöcken ein Komma
steht, hinter dem letzten aber keins. Fremde Einträge bleiben unangetastet.

Stehen dort noch **ältere dwb-Einträge** (etwa `de.dwb.export_1.3.4` oder die
alten Kennungen `de.dwbkd.ansicht`, `de.dwbkd.export`, `dwbkdtest`), lösch
deren Blöcke ganz heraus — sonst lädt InDesign zwei Fassungen desselben
Bedienfelds. Die zugehörigen alten Ordner im `External`-Ordner dürfen
ebenfalls weg.

### A3 · Neu starten und nachsehen

InDesign starten. Die Bedienfelder stehen unter

    Plug-ins ▸ Ansicht dwb  ▸ Ansicht dwb
    Plug-ins ▸ Export dwb   ▸ Export dwb
    Plug-ins ▸ Prüfung dwb  ▸ Prüfung dwb

Unter **Plug-ins ▸ Plug-ins verwalten** müssen alle drei mit ihrem Namen und
dem Zustand „enabled“ auftauchen.

---

## Teil B — die sieben Skripte und das Startskript

### B1 · Den Skriptordner finden — ohne Pfad zu tippen

InDesign legt je Version **und Sprache** einen eigenen Skriptordner an, der
Name ist auf jedem Rechner anders. Der bequemste Weg führt am Pfad vorbei:

1. InDesign starten, **Fenster ▸ Hilfsprogramme ▸ Skripte**
2. Rechtsklick auf den Ordner **Benutzer** ▸ *Im Finder anzeigen*
   (unter Windows sinngemäß *Im Explorer anzeigen*)

Der Finder öffnet damit genau den Ordner `Scripts Panel`. Von Hand wäre es:

```
~/Library/Preferences/Adobe InDesign/Version 21.0/de_DE/Scripts/Scripts Panel
```

`Version 21.0` und `de_DE` heißen je nach installierter Fassung und Sprache
anders — deshalb besser über den Rechtsklick gehen. Wer beide Sprachen oder
mehrere InDesign-Versionen installiert hat, wiederholt Teil B für **jeden**
dieser Ordner; sonst fehlen die Skripte nach dem Umschalten.

### B2 · Die sieben Dateien hineinkopieren

Diese `.jsx` in den Ordner `Scripts Panel` kopieren (Unterordner sind erlaubt
und tauchen im Bedienfeld als Gruppe auf):

| Aus | Datei |
|---|---|
| `Importoptionen/` | `Importoptionen.jsx` |
| `Zoom-Export/` | `Zoom-Export.jsx` |
| `Werkzeuge/` | `Typo-Putz.jsx` · `Aufraeumen.jsx` · `Version-sichern.jsx` · `Neues-Dokument.jsx` · `Kontaktabzug.jsx` |

Die `README.md`-Dateien bleiben, wo sie sind — im Skriptordner stören sie nur.

Das Skriptbedienfeld liest den Ordner **sofort** neu; für die Skripte ist
kein Neustart nötig.

### B3 · Das Startskript

`Importoptionen/Menue-Startup.jsx` kopieren nach — eine Ebene über
`Scripts Panel`:

```
…/Scripts/startup scripts/
```

Den Ordner `startup scripts` gibt es anfangs oft nicht; dann im Finder neu
anlegen, **exakt so geschrieben**: klein, mit Leerzeichen, ohne Bindestrich.
InDesign führt beim Start alles aus, was darin liegt.

Nach dem nächsten Start steht **Objekt ▸ Importoptionen ändern …** im Menü
(dort lässt sich unter *Bearbeiten ▸ Tastaturbefehle* auch ein Kürzel
vergeben). Ohne dieses Startskript funktioniert alles andere weiterhin — nur
der Knopf **Importoptionen …** im Bedienfeld *Ansicht dwb* muss dann den
Umweg über das Skriptbedienfeld nehmen.

---

## Teil C — dasselbe unter Windows

Gleiche Reihenfolge, gleiche Regeln, nur andere Orte. In die Adresszeile des
Explorers lässt sich `%APPDATA%` direkt eintippen.

| | Pfad |
|---|---|
| Plugin-Ordner (A1) | `%APPDATA%\Adobe\UXP\Plugins\External\` |
| Verzeichnisdatei (A2) | `%APPDATA%\Adobe\UXP\PluginsInfo\v1\ID.json` |
| Skripte (B2) | `%APPDATA%\Adobe\InDesign\Version 21.0\de_DE\Scripts\Scripts Panel\` |
| Startskript (B3) | `…\Scripts\startup scripts\` |

Der Inhalt der `ID.json` ist **wortgleich** derselbe wie oben — auch dort mit
Schrägstrichen im `path`, nicht mit Rückstrichen.

---

## Kontrolle — und wenn nichts erscheint

Der Reihe nach durchgehen; die häufigsten Ursachen zuerst:

1. **InDesign wirklich beendet und neu gestartet?** Fenster schließen genügt
   nicht — das Programm muss ganz beendet werden (⌘Q).
2. **Stimmt der Ordnername Zeichen für Zeichen?** `de.dwb.export_1.3.5`, mit
   Unterstrich vor der Version, ohne Leerzeichen.
3. **Stimmen Ordnername, `path` und `versionString` überein?** Drei Stellen,
   dieselbe Nummer.
4. **Liegt `manifest.json` direkt im Plugin-Ordner?** Ein Zwischenordner (etwa
   `de.dwb.export_1.3.5/export/manifest.json`) macht das Plugin unsichtbar.
5. **Ist die `ID.json` noch gültiges JSON?** Ein fehlendes oder überzähliges
   Komma reicht, damit **alle** Plugins verschwinden — auch fremde. Zum Prüfen
   die Datei in einen JSON-Prüfer im Browser kopieren, oder die Sicherung
   `ID.json.bak` zurückholen und noch einmal ansetzen.
6. **Ist InDesign alt genug?** UXP-Bedienfelder gibt es erst ab **18.5**
   (2023). Darunter erscheinen sie nie; die Rückfallebene ist die Palette
   `Zoom-Export/Zoom-Export.jsx`, die als reines Skript überall läuft.

**Warum ein Plugin nicht lädt, sagt InDesign nur im Log.** Öffnen ohne
Terminal: in *Konsole.app* links unter *Berichte* nachsehen, oder im Finder
per **⇧⌘G**

```
~/Library/Logs/Adobe
```

Dort im Ordner `Adobe InDesign …` die jüngste Datei `UXPLogs_*.log`
doppelklicken und nach `dwb` suchen. Der Jahresordner im Pfad wächst nicht mit
der InDesign-Version mit — es kann also mehrere geben, das Datum entscheidet.

---

## Wieder entfernen — von Hand

1. Die drei Ordner `de.dwb.*_*` aus `…/UXP/Plugins/External/` löschen.
2. In der `ID.json` die drei Blöcke mit `"pluginId": "de.dwb.…"` herauslöschen
   (auf die Kommas achten). Fremde Einträge stehen lassen.
3. Die sieben `.jsx` aus `Scripts Panel` und `Menue-Startup.jsx` aus
   `startup scripts` löschen.
4. InDesign neu starten.

Eigene Zoomstufen, Export-Knöpfe und Protokolle überleben das — sie liegen
getrennt davon unter

```
~/Library/Application Support/Adobe/UXP/PluginsStorage/IDSN/<Version>/External/de.dwb.export/PluginData/
```

Wer auch die loswerden will, löscht dort die Ordner `de.dwb.*`. Wer die
Einstellungen umgekehrt auf einen **anderen Rechner mitnehmen** will, kopiert
von dort die `einstellungen.json` an die gleiche Stelle des neuen Rechners —
der Ordnerpfad muss dazu von Hand angelegt werden.

---

## Fallen — was beim Tippen schiefgeht

**TextEdit macht aus geraden Anführungszeichen krumme.** `"name"` wird still
zu `„name“`, und die Datei ist als JSON tot. Vor dem Tippen im Menü
*TextEdit ▸ Einstellungen ▸ Neues Dokument* die **intelligenten
Anführungszeichen abschalten** — oder nur mit Kopieren und Einsetzen
arbeiten und nichts von Hand nachtippen.

**TextEdit sichert sonst als RTF.** Bei einer neu angelegten Datei zuerst
*Format ▸ In reinen Text umwandeln* (**⇧⌘T**), sonst steht Formatierungscode
in der Datei. Beim Sichern hängt TextEdit gern noch `.txt` an — der Dateiname
muss am Ende exakt `ID.json` lauten, notfalls im Finder nachträglich
umbenennen und die Rückfrage zur Endung bestätigen.

**Unter Windows: UTF-8, aber ohne BOM.** Der Name „Prüfung dwb“ enthält ein
Umlautzeichen, die Datei muss also UTF-8 sein — im Notepad-Dialog *Speichern
unter* aber „UTF-8“ wählen, **nicht** „UTF-8 mit BOM“. Über die drei
unsichtbaren Zeichen am Dateianfang stolpert der Plugin-Lader. Ebenfalls im
Speichern-Dialog: *Dateityp* auf „Alle Dateien“ stellen, sonst wird aus
`ID.json` ein `ID.json.txt`.

**Von Hand kopiert ist kopiert.** Der Installer *verknüpft* die Skripte unter
macOS, eine Änderung am Quelltext wirkt dort sofort. Hier liegen echte Kopien:
Nach jeder Änderung an einem `.jsx` oder an einem Bedienfeld muss neu kopiert
werden — beim Bedienfeld samt neuer Versionsnummer an allen drei Stellen.

**Der Ordner `External` ist nicht der einzige.** Über das Creative-Cloud-Fenster
installierte Plugins landen woanders; die dort sichtbare Liste hat mit dieser
Handinstallation nichts zu tun. Maßgeblich ist allein
**Plug-ins ▸ Plug-ins verwalten** im laufenden InDesign.

---

**Stand:** 2026-09-03 · passend zu Ansicht dwb 1.3.7 · Export dwb 1.3.5 ·
Prüfung dwb 1.0.3 · geprüft mit InDesign 21.5.1 (2026), macOS
