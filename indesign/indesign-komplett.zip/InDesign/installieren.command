#!/bin/bash
# ============================================================================
#  Alles für InDesign einrichten
# ----------------------------------------------------------------------------
#  Richtet in einem Rutsch ein:
#    • die drei Bedienfelder „Ansicht dwb“, „Export dwb“ und „Prüfung dwb“
#    • die Skripte im Skriptbedienfeld: Importoptionen, Zoom-Export,
#      Typo-Putz, Aufräumen, Version sichern, Neues Dokument, Kontaktabzug
#
#  Aufruf: Doppelklick (fragt: Einrichten / Entfernen / Prüfen), oder Terminal:
#          ./installieren.command                    richtet alles ein
#          ./installieren.command --entfernen        nimmt alles wieder heraus
#          ./installieren.command --entfernen-alles  löscht auch Einstellungen
#          ./installieren.command --pruefen          prüft, ohne zu ändern
#          ./installieren.command --ausfuehrlich     zeigt jeden Pfad einzeln
#
#  Danach InDesign neu starten.
# ============================================================================
set -e
HIER="$(cd "$(dirname "$0")" && pwd)"

MODUS="einrichten"
AUSFUEHRLICH=""
for ARG in "$@"; do
    case "$ARG" in
        --einrichten)      MODUS="einrichten" ;;
        --entfernen)       MODUS="entfernen" ;;
        --entfernen-alles) MODUS="entfernen-alles" ;;
        --pruefen)         MODUS="pruefen" ;;
        --ausfuehrlich)    AUSFUEHRLICH="--ausfuehrlich" ;;
        *) echo "Unbekannter Schalter: $ARG"; exit 2 ;;
    esac
done

# Ohne Argumente und mit Terminal davor (Doppelklick im Finder): kurz fragen —
# sonst wäre das Entfernen nur über das Terminal zu erreichen.
if [ $# -eq 0 ] && [ -t 0 ]; then
    echo "  [1] Einrichten   [2] Entfernen   [3] Prüfen"
    printf "  Auswahl (Eingabetaste = Einrichten): "
    read -r WAHL
    case "$WAHL" in
        2) MODUS="entfernen" ;;
        3) MODUS="pruefen" ;;
        *) MODUS="einrichten" ;;
    esac
    echo
fi

# Läuft InDesign gerade, greift nichts davon vor dem Neustart — deutlich sagen.
if [ "$MODUS" != "pruefen" ] \
   && pgrep -f "Adobe InDesign [0-9]*\.app/Contents/MacOS/Adobe InDesign" >/dev/null 2>&1; then
    echo "⚠ InDesign läuft gerade — bitte beenden und neu starten,"
    echo "  vorher wird von den Änderungen nichts sichtbar."
    echo
fi

FEHLER=0

echo "════════════════════════════════════════════════════════════"
echo "  Bedienfelder (UXP-Plugins)"
echo "════════════════════════════════════════════════════════════"
DWB_ELTERN=1 "$HIER/Bedienfelder/installieren.command" "--$MODUS" $AUSFUEHRLICH || FEHLER=1

echo
echo "════════════════════════════════════════════════════════════"
echo "  Skripte im Skriptbedienfeld"
echo "════════════════════════════════════════════════════════════"

# InDesign legt je Version und Sprache einen eigenen Skriptordner an. Wir
# bedienen alle, die es auf diesem Rechner gibt — dann stimmt es auch nach
# einem Versionswechsel oder bei zweisprachiger Installation.
ORDNER=0; SKRIPTE=0; SKRIPTE_KAPUTT=0
for ZIEL in "$HOME/Library/Preferences/Adobe InDesign/Version "*/*/"Scripts/Scripts Panel"; do
    [ -d "$ZIEL" ] || continue
    ORDNER=$((ORDNER + 1))
    for SKRIPT in "Importoptionen/Importoptionen.jsx" "Zoom-Export/Zoom-Export.jsx" \
                  "Werkzeuge/Typo-Putz.jsx" "Werkzeuge/Aufraeumen.jsx" \
                  "Werkzeuge/Version-sichern.jsx" "Werkzeuge/Neues-Dokument.jsx" \
                  "Werkzeuge/Kontaktabzug.jsx" "Werkzeuge/Bilder-in-Rahmen.jsx"; do
        NAME="$(basename "$SKRIPT")"
        case "$MODUS" in
            pruefen)
                if [ -L "$ZIEL/$NAME" ] && [ -e "$ZIEL/$NAME" ]; then
                    SKRIPTE=$((SKRIPTE + 1))
                    [ -n "$AUSFUEHRLICH" ] && echo "in Ordnung: $ZIEL/$NAME"
                else
                    SKRIPTE_KAPUTT=$((SKRIPTE_KAPUTT + 1))
                    echo "✗ fehlt oder zeigt ins Leere: $ZIEL/$NAME"
                fi
                ;;
            entfernen|entfernen-alles)
                if [ -L "$ZIEL/$NAME" ]; then
                    rm -f "$ZIEL/$NAME"
                    SKRIPTE=$((SKRIPTE + 1))
                    [ -n "$AUSFUEHRLICH" ] && echo "entfernt: $ZIEL/$NAME"
                fi
                ;;
            *)
                if ln -sf "$HIER/$SKRIPT" "$ZIEL/$NAME"; then
                    SKRIPTE=$((SKRIPTE + 1))
                    [ -n "$AUSFUEHRLICH" ] && echo "verknüpft: $ZIEL/$NAME"
                else
                    SKRIPTE_KAPUTT=$((SKRIPTE_KAPUTT + 1))
                    echo "✗ Verknüpfung fehlgeschlagen: $ZIEL/$NAME"
                fi
                ;;
        esac
    done
done

# Das Startskript hängt „Importoptionen ändern …“ fest ins Menü Objekt.
# InDesign führt alles aus, was im Ordner „startup scripts“ liegt.
START_OK=0; START_KAPUTT=0
for ZIEL in "$HOME/Library/Preferences/Adobe InDesign/Version "*/*/"Scripts"; do
    [ -d "$ZIEL" ] || continue
    START="$ZIEL/startup scripts"
    case "$MODUS" in
        pruefen)
            if [ -L "$START/Menue-Startup.jsx" ] && [ -e "$START/Menue-Startup.jsx" ]; then
                START_OK=$((START_OK + 1))
                [ -n "$AUSFUEHRLICH" ] && echo "in Ordnung: $START/Menue-Startup.jsx"
            else
                START_KAPUTT=$((START_KAPUTT + 1))
                echo "✗ fehlt oder zeigt ins Leere: $START/Menue-Startup.jsx"
            fi
            ;;
        entfernen|entfernen-alles)
            if [ -L "$START/Menue-Startup.jsx" ]; then
                rm -f "$START/Menue-Startup.jsx"
                START_OK=$((START_OK + 1))
                [ -n "$AUSFUEHRLICH" ] && echo "entfernt: $START/Menue-Startup.jsx"
            fi
            ;;
        *)
            mkdir -p "$START"
            if ln -sf "$HIER/Importoptionen/Menue-Startup.jsx" "$START/Menue-Startup.jsx"; then
                START_OK=$((START_OK + 1))
                [ -n "$AUSFUEHRLICH" ] && echo "verknüpft: $START/Menue-Startup.jsx"
            else
                START_KAPUTT=$((START_KAPUTT + 1))
                echo "✗ Verknüpfung fehlgeschlagen: $START/Menue-Startup.jsx"
            fi
            ;;
    esac
done

# Kein einziger Skriptordner: InDesign war auf diesem Rechner noch nie offen.
if [ "$ORDNER" = "0" ]; then
    echo "✗ Kein Skriptordner gefunden. Ist InDesign auf diesem Rechner schon"
    echo "  einmal gelaufen? Bitte InDesign einmal starten (dabei entstehen die"
    echo "  Ordner) und den Installer danach erneut ausführen."
    FEHLER=1
fi

# Kompakte Bilanz — die vollen Pfade gibt es mit --ausfuehrlich.
echo
if [ "$ORDNER" != "0" ]; then
    case "$MODUS" in
        pruefen)
            if [ "$SKRIPTE_KAPUTT" = "0" ]; then
                echo "  ✓ $SKRIPTE Skript-Verknüpfungen in $ORDNER Versionsordner(n) in Ordnung"
            else
                echo "  ✗ $SKRIPTE_KAPUTT Skript-Verknüpfung(en) kaputt oder fehlend"
                FEHLER=1
            fi
            if [ "$START_KAPUTT" = "0" ]; then
                echo "  ✓ Startskript in Ordnung"
            else
                echo "  ✗ Startskript kaputt oder fehlend"
                FEHLER=1
            fi
            ;;
        entfernen|entfernen-alles)
            echo "  ✓ $SKRIPTE Skript-Verknüpfungen und $START_OK Startskript(e) entfernt"
            ;;
        *)
            if [ "$SKRIPTE_KAPUTT" = "0" ] && [ "$START_KAPUTT" = "0" ]; then
                echo "  ✓ $SKRIPTE Skripte in $ORDNER Versionsordner(n) verknüpft"
                echo "  ✓ Startskript verknüpft"
            else
                echo "  ✗ Nicht alle Verknüpfungen gelungen — siehe oben"
                FEHLER=1
            fi
            ;;
    esac
fi

echo
echo "════════════════════════════════════════════════════════════"
if [ "$FEHLER" != "0" ]; then
    echo "  ✗ Nicht alles in Ordnung — Einzelheiten stehen oben."
elif [ "$MODUS" = "pruefen" ]; then
    echo "  Prüfung abgeschlossen — alles in Ordnung."
elif [ "$MODUS" = "entfernen" ] || [ "$MODUS" = "entfernen-alles" ]; then
    echo "  Fertig. InDesign neu starten — dann ist alles wieder weg."
    if [ "$MODUS" = "entfernen" ]; then
        echo "  (Einstellungen bleiben erhalten; --entfernen-alles löscht auch sie.)"
    fi
else
    echo "  Fertig. InDesign neu starten. Danach:"
    echo
    echo "    Plug-ins ▸ Ansicht dwb  ▸ Ansicht dwb"
    echo "    Plug-ins ▸ Export dwb   ▸ Export dwb"
    echo "    Plug-ins ▸ Prüfung dwb  ▸ Prüfung dwb"
    echo "    Fenster ▸ Hilfsprogramme ▸ Skripte ▸ Benutzer"
    echo "        ▸ Importoptionen.jsx · Zoom-Export.jsx"
    echo "        ▸ Typo-Putz.jsx · Aufraeumen.jsx · Version-sichern.jsx"
    echo "        ▸ Neues-Dokument.jsx · Kontaktabzug.jsx · Bilder-in-Rahmen.jsx"
    echo "    Objekt ▸ Importoptionen ändern …   (kommt vom Startskript)"
fi
echo "════════════════════════════════════════════════════════════"
exit "$FEHLER"
