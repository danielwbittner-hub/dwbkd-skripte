// ============================================================================
// Export dwb — UXP-Bedienfeld für Adobe InDesign                 Version 1.3
// ----------------------------------------------------------------------------
// Beliebig viele Knöpfe, ein Klick: jeder Knopf exportiert als PDF (über eine
// PDF-Exportvorgabe von InDesign) oder als JPG/PNG mit eigener Garnitur aus
// Auflösung, Pixelmaß und Farbraum. Zugeordnet wird alles selbst — im Fenster
// „Export einstellen“ (Knopf „…“, Alt-Klick auf einen Knopf, Rechtsklick oder
// das Bedienfeldmenü).
//
// Alles andere — Zielordner, Unterordner, Dateiname mit Platzhaltern, Umfang,
// Auflösung, Farbraum — steht ebenfalls dort und wird gesichert. Danach ist
// jeder Export ein einziger Klick, ohne Dialog. Der Umfang lässt sich auch
// direkt im Bedienfeld umstellen; ein laufender Mehrdatei-Export zeigt den
// Fortschritt und lässt sich über den Knopf („Anhalten“) abbrechen.
// „Verpacken“ sichert das Dokument und verpackt es (Schriften, Verknüpfungen,
// Profile) in einen Ordner „‹Dokument› verpackt“ neben der Dokumentdatei.
//
// Einstellungen liegen im Datenordner des Plugins:
//   …/UXP/PluginsStorage/IDSN/<Version>/External/de.dwb.export/PluginData/
// © 2026 dwbkd · www.dwbkd.de
// ============================================================================

const uxp = require("uxp");
const lfs = uxp.storage.localFileSystem;

const EINSTELLUNGSDATEI = "einstellungen.json";
const PROTOKOLLDATEI    = "selbsttest-protokoll.txt";
const SELBSTTEST_MARKE  = "selbsttest.txt";

const QUALITAETEN = [
    ["Maximum", "MAXIMUM"],
    ["Hoch",    "HIGH"],
    ["Mittel",  "MEDIUM"],
    ["Niedrig", "LOW"]
];

// Die Bild-Garnitur eines JPG-/PNG-Knopfes. icc zählt nur bei JPG,
// transparenz nur bei PNG — der jeweils andere Wert stört nicht und bleibt
// beim Formatwechsel eines Knopfes erhalten.
function standardBild(format) {
    return {
        qualitaet:  "MAXIMUM",
        aufloesung: (format === "PNG") ? 150 : 300,
        farbraum:   "RGB",
        icc: true, transparenz: true, kanten: true, anschnitt: false,
        masz: "ppi", breitePx: 0, hoehePx: 0
    };
}

function standardEinstellungen() {
    return {
        slots: [
            { name: "Print",     format: "PDF", vorgabe: "", unterordner: "",    einzelseiten: false, bild: null },
            { name: "Newspaper", format: "PDF", vorgabe: "", unterordner: "",    einzelseiten: false, bild: null },
            { name: "Web",       format: "PDF", vorgabe: "", unterordner: "Web", einzelseiten: false, bild: null },
            { name: "JPG",       format: "JPG", vorgabe: "", unterordner: "",    einzelseiten: false, bild: standardBild("JPG") },
            { name: "PNG",       format: "PNG", vorgabe: "", unterordner: "",    einzelseiten: false, bild: standardBild("PNG") }
        ],
        zielArt:        "dokument",     // dokument | fest | fragen
        zielOrdner:     "",
        unterordner:    "",
        muster:         "{dok}",
        umfang:         "alle",         // alle | aktuelle | bereich | auswahl
        bereich:        "",
        druckbogen:     false,
        ueberschreiben: false,
        danach:         "nichts",       // nichts | finder | datei
        verpackenPdf:   false,          // Druck-PDF mit ins Paket
        verpackenVorgabe: "",           // PDF-Vorgabe dafür
        verpackenZip:   false           // Paket zusätzlich als ZIP (nur macOS)
    };
}

let einstellungen = standardEinstellungen();
let statusFeld = null;
let arbeitet = false;
// Ein Klick auf den laufenden Knopf („Anhalten“) setzt dieses Zeichen; die
// Exportschleifen prüfen es vor jeder weiteren Datei.
let abbruchGewuenscht = false;
// Wann der laufende Export begann: ein Klick kurz danach ist fast immer der
// zweite Teil eines Doppelklicks — der soll den Export nicht gleich wieder
// anhalten.
let exportBeginn = 0;
// Zielordner des letzten gelungenen Exports — ein Klick auf die Statuszeile
// öffnet ihn.
let letzterZielPfad = "";
// Was seitenAusBereich an unbekannten Seiten übersprungen hat — für die
// Warnung in der Statuszeile.
let bereichWarnungen = [];
// Welche Auflösung beim letzten Bildexport wirklich herauskam (beim Pixelmaß
// wird sie je Datei ausgerechnet) — nur für die Statuszeile.
let letzteAufloesung = 0;

// ============================================================================
//  Kleinkram
// ============================================================================

function indesign() { return require("indesign"); }

// art: "fehler" färbt die Zeile rot, "erfolg" stellt einen grünen Punkt voran,
// ohne art bleibt sie leise grau.
function status(text, art) {
    if (!statusFeld) statusFeld = document.getElementById("status");
    if (!statusFeld) return;
    statusFeld.textContent = "";
    if (art === "erfolg") {
        const punkt = document.createElement("span");
        punkt.className = "punkt";
        punkt.textContent = "● ";
        statusFeld.appendChild(punkt);
    }
    statusFeld.appendChild(document.createTextNode(String(text)));
    statusFeld.setAttribute("title", String(text));
    statusFeld.classList.toggle("fehler", art === "fehler");
}

// Merkt sich den Zielordner des letzten Exports; die Statuszeile wird damit
// zum Öffnen-Knopf (die Unterstreichung zeigt es an).
function statusZiel(pfad) {
    letzterZielPfad = pfad ? String(pfad) : "";
    if (!statusFeld) statusFeld = document.getElementById("status");
    if (statusFeld) statusFeld.classList.toggle("klickbar", letzterZielPfad.length > 0);
}

// Kurz an die Oberfläche zurückgeben: so wird die Statuszeile zwischen zwei
// Dateien neu gezeichnet und ein Klick auf „Anhalten“ kommt durch.
function kurzeAtempause() {
    return new Promise(fertig => setTimeout(fertig, 0));
}

function zahl(wert, ersatz) {
    const n = parseFloat(String(wert).replace(",", "."));
    return isNaN(n) ? ersatz : n;
}

function fuellen(n, stellen) {
    let s = String(Math.round(n));
    while (s.length < stellen) s = "0" + s;
    return s;
}

function heute() {
    const d = new Date();
    return d.getFullYear() + "-" + fuellen(d.getMonth() + 1, 2) + "-" + fuellen(d.getDate(), 2);
}

function uhrzeit() {
    const d = new Date();
    return fuellen(d.getHours(), 2) + fuellen(d.getMinutes(), 2);
}

// Alles heraus, was in Dateinamen Ärger macht.
function sauberName(text) {
    const name = String(text).replace(/[\\\/:\*\?"<>\|\r\n\t]/g, "_")
                             .replace(/^\s+|\s+$/g, "")
                             .replace(/\.+$/, "")
                             .replace(/_+$/, "");
    return name.length ? name : "Export";
}

function ohneEndung(name) {
    const text = String(name), punkt = text.lastIndexOf(".");
    return (punkt > 0) ? text.substring(0, punkt) : text;
}

// ============================================================================
//  Roll-Hinweise
// ----------------------------------------------------------------------------
// UXP zeichnet keine sichtbaren Rollbalken — dass ein Bereich unten (oder
// oben) weitergeht, sieht man sonst schlicht nicht. Jeder Rollbereich steckt
// in einem .rollrahmen mit zwei Pfeilzeilen (siehe stil.css), die nur bei
// verdecktem Inhalt erscheinen; ein Klick darauf rollt ein Stück weiter.
// ============================================================================

const rollBereiche = [];

function rollHinweiseAnbinden(bereich) {
    if (!bereich || bereich.dataset.rollt === "ja") return;
    bereich.dataset.rollt = "ja";
    const rahmen = bereich.parentElement;
    const oben  = rahmen ? rahmen.querySelector(".rollhinweis.oben")  : null;
    const unten = rahmen ? rahmen.querySelector(".rollhinweis.unten") : null;
    const zeigen = () => {
        // Ein unsichtbarer Bereich (geschlossener Dialog) meldet Höhe 0 —
        // dann bleiben beide Hinweise aus.
        const kannOben  = bereich.clientHeight > 0 && bereich.scrollTop > 2;
        const kannUnten = bereich.clientHeight > 0 &&
            bereich.scrollTop + bereich.clientHeight < bereich.scrollHeight - 2;
        if (oben)  oben.classList.toggle("sichtbar", kannOben);
        if (unten) unten.classList.toggle("sichtbar", kannUnten);
    };
    const rollen = (richtung) => {
        bereich.scrollTop += richtung * Math.max(40, Math.round(bereich.clientHeight * 0.8));
        zeigen();
    };
    bereich.addEventListener("scroll", zeigen);
    if (oben)  oben.addEventListener("click",  () => rollen(-1));
    if (unten) unten.addEventListener("click", () => rollen(1));
    rollBereiche.push(zeigen);
    zeigen();
}

// Die Bedienfeldknöpfe sind <div role="button"> (Baulehre 30): nur so kommen
// Füllung, Ecken und Höhe aus dem CSS an — ein <button> malt der Wirt selbst.
// Ein DIV kennt aber kein disabled. Deshalb: gesperrt = Attribut „disabled“
// (dafür greift das CSS), ein Wächter in der Fangphase lässt Klicks auf
// Gesperrte gar nicht erst ankommen, und Enter/Leertaste lösen aus wie beim
// echten Knopf (dispatchEvent — click() tut in UXP nichts, Baulehre 2).
function knopfGesperrt(element, aus) {
    if (!element) return;
    // Gesperrte DIV-Knöpfe auch aus der Tab-Reihe nehmen — ein <button disabled>
    // wäre von selbst unerreichbar, ein DIV mit tabindex 0 nicht.
    if (aus) { element.setAttribute("disabled", ""); element.setAttribute("tabindex", "-1"); }
    else     { element.removeAttribute("disabled");  element.setAttribute("tabindex", "0"); }
}
function knopfVon(ziel) {
    let el = ziel;
    while (el && el !== document) {
        if (el.classList && el.classList.contains("knopf")) return el;
        el = el.parentNode;
    }
    return null;
}
function knopfWaechterAnbinden(wurzel) {
    if (!wurzel || wurzel.getAttribute("data-waechter") === "ja") return;
    wurzel.setAttribute("data-waechter", "ja");
    wurzel.addEventListener("click", (e) => {
        const knopf = knopfVon(e && e.target);
        if (knopf && knopf.hasAttribute("disabled")) {
            if (e.stopPropagation) e.stopPropagation();
            if (e.preventDefault) e.preventDefault();
        }
    }, true);
    // Fangphase: läuft VOR dem keydown des Dialogs, und der Stopp sorgt dafür,
    // dass Enter auf einem DIV-Knopf nur diesen drückt — nicht zugleich als
    // „Eingabetaste = sichern“ des Fensters zählt.
    wurzel.addEventListener("keydown", (e) => {
        const taste = e && (e.key || e.code);
        if (taste !== "Enter" && taste !== "NumpadEnter" && taste !== " " && taste !== "Space") return;
        const knopf = knopfVon(e.target);
        if (!knopf) return;
        if (e.preventDefault) e.preventDefault();
        if (e.stopPropagation) e.stopPropagation();
        // Gesperrt: Taste schlucken — sonst zählte sie als Eingabetaste des
        // Fensters („sichern“), obwohl der Knopf sichtbar nichts tut.
        if (knopf.hasAttribute("disabled")) return;
        knopf.dispatchEvent(new Event("click"));
    }, true);
    // Fokus-Ring in Dialogen nur nach Tab, nie nach Mausklick (der sah aus wie
    // „aktiv“). Per Klasse, weil nur :focus im Wirt belegt ist; beim
    // unsichtbaren Absende-Knopf auf die Hülle gespiegelt. Feuert focusin im
    // Wirt nicht, passiert schlicht nichts.
    if (String(wurzel.tagName).toUpperCase() !== "DIALOG") return;
    const traeger = (ziel) => {
        const k = knopfVon(ziel);
        if (k) return k;
        const p = ziel && ziel.parentNode;
        return (p && p.classList && p.classList.contains("huelle")) ? p : null;
    };
    wurzel.addEventListener("keydown", (e) => {
        if ((e && (e.key || e.code)) === "Tab") wurzel.setAttribute("data-tastatur", "ja");
    }, true);
    wurzel.addEventListener("mousedown", () => wurzel.setAttribute("data-tastatur", ""), true);
    wurzel.addEventListener("focusin", (e) => {
        const t = traeger(e && e.target);
        if (t && wurzel.getAttribute("data-tastatur") === "ja") t.classList.add("fokus");
    }, true);
    wurzel.addEventListener("focusout", (e) => {
        const t = traeger(e && e.target);
        if (t) t.classList.remove("fokus");
    }, true);
}
// Wächter auf Bedienfeld UND Dialoge; dazu die Absende-Hüllen (Baulehre 31):
// greift die unsichtbare Schaltfläche den Klick nicht ab — etwa weil der
// Wirt ihre absolute Lage ignoriert —, reicht die sichtbare Fläche ihn an
// den echten Knopf weiter und schickt das Formular danach NATIV ab. Nur das
// schließt ein uxpShowModal-Fenster verlässlich; die Klick-Handler allein
// (Wunsch merken + close()) wären genau der Einfrier-Pfad aus Baulehre 11.
// Kennt der Wirt kein requestSubmit, tut der Rückfall lieber gar nichts.
function knopfWaechterAlle() {
    knopfWaechterAnbinden(document.getElementById("wandInhalt"));
    document.querySelectorAll("dialog").forEach(knopfWaechterAnbinden);
    document.querySelectorAll(".huelle").forEach((huelle) => {
        if (huelle.getAttribute("data-waechter") === "ja") return;
        huelle.setAttribute("data-waechter", "ja");
        const flaeche = huelle.querySelector(".knopf");
        const echt    = huelle.querySelector("button");
        if (!flaeche || !echt) return;
        flaeche.addEventListener("click", () => {
            let form = echt.form || null;
            if (!form) { let p = huelle.parentNode; while (p && String(p.tagName).toUpperCase() !== "FORM") p = p.parentNode; form = p || null; }
            if (!form || typeof form.requestSubmit !== "function") return;
            // Erst die Handler des echten Knopfs (Wunsch merken, Eingabe prüfen) —
            // cancelable, damit ein preventDefault („Anlegen“ bei ungültiger
            // Eingabe) ankommt und das Fenster offen bleibt.
            const ev = new Event("click", { cancelable: true });
            echt.dispatchEvent(ev);
            if (ev.defaultPrevented) return;
            let dialog = huelle.parentNode; while (dialog && String(dialog.tagName).toUpperCase() !== "DIALOG") dialog = dialog.parentNode;
            if (dialog && dialog.open === false) return;      // close() hat schon gegriffen
            try { form.requestSubmit(echt); } catch (e) { /* dann bleibt Enter/Esc */ }
        });
    });
}
if (document.getElementById("wandInhalt")) knopfWaechterAlle();
else document.addEventListener("DOMContentLoaded", knopfWaechterAlle);

function rollHinweiseAuffrischen() {
    for (const zeigen of rollBereiche) { try { zeigen(); } catch (e) {} }
}

// Die Wand auf die gemessene Fensterhöhe setzen. height:100% läuft in
// InDesigns UXP-Wirt ins Leere (html/body werden nicht auf die
// Bedienfeldhöhe gezwungen — die Wand wüchse mit dem Inhalt und nichts
// rollte, der Wirt schnitte unten ab). Aufruf bei Start, resize und im
// Helligkeitstakt, denn An- und Abdocken meldet nicht immer ein resize.
let wandHoeheZuletzt = 0;
function wandMasseSetzen() {
    const wand   = document.querySelector(".rollrahmen.wand");
    const inhalt = document.getElementById("wandInhalt");
    if (wand && inhalt) {
        let h = 0;
        try { h = window.innerHeight || 0; } catch (e) { h = 0; }
        if (!h) { try { h = document.documentElement.clientHeight || 0; } catch (e) {} }
        if (h > 40 && h !== wandHoeheZuletzt) {
            wandHoeheZuletzt = h;
            wand.style.height   = h + "px";
            inhalt.style.height = h + "px";
        }
    }
    rollHinweiseAuffrischen();
    knoepfeKuerzen(false);
}

// ------------------------------------------------------------- Dialoghöhe
// Dem Wirt ist die Fensterhöhe nicht zu überlassen: er baut Dialoge gern
// rund 30 px kürzer als den Inhalt (die Titelleiste geht zulasten des
// Fußes — im Ansicht-Bedienfeld fehlten so die Knöpfe). Eine AUSDRÜCKLICH
// angeforderte Höhe setzt er dagegen exakt um (Baulehre 8). Gemessen wird
// an einem KLON des Fensters, der unsichtbar an die Seite gehängt und
// gleich wieder entfernt wird — das echte Dialog-Element darf vor
// uxpShowModal() nicht per show()/close() berührt werden, sonst wirft der
// Wirt beim Öffnen einen InvalidStateError (live passiert). height:auto
// überstimmt am Klon kurz das height:100% des Dialogs, damit die
// natürliche Inhaltshöhe herauskommt.
function dialogHoeheMessen(fenster, messBreite) {
    let gemessen = 0, klon = null;
    try {
        klon = fenster.cloneNode(true);
        // Keine doppelten Kennungen im Baum — der Klon lebt nur einen Moment.
        try { klon.removeAttribute("id"); } catch (e) {}
        try { klon.querySelectorAll("[id]").forEach(el => el.removeAttribute("id")); } catch (e) {}
        klon.setAttribute("open", "");
        klon.style.display = "block";
        klon.style.position = "absolute";
        klon.style.left = "-4000px";
        klon.style.top = "0";
        // NICHT visibility:hidden — so versteckt misst der Wirt 0
        // (Baulehre 22), dialogHoeheMessen fiel dann auf den
        // Rückfallwert zurück und der Dialog ging viel zu hoch auf.
        klon.style.opacity = "0";
        klon.style.pointerEvents = "none";
        klon.style.width = messBreite + "px";
        klon.style.height = "auto";
        document.body.appendChild(klon);
        gemessen = Math.ceil(klon.getBoundingClientRect().height);
    } catch (e) { gemessen = 0; }
    try { if (klon && klon.parentNode) klon.parentNode.removeChild(klon); } catch (e) {}
    return gemessen;
}

// --------------------------------------------------- Knopfbeschriftungen
// UXP kennt auf Knöpfen kein text-overflow: bei zentriertem Text wird
// Übermaß an BEIDEN Seiten stumm abgeschnitten (aus „Newspaper“ wurde
// „ewspap“) — und scrollWidth meldet dabei KEINEN Überlauf, taugt also
// nicht als Prüfung (live gesehen). Deshalb misst ein unsichtbares
// Mess-Span die Textbreite selbst; gekürzt wird mit echtem „…“, der volle
// Text liegt im Tooltip nach, wenn der Knopf keinen eigenen hat.
// Läuft nach jedem Knopfbau und huckepack auf wandMasseSetzen (resize
// und Helligkeitstakt) — aber nur, wenn sich die Panelbreite geändert hat.
let kuerzenBreiteZuletzt = -1;
let messSpan = null;
// Was der Wirt beim Messen tatsächlich zurückgibt — landet in mess-knoepfe.txt.
const messProtokoll = [];
// Breite eines Elements: getBoundingClientRect zuerst, dann offsetWidth,
// dann clientWidth. In InDesigns UXP ist window.innerWidth undefined
// (Baulehre 21) — auf einen einzigen Weg ist kein Verlass.
function elementBreite(el) {
    if (!el) return 0;
    try {
        const r = el.getBoundingClientRect();
        if (r && r.width > 0) return r.width;
    } catch (e) { /* weiter */ }
    try { if (el.offsetWidth > 0) return el.offsetWidth; } catch (e) { /* weiter */ }
    try { if (el.clientWidth > 0) return el.clientWidth; } catch (e) { /* weiter */ }
    return 0;
}
function textBreite(text, schriftGroesse) {
    if (!messSpan) {
        messSpan = document.createElement("span");
        messSpan.style.position = "absolute";
        messSpan.style.left = "-4000px";
        messSpan.style.top = "0";
        // NICHT visibility:hidden — ein so versteckter Knoten liefert im
        // UXP-Wirt keine Maße mehr, und dann hielt die Kürzung jeden Text
        // für kurz genug („ewspap“ blieb stehen). Aus dem Bild geschoben
        // und durchsichtig tut dasselbe, bleibt aber messbar.
        messSpan.style.opacity = "0";
        messSpan.style.pointerEvents = "none";
        messSpan.style.whiteSpace = "nowrap";
        document.body.appendChild(messSpan);
    }
    messSpan.style.fontSize = schriftGroesse;
    messSpan.textContent = text;
    const gemessen = elementBreite(messSpan);
    // Misst der Wirt gar nicht, lieber grob schätzen als gar nicht kürzen:
    // rund 0,55 em je Zeichen trifft bei 10–11 px nah genug.
    if (gemessen > 0) return gemessen;
    const px = parseFloat(schriftGroesse) || 11;
    return text.length * px * 0.55;
}
function knopfSchrift(knopf) {
    try {
        const stil = getComputedStyle(knopf);
        if (stil && stil.fontSize) return stil.fontSize;
    } catch (e) { /* dann nach Klasse */ }
    return "11px";
}
function knopfTextKuerzen(knopf) {
    // Kürzen ist in einem UXP-Bedienfeld prinzipiell unmöglich: der Wirt gibt
    // für Flex-Kinder keine Breite heraus (Baulehre 23, gemessen: alles 0), und
    // ohne verfügbare Breite gibt es nichts zu vergleichen. Auch element.dataset
    // trägt nichts über den Aufruf hinaus. Also nur noch der Weg, der ohne
    // Elementmaße auskommt: den Knopf so breit machen, dass die Aufschrift
    // hineinpasst — die Textbreite liefert der Wirt zuverlässig.
    knopfBreiteSichern(knopf);
}
// Der Wirt gibt für Flex-Kinder KEINE Breite heraus (Baulehre 23, gemessen:
// jeder Knopf 0 px, wandInhalt 0 px) — Kürzen ist damit unmöglich, denn ohne
// verfügbare Breite gibt es nichts zu vergleichen. Textbreiten liefert er
// dagegen (das Mess-Span steht absolut und schrumpft auf den Inhalt). Also
// andersherum: den Knopf so breit machen, dass die Aufschrift hineinpasst.
// Nur vergrößern, nie verkleinern — sonst kippt die bestehende Aufteilung.
const KNOPF_SONDER = ["breit", "schmal", "winzig", "segment", "klein"];
function knopfBreiteSichern(knopf) {
    if (!knopf) return;
    if (KNOPF_SONDER.some((k) => knopf.classList.contains(k))) return;
    const text = knopf.textContent;
    if (!text) return;
    const noetig = Math.ceil(textBreite(text, knopfSchrift(knopf))) + 18;
    if (!(noetig > 0)) return;
    let basis = "";
    try { basis = String(getComputedStyle(knopf).flexBasis || ""); } catch (e) { basis = ""; }
    // Steht die Grundbreite auf „auto“, richtet der Knopf sich schon nach
    // seiner Aufschrift und kann gar nicht abschneiden — Finger weg.
    if (!/^\d/.test(basis)) return;
    const grund = parseFloat(basis) || 0;
    if (noetig <= grund) return;
    knopf.style.flexBasis = noetig + "px";
    knopf.style.minWidth  = noetig + "px";
}

function knoepfeKuerzen(erzwingen) {
    const breite = elementBreite(document.getElementById("wandInhalt")) ||
                   elementBreite(document.body);
    // Meldet der Wirt gar keine Breite (0), darf der Vergleich nicht dauerhaft
    // blockieren — sonst liefe die Kürzung nach dem ersten Lauf nie wieder.
    if (!erzwingen && breite > 0 && breite === kuerzenBreiteZuletzt) return;
    kuerzenBreiteZuletzt = breite;
    const knoepfe = document.querySelectorAll("#wandInhalt .knopf");
    knoepfe.forEach(knopfTextKuerzen);
    if (messProtokoll.length < 40) {
        const probe = knoepfe[1] || knoepfe[0];
        messProtokoll.push(
            "Wand " + Math.round(breite) +
            " · Knopf " + (probe ? Math.round(elementBreite(probe)) : "?") +
            " · Text \"Newspaper\" " + Math.round(textBreite("Newspaper", "11px")) +
            " · aufgeschrieben \"" + (probe ? probe.textContent : "?") + "\"");
    }
}

// Der Wirt gibt erst Maße heraus, wenn das Bedienfeld tatsächlich SICHTBAR ist.
// Bei "loadEvent": "startup" wird das Dokument lange vorher aufgebaut — eine
// Messung kurz nach dem Laden lieferte deshalb durchweg 0 (auch scrollHeight).
// Also nachfassen, bis eine echte Breite kommt, und erst dann messen. Läuft
// auch bei jedem show() erneut, denn ein zugeklapptes Feld meldet wieder 0.
let messLauf = 0;
function messenWennBereit() {
    const lauf = ++messLauf;
    let versuche = 0;
    const takt = setInterval(() => {
        if (lauf !== messLauf) { clearInterval(takt); return; }   // neuer Lauf hat übernommen
        versuche++;
        const wand = document.getElementById("wandInhalt");
        const da = wand && (elementBreite(wand) > 0 || wand.clientHeight > 0);
        if (da || versuche >= 40) {                               // höchstens 20 Sekunden
            clearInterval(takt);
            knoepfeKuerzen(true);
            messungSchreiben(da ? "sichtbar nach " + (versuche * 500) + " ms"
                                : "NIE Maße bekommen (40 Versuche)");
        }
    }, 500);
}

// Einmal nach dem Aufbau festhalten, was der Wirt wirklich zeichnet — nur so
// ist zu entscheiden, ob background-color auf <button> ankommt oder ob UXP
// seine eigene Knopfform darüberlegt (Baulehre 22).
async function messungSchreiben(notiz) {
    try {
        const zeilen = ["Gemessen " + new Date().toLocaleString(),
                        "Zustand: " + (notiz || "-")];
        zeilen.push("window.innerWidth/Height: " + window.innerWidth + "/" + window.innerHeight);
        const wand = document.getElementById("wandInhalt");
        zeilen.push("wandInhalt: rect " + (wand ? Math.round(elementBreite(wand)) : "?") +
                    " · clientWidth " + (wand ? wand.clientWidth : "?"));
        // DAS ist die Zahl für maximumSize im Manifest: was der Inhalt braucht
        // (scrollHeight) gegen das, was das Bedienfeld hergibt (clientHeight).
        zeilen.push("HÖHE nötig " + (wand ? wand.scrollHeight : "?") +
                    " · vorhanden " + (wand ? wand.clientHeight : "?"));
        document.querySelectorAll("#wandInhalt .knopf").forEach((k, i) => {
            let st = null;
            try { st = getComputedStyle(k); } catch (e) { /* dann ohne */ }
            zeilen.push("Knopf " + i + " \"" + k.textContent + "\" (voll \"" +
                (k.dataset.voll === undefined ? "-" : k.dataset.voll) + "\") " +
                Math.round(elementBreite(k)) + "px · flexBasis " +
                (k.style.flexBasis || "-") + " · Text " +
                Math.round(textBreite(k.textContent, knopfSchrift(k))) +
                " · POLSTER " + (elementBreite(k) > 0
                    ? Math.round(elementBreite(k) - textBreite(k.textContent, knopfSchrift(k)))
                    : "?") +
                (st ? " · bg " + st.backgroundColor + " · radius " + st.borderRadius +
                      " · border " + st.borderColor + " " + st.borderStyle : ""));
        });
        zeilen.push("--- Läufe der Kürzung ---");
        zeilen.push(...messProtokoll);
        const ordner = await datenOrdner();
        const datei  = await ordner.createFile("mess-knoepfe.txt", { overwrite: true });
        await datei.write(zeilen.join("\n"));
    } catch (e) { /* Messung ist Beiwerk */ }
}

// ============================================================================
//  Einstellungen sichern und laden
// ============================================================================

async function datenOrdner() {
    return await lfs.getDataFolder();
}

async function eintragOderNull(ordner, name) {
    try { return await ordner.getEntry(name); } catch (e) { return null; }
}

// Die Bild-Garnitur eines Knopfes in eine verlässliche Form bringen — fehlende
// Felder ergänzen, Zahlen deckeln, für PNG unmögliches CMYK zurückdrehen.
function bildSaeubern(wert, format) {
    if (format !== "JPG" && format !== "PNG") return null;
    const bild = Object.assign(standardBild(format), (wert && typeof wert === "object") ? wert : {});
    bild.qualitaet  = String(bild.qualitaet || "MAXIMUM");
    bild.masz       = (bild.masz === "pixel") ? "pixel" : "ppi";
    bild.aufloesung = Math.max(9, Math.min(2400, Math.round(zahl(bild.aufloesung, (format === "PNG") ? 150 : 300))));
    bild.breitePx   = Math.max(0, Math.round(zahl(bild.breitePx, 0)));
    bild.hoehePx    = Math.max(0, Math.round(zahl(bild.hoehePx, 0)));
    if (format === "PNG" && bild.farbraum === "CMYK") bild.farbraum = "RGB";
    return bild;
}

async function einstellungenLaden() {
    try {
        const ordner = await datenOrdner();
        const datei = await eintragOderNull(ordner, EINSTELLUNGSDATEI);
        if (datei) {
            const inhalt = await datei.read();
            const gelesen = JSON.parse(inhalt);
            einstellungen = Object.assign(standardEinstellungen(), gelesen);
            // Die Zahl der Knöpfe ist frei — nur die Form muss stimmen.
            if (!Array.isArray(einstellungen.slots)) einstellungen.slots = standardEinstellungen().slots;
            // Ältere Fassungen kannten kein Format je Knopf: die Slots waren
            // reine PDF-Knöpfe, JPG und PNG hatten feste Tabellen daneben.
            const alteFassung = !einstellungen.slots.some(slot => slot && slot.format) &&
                                !!(gelesen.jpg || gelesen.png);
            einstellungen.slots = einstellungen.slots.map(slot => {
                const format = (slot && (slot.format === "JPG" || slot.format === "PNG"))
                    ? slot.format : "PDF";
                return {
                    name:         String((slot && slot.name) || format),
                    format:       format,
                    vorgabe:      String((slot && slot.vorgabe) || ""),
                    unterordner:  String((slot && slot.unterordner) || ""),
                    einzelseiten: !!(slot && slot.einzelseiten),
                    bild:         bildSaeubern(slot && slot.bild, format)
                };
            });
            if (alteFassung) {
                // Aus den alten JPG-/PNG-Tabellen werden zwei Bild-Knöpfe —
                // die eingestellten Werte gehen dabei nicht verloren.
                einstellungen.slots.push({ name: "JPG", format: "JPG", vorgabe: "",
                    unterordner: "", einzelseiten: false, bild: bildSaeubern(gelesen.jpg, "JPG") });
                einstellungen.slots.push({ name: "PNG", format: "PNG", vorgabe: "",
                    unterordner: "", einzelseiten: false, bild: bildSaeubern(gelesen.png, "PNG") });
            }
            // Die alten Tabellen wohnen jetzt in den Knöpfen.
            delete einstellungen.jpg;
            delete einstellungen.png;
        }
    } catch (e) {
        einstellungen = standardEinstellungen();
    }
    await vorgabenErgaenzen();
    return einstellungen;
}

// Beim ersten Start stehen noch keine PDF-Vorgaben in den Knöpfen. Dann werden
// welche vorgeschlagen, die zum Namen passen — sonst die erste vorhandene.
// Bild-Knöpfe brauchen keine Vorgabe und bleiben unangetastet.
async function vorgabenErgaenzen() {
    let namen = [];
    try { namen = pdfVorgabenNamen(); } catch (e) { return; }
    if (!namen.length) return;
    // Für die ersten drei PDF-Knöpfe gibt es einen Vorschlag, der zum Namen
    // passt; alles Weitere bekommt einfach die erste vorhandene Vorgabe.
    const wunsch = [
        ["[Druckausgabequalität]", "[High Quality Print]", "[PDF/X-4:2008]", "print"],
        ["[Qualitativ hochwertiger Druck]", "zeitung", "newspaper", "[PDF/X-1a:2001]"],
        ["web", "[Kleinste Dateigröße]", "[Smallest File Size]"]
    ];
    let pdfNummer = 0;
    einstellungen.slots.forEach((slot) => {
        if (slot.format !== "PDF") return;
        const i = pdfNummer++;
        if (slot.vorgabe && namen.indexOf(slot.vorgabe) >= 0) return;
        let treffer = "";
        for (const w of (wunsch[i] || [])) {
            for (const n of namen) {
                if (String(n).toLowerCase() === String(w).toLowerCase()) { treffer = n; break; }
            }
            if (treffer) break;
        }
        slot.vorgabe = treffer || namen[0];
    });
}

async function einstellungenSichern() {
    try {
        const ordner = await datenOrdner();
        const datei = await ordner.createFile(EINSTELLUNGSDATEI, { overwrite: true });
        await datei.write(JSON.stringify(einstellungen, null, 2));
        return true;
    } catch (e) {
        status("Einstellungen ließen sich nicht sichern: " + e, "fehler");
        return false;
    }
}

// ============================================================================
//  Ordner und Dateinamen
// ============================================================================

// UXP kennt mehrere Wege zu einem Ordner; welcher trägt, hängt an Pfad und
// Fassung. Deshalb der Reihe nach.
async function ordnerAusPfad(pfad) {
    if (!pfad) return null;
    const alsUrl = String(pfad).replace(/\\/g, "/");
    const wege = [
        () => lfs.getEntryWithUrl("file:" + pfad),
        () => lfs.getEntryWithUrl("file:///" + alsUrl.replace(/^\//, "")),   // Windows: file:///C:/…
        () => lfs.getEntryWithUrl("file://" + encodeURI(pfad)),
        () => lfs.getEntry(pfad)
    ];
    for (const weg of wege) {
        try {
            const eintrag = await weg();
            if (eintrag) return eintrag;
        } catch (e) { /* nächster Versuch */ }
    }
    return null;
}

// Windows meldet Pfade mit Gegenschrägstrich. Beim Zusammensetzen denselben
// Trenner verwenden, sonst kommt ein Mischmasch heraus.
function pfadVerbinden(ordner, name) {
    const pfad = String(ordner);
    const trenner = (pfad.indexOf("\\") >= 0 && pfad.indexOf("/") < 0) ? "\\" : "/";
    return pfad.replace(/[\\\/]+$/, "") + trenner + name;
}

// doc.filePath (und doc.fullName) sind im UXP-DOM von InDesign PROMISES
// (Baulehre 32, live gemessen): sie lösen auf einen UXP-Ordner-/Dateieintrag
// mit nativePath auf. Ohne await liest man an der Promise nur undefined und
// hält jedes gesicherte Dokument für ortlos — Verpacken brach ab, und der
// Export nach „Ordner des Dokuments“ fiel still auf den Auswahldialog zurück.
async function dokumentOrdnerPfad(doc) {
    try {
        if (!doc.saved) return null;
        let p = doc.filePath;
        if (p && typeof p.then === "function") p = await p;
        if (!p) return null;
        if (typeof p === "string") return p;
        return p.nativePath || p.fsName || p.absoluteURI || null;
    } catch (e) {
        return null;
    }
}

async function unterordnerAnlegen(ordner, name) {
    const sauber = sauberName(name);
    if (!sauber || !String(name).replace(/^\s+|\s+$/g, "").length) return ordner;
    const vorhanden = await eintragOderNull(ordner, sauber);
    if (vorhanden) return vorhanden;
    return await ordner.createFolder(sauber);
}

async function zielOrdner(slot) {
    const { app } = indesign();
    const doc = app.activeDocument;
    let basis = null;

    if (einstellungen.zielArt === "fest") {
        basis = await ordnerAusPfad(einstellungen.zielOrdner);
        if (!basis) basis = await lfs.getFolder();
    } else if (einstellungen.zielArt === "fragen") {
        basis = await lfs.getFolder();
    } else {
        const pfad = await dokumentOrdnerPfad(doc);
        if (pfad) basis = await ordnerAusPfad(pfad);
        if (!basis) basis = await lfs.getFolder();
    }
    if (!basis) return null;

    let ziel = await unterordnerAnlegen(basis, einstellungen.unterordner);
    if (slot && slot.unterordner) ziel = await unterordnerAnlegen(ziel, slot.unterordner);
    return ziel;
}

// musterVorlage ist nur für die Vorschau im Einstellungsfenster gedacht: dort
// soll der Feldinhalt wirken, bevor er gesichert ist.
function nameBauen(knopfName, format, teilName, nummer, musterVorlage) {
    let muster = String((musterVorlage === undefined || musterVorlage === null)
        ? (einstellungen.muster || "")
        : musterVorlage).replace(/^\s+|\s+$/g, "");
    if (!muster.length) muster = "{dok}";
    const { app } = indesign();
    let dokName = "Dokument";
    try { dokName = ohneEndung(app.activeDocument.name); } catch (e) { /* kein Dokument */ }
    let name = muster;
    name = name.replace(/\{dok\}/g,   dokName);
    name = name.replace(/\{knopf\}/g, knopfName || "");
    name = name.replace(/\{datum\}/g, heute());
    name = name.replace(/\{zeit\}/g,  uhrzeit());
    name = name.replace(/\{format\}/g, String(format).toLowerCase());
    name = name.replace(/\{seite\}/g, (teilName === null || teilName === undefined) ? "" : String(teilName));
    name = name.replace(/\{nr\}/g,    (nummer === null || nummer === undefined) ? "" : fuellen(nummer, 3));
    return sauberName(name);
}

// Bei mehreren Dateien muss der Name unterscheiden. Wer keinen Platzhalter
// gesetzt hat, bekommt die Seite hinten angehängt — sonst überschreibt sich
// der Export selbst.
function nameMitTeil(knopfName, format, teilName, nummer, mehrere) {
    let name = nameBauen(knopfName, format, teilName, nummer);
    const hatPlatzhalter = /\{seite\}|\{nr\}/.test(String(einstellungen.muster));
    if (mehrere && !hatPlatzhalter && teilName !== null && teilName !== undefined)
        name = name + "_" + sauberName(teilName);
    return name;
}

function freierName(vorhanden, name, endung) {
    let voll = name + "." + endung, zaehler = 2;
    if (einstellungen.ueberschreiben) return voll;
    while (vorhanden.has(voll) && zaehler < 1000) {
        voll = name + "_" + zaehler + "." + endung;
        zaehler++;
    }
    vorhanden.add(voll);
    return voll;
}

async function vorhandeneNamen(ordner) {
    const menge = new Set();
    try {
        const eintraege = await ordner.getEntries();
        for (const e of eintraege) menge.add(e.name);
    } catch (e) { /* leerer Ordner ist auch eine Antwort */ }
    return menge;
}

// ============================================================================
//  Seiten, Druckbögen, Objekte
// ============================================================================

// Ein Wort aus dem Seitenbereich zu einem Seitenindex machen: erst der
// Seitenname, wie er im Dokument steht (Abschnitte, römische Ziffern), sonst
// die laufende Nummer ab der ersten Seite.
function seiteZuIndex(doc, wort) {
    const name = String(wort).replace(/^\s+|\s+$/g, "");
    if (!name.length) return -1;
    for (let i = 0; i < doc.pages.length; i++)
        if (String(doc.pages.item(i).name) === name) return i;
    const nummer = parseInt(name, 10);
    if (!isNaN(nummer) && nummer >= 1 && nummer <= doc.pages.length) return nummer - 1;
    return -1;
}

// InDesign stürzt beim Bildexport ab, wenn der Seitenbereich Seiten nennt, die
// es nicht gibt (in 21.5.1 nachgestellt). Deshalb wird der Text hier zu echten
// Seiten aufgelöst — an den Export geht nur, was existiert. Unbekannte Seiten
// werden nicht stillschweigend zurechtgebogen, sondern übersprungen und in
// bereichWarnungen gemeldet (die Statuszeile zeigt sie nach dem Export).
function seitenAusBereich(doc, text) {
    const teile = String(text).split(",");
    const gesehen = {}, raus = [];
    bereichWarnungen = [];
    const unbekannt = (wort) => {
        bereichWarnungen.push("Seite „" + wort + "“ gibt es nicht — übersprungen");
    };
    for (const stueck of teile) {
        const wort = stueck.replace(/^\s+|\s+$/g, "");
        if (!wort.length) continue;
        const strich = wort.indexOf("-", 1);
        if (strich > 0) {
            const vorn   = wort.substring(0, strich).replace(/^\s+|\s+$/g, "");
            const hinten = wort.substring(strich + 1).replace(/^\s+|\s+$/g, "");
            let a = seiteZuIndex(doc, vorn);
            // Ein offenes Ende („3-“) heißt weiterhin: bis zur letzten Seite.
            let b = hinten.length ? seiteZuIndex(doc, hinten) : doc.pages.length - 1;
            if (a < 0) { unbekannt(vorn); continue; }
            if (b < 0) { unbekannt(hinten); continue; }
            if (a > b) { const x = a; a = b; b = x; }
            for (let x = a; x <= b; x++)
                if (!gesehen[x]) { gesehen[x] = true; raus.push(doc.pages.item(x)); }
        } else {
            const a = seiteZuIndex(doc, wort);
            if (a < 0) { unbekannt(wort); continue; }
            if (!gesehen[a]) { gesehen[a] = true; raus.push(doc.pages.item(a)); }
        }
    }
    return raus;
}

function seitenDerAuswahl(doc) {
    const { app } = indesign();
    const gesehen = {}, raus = [];
    if (!app.selection) return raus;
    for (let i = 0; i < app.selection.length; i++) {
        let seite = null;
        try { seite = app.selection[i].parentPage; } catch (e) { seite = null; }
        if (!seite) {
            try { seite = app.selection[i].parentTextFrames[0].parentPage; } catch (e) { seite = null; }
        }
        if (seite && !gesehen[seite.id]) { gesehen[seite.id] = true; raus.push(seite); }
    }
    return raus;
}

function seitenFuerUmfang(doc) {
    const { app } = indesign();
    if (einstellungen.umfang === "aktuelle") {
        try { return [app.activeWindow.activePage]; } catch (e) { return []; }
    }
    if (einstellungen.umfang === "bereich") return seitenAusBereich(doc, einstellungen.bereich);
    if (einstellungen.umfang === "auswahl") return seitenDerAuswahl(doc);
    const alle = [];
    for (let i = 0; i < doc.pages.length; i++) alle.push(doc.pages.item(i));
    return alle;
}

// Aus Seiten Druckbögen machen — je Bogen bleibt die erste getroffene Seite
// stehen, denn der Bildexport spricht einen Bogen über eine seiner Seiten an.
function zuDruckbogen(seiten) {
    const gesehen = {}, raus = [];
    for (const seite of seiten) {
        let bogen = null;
        try { bogen = seite.parent; } catch (e) { bogen = null; }
        if (!bogen) continue;
        if (!gesehen[bogen.id]) { gesehen[bogen.id] = true; raus.push(seite); }
    }
    return raus;
}

function objekteDerAuswahl() {
    const { app } = indesign();
    const raus = [];
    if (!app.selection) return raus;
    for (let i = 0; i < app.selection.length; i++) {
        try {
            const objekt = app.selection[i];
            if (typeof objekt.exportFile === "function" && objekt.geometricBounds.length === 4)
                raus.push(objekt);
        } catch (e) { /* Text, Tabellen und dergleichen können das nicht */ }
    }
    return raus;
}

// Absolute Seitenangabe („+7“) — unabhängig von Abschnitten und Nummerierungen.
function absolut(seite) { return "+" + (seite.documentOffset + 1); }

// ============================================================================
//  Pixelmaß → Auflösung
// ----------------------------------------------------------------------------
// Statt einer Auflösung lässt sich eine Zielgröße in Bildpunkten angeben. Die
// nötige Auflösung hängt dann davon ab, wie groß das Exportierte in Zentimetern
// ist — und das ist bei jeder Seite und jedem Objekt anders. Deshalb wird sie
// je Datei neu ausgerechnet.
// ============================================================================

// Maße in Punkt. InDesign liefert Grenzen in der gerade eingestellten
// Maßeinheit — die wird kurz auf Punkt gestellt und danach zurückgedreht.
function inPunkt(fn) {
    const idsn = indesign(), app = idsn.app;
    let alt = null, raus = null;
    try { alt = app.scriptPreferences.measurementUnit; } catch (e) {}
    try {
        app.scriptPreferences.measurementUnit = idsn.MeasurementUnits.POINTS;
        raus = fn();
    } catch (e) {
        raus = null;
    } finally {
        try { if (alt !== null) app.scriptPreferences.measurementUnit = alt; } catch (e) {}
    }
    return raus;
}

function anschnittZugabe(doc, waagerecht) {
    let zugabe = 0;
    try {
        const p = doc.documentPreferences;
        zugabe = waagerecht
            ? (p.documentBleedInsideOrLeftOffset + p.documentBleedOutsideOrRightOffset)
            : (p.documentBleedTopOffset + p.documentBleedBottomOffset);
    } catch (e) { zugabe = 0; }
    return zugabe || 0;
}

// Größe dessen, was gleich exportiert wird — Seite, ganzer Druckbogen oder
// Objekt, wahlweise samt Anschnitt.
function exportMasse(doc, ziel, alsBogen, mitAnschnitt) {
    return inPunkt(() => {
        let stuecke = [ziel];
        if (alsBogen) {
            try { stuecke = ziel.parent.pages.everyItem().getElements(); } catch (e) { stuecke = [ziel]; }
        }
        let oben = null, links = null, unten = null, rechts = null;
        for (const stueck of stuecke) {
            let g = null;
            try { g = stueck.bounds; } catch (e) { g = null; }
            if (!g) { try { g = stueck.visibleBounds; } catch (e) { g = null; } }
            if (!g || g.length < 4) continue;
            if (oben === null || g[0] < oben) oben = g[0];
            if (links === null || g[1] < links) links = g[1];
            if (unten === null || g[2] > unten) unten = g[2];
            if (rechts === null || g[3] > rechts) rechts = g[3];
        }
        if (oben === null) return null;
        let breite = rechts - links, hoehe = unten - oben;
        if (mitAnschnitt) {
            breite += anschnittZugabe(doc, true);
            hoehe  += anschnittZugabe(doc, false);
        }
        return { breite: breite, hoehe: hoehe };
    });
}

// Der höhere der beiden Wünsche bestimmt die Auflösung; ein leeres Feld
// zählt nicht mit.
function aufloesungAus(einst, masse) {
    const standard = Math.round(zahl(einst.aufloesung, 300));
    if (einst.masz !== "pixel" || !masse) return standard;
    const breiteZoll = masse.breite / 72, hoeheZoll = masse.hoehe / 72;
    const werte = [];
    const wunschBreite = Math.round(zahl(einst.breitePx, 0));
    const wunschHoehe  = Math.round(zahl(einst.hoehePx, 0));
    if (wunschBreite > 0 && breiteZoll > 0.01) werte.push(wunschBreite / breiteZoll);
    if (wunschHoehe  > 0 && hoeheZoll  > 0.01) werte.push(wunschHoehe  / hoeheZoll);
    if (!werte.length) return standard;
    let ppi = Math.max.apply(null, werte);
    return Math.max(9, Math.min(2400, Math.round(ppi)));
}

function aufloesungSetzen(format, ppi) {
    const { app } = indesign();
    const p = (format === "PNG") ? app.pngExportPreferences : app.jpegExportPreferences;
    try { p.exportResolution = ppi; } catch (e) {}
}

// ============================================================================
//  Export
// ============================================================================

function pdfVorgabenNamen() {
    const { app } = indesign();
    const namen = [];
    for (let i = 0; i < app.pdfExportPresets.length; i++)
        namen.push(String(app.pdfExportPresets.item(i).name));
    return namen;
}

async function exportPdf(slot, ordner, seiten) {
    const idsn = indesign(), app = idsn.app;
    let vorgabe = null;
    // Beim allerersten Start kann die Zuordnung noch leer sein (die
    // PDF-Vorgaben stehen erst bereit, wenn InDesign fertig geladen hat).
    if (!slot.vorgabe) { await vorgabenErgaenzen(); }
    try {
        const treffer = app.pdfExportPresets.itemByName(slot.vorgabe);
        if (treffer.isValid) vorgabe = treffer;
    } catch (e) { vorgabe = null; }
    if (!vorgabe)
        throw new Error("Die PDF-Vorgabe „" + slot.vorgabe + "“ gibt es nicht (mehr). " +
                        "Bitte unter „…“ eine andere zuordnen.");

    const doc = app.activeDocument;
    const vorhanden = await vorhandeneNamen(ordner);
    const dateien = [];
    const altBereich = app.pdfExportPreferences.pageRange;
    try {
        if (slot.einzelseiten) {
            const mehrere = seiten.length > 1;
            for (let i = 0; i < seiten.length; i++) {
                if (abbruchGewuenscht) break;
                if (mehrere) {
                    status(slot.name + ": Seite " + String(seiten[i].name) +
                           " (" + (i + 1) + " von " + seiten.length + ") …");
                    await kurzeAtempause();
                }
                app.pdfExportPreferences.pageRange = absolut(seiten[i]);
                const name = nameMitTeil(slot.name, "PDF", String(seiten[i].name), i + 1, mehrere);
                const datei = freierName(vorhanden, name, "pdf");
                doc.exportFile(idsn.ExportFormat.PDF_TYPE, pfadVerbinden(ordner.nativePath, datei), false, vorgabe);
                dateien.push(datei);
            }
        } else {
            app.pdfExportPreferences.pageRange = (seiten.length === doc.pages.length)
                ? idsn.PageRange.ALL_PAGES
                : seiten.map(absolut).join(",");
            const name = nameMitTeil(slot.name, "PDF", null, null, false);
            const datei = freierName(vorhanden, name, "pdf");
            doc.exportFile(idsn.ExportFormat.PDF_TYPE, pfadVerbinden(ordner.nativePath, datei), false, vorgabe);
            dateien.push(datei);
        }
    } finally {
        try { app.pdfExportPreferences.pageRange = altBereich; } catch (e) {}
    }
    return dateien;
}

function bildVoreinstellungenSichern(format) {
    const { app } = indesign();
    const p = (format === "PNG") ? app.pngExportPreferences : app.jpegExportPreferences;
    const alt = {};
    const felder = (format === "PNG")
        ? ["exportResolution", "pngQuality", "pngColorSpace", "transparentBackground",
           "antiAlias", "useDocumentBleeds", "pngExportRange", "pageString",
           "exportingSpread", "pngSuffix"]
        : ["exportResolution", "jpegQuality", "jpegColorSpace", "embedColorProfile",
           "antiAlias", "useDocumentBleeds", "jpegExportRange", "pageString",
           "exportingSpread", "jpegSuffix"];
    for (const feld of felder) {
        try { alt[feld] = p[feld]; } catch (e) {}
    }
    return alt;
}

function bildVoreinstellungenZurueck(format, alt) {
    const { app } = indesign();
    const p = (format === "PNG") ? app.pngExportPreferences : app.jpegExportPreferences;
    for (const feld in alt) {
        if (!Object.prototype.hasOwnProperty.call(alt, feld)) continue;
        try { p[feld] = alt[feld]; } catch (e) {}
    }
}

// Der Anhang, den InDesign von sich aus an Bilddateien hängt (in den
// Voreinstellungen steht dort gern noch etwas wie „_1200dpi“ vom letzten
// Export über den Dialog). Muss leer sein, sonst stimmt kein Dateiname.
// e ist die Bild-Garnitur des Knopfes (slot.bild).
function bildVorbereiten(format, e) {
    const idsn = indesign(), app = idsn.app;
    if (format === "PNG") {
        const p = app.pngExportPreferences;
        p.pngSuffix             = "";
        p.exportResolution      = Math.round(zahl(e.aufloesung, 150));   // je Datei nachgestellt
        p.pngQuality            = idsn.PNGQualityEnum[e.qualitaet];
        p.pngColorSpace         = idsn.PNGColorSpaceEnum[e.farbraum];
        p.transparentBackground = e.transparenz === true;
        p.antiAlias             = e.kanten === true;
        p.useDocumentBleeds     = e.anschnitt === true;
        p.exportingSpread       = einstellungen.druckbogen === true;
    } else {
        const p = app.jpegExportPreferences;
        p.jpegSuffix        = "";
        p.exportResolution  = Math.round(zahl(e.aufloesung, 300));       // je Datei nachgestellt
        p.jpegQuality       = idsn.JPEGOptionsQuality[e.qualitaet];
        p.jpegColorSpace    = idsn.JpegColorSpaceEnum[e.farbraum];
        p.embedColorProfile = e.icc === true;
        p.antiAlias         = e.kanten === true;
        p.useDocumentBleeds = e.anschnitt === true;
        p.exportingSpread   = einstellungen.druckbogen === true;
    }
}

function bildBereich(format, seite) {
    const idsn = indesign(), app = idsn.app;
    if (format === "PNG") {
        app.pngExportPreferences.pngExportRange = idsn.PNGExportRangeEnum.EXPORT_RANGE;
        app.pngExportPreferences.pageString = absolut(seite);
    } else {
        app.jpegExportPreferences.jpegExportRange = idsn.ExportRangeOrAllPages.EXPORT_RANGE;
        app.jpegExportPreferences.pageString = absolut(seite);
    }
}

async function exportBild(slot, ordner, seiten) {
    const idsn = indesign(), app = idsn.app, doc = app.activeDocument;
    const format = slot.format;
    const endung = (format === "PNG") ? "png" : "jpg";
    const alt = bildVoreinstellungenSichern(format);
    const vorhanden = await vorhandeneNamen(ordner);
    const dateien = [];
    try {
        const einst = slot.bild || standardBild(format);
        bildVorbereiten(format, einst);
        const mehrere = seiten.length > 1;
        for (let i = 0; i < seiten.length; i++) {
            if (abbruchGewuenscht) break;
            if (mehrere) {
                status(slot.name + ": Seite " + String(seiten[i].name) +
                       " (" + (i + 1) + " von " + seiten.length + ") …");
                await kurzeAtempause();
            }
            bildBereich(format, seiten[i]);
            if (einst.masz === "pixel") {
                const masse = exportMasse(doc, seiten[i], einstellungen.druckbogen === true,
                                          einst.anschnitt === true);
                letzteAufloesung = aufloesungAus(einst, masse);
                aufloesungSetzen(format, letzteAufloesung);
            }
            const teil = einstellungen.druckbogen
                ? ("Bogen-" + String(seiten[i].name))
                : String(seiten[i].name);
            const name  = nameMitTeil(slot.name, format, teil, i + 1, mehrere);
            const datei = freierName(vorhanden, name, endung);
            doc.exportFile(idsn.ExportFormat[format === "PNG" ? "PNG_FORMAT" : "JPG"],
                           pfadVerbinden(ordner.nativePath, datei));
            dateien.push(datei);
        }
    } finally {
        bildVoreinstellungenZurueck(format, alt);
    }
    return dateien;
}

// Eine Auswahl als Bild kann nur das Objekt selbst, nicht das Dokument.
async function exportObjekte(slot, ordner, objekte) {
    const idsn = indesign();
    const format = slot.format;
    const endung = (format === "PNG") ? "png" : "jpg";
    const alt = bildVoreinstellungenSichern(format);
    const vorhanden = await vorhandeneNamen(ordner);
    const dateien = [];
    try {
        const einst = slot.bild || standardBild(format);
        bildVorbereiten(format, einst);
        const doc = indesign().app.activeDocument;
        const mehrere = objekte.length > 1;
        for (let i = 0; i < objekte.length; i++) {
            if (abbruchGewuenscht) break;
            if (mehrere) {
                status(slot.name + ": Objekt " + (i + 1) + " von " + objekte.length + " …");
                await kurzeAtempause();
            }
            if (einst.masz === "pixel") {
                const masse = exportMasse(doc, objekte[i], false, einst.anschnitt === true);
                letzteAufloesung = aufloesungAus(einst, masse);
                aufloesungSetzen(format, letzteAufloesung);
            }
            const teil  = "Objekt-" + fuellen(i + 1, 2);
            const name  = nameMitTeil(slot.name, format, teil, i + 1, mehrere);
            const datei = freierName(vorhanden, name, endung);
            objekte[i].exportFile(idsn.ExportFormat[format === "PNG" ? "PNG_FORMAT" : "JPG"],
                                  pfadVerbinden(ordner.nativePath, datei));
            dateien.push(datei);
        }
    } finally {
        bildVoreinstellungenZurueck(format, alt);
    }
    return dateien;
}

// Den ersten Knopf mit diesem Format finden — für den Selbsttest.
function slotIndexFuerFormat(format) {
    for (let i = 0; i < einstellungen.slots.length; i++)
        if (einstellungen.slots[i].format === format) return i;
    return -1;
}

// Während eines Exports sind alle Knöpfe gesperrt — nur der laufende bleibt
// bedienbar, denn er ist jetzt der „Anhalten“-Knopf.
function knoepfeSperren(aktiv) {
    document.querySelectorAll(".leiste .knopf").forEach(knopf => {
        knopfGesperrt(knopf, knopf !== aktiv);
    });
}

function knoepfeBeleben() {
    document.querySelectorAll(".leiste .knopf").forEach(knopf => {
        knopfGesperrt(knopf, false);
    });
}

async function exportieren(slotIndex, knopfElement) {
    if (arbeitet) {
        // Der laufende Knopf heißt gerade „Anhalten“: den gewünschten Abbruch
        // merken — die Exportschleife hört vor der nächsten Datei darauf.
        // Ein Klick unmittelbar nach dem Start ist aber der zweite Teil eines
        // Doppelklicks und zählt nicht als Abbruchwunsch.
        if (Date.now() - exportBeginn < 600) return;
        abbruchGewuenscht = true;
        status("wird nach der laufenden Datei angehalten …");
        return;
    }
    const idsn = indesign(), app = idsn.app;
    const slot = einstellungen.slots[slotIndex];
    if (!slot) return;
    const format = slot.format || "PDF";
    if (!app.documents.length) { status("Kein Dokument geöffnet.", "fehler"); return; }

    arbeitet = true;
    abbruchGewuenscht = false;
    exportBeginn = Date.now();
    document.body.classList.add("arbeitet");
    const knopf = knopfElement || null;
    const knopfText = knopf ? knopf.textContent : "";
    if (knopf) knopf.textContent = "Anhalten";
    knoepfeSperren(knopf);
    statusZiel("");
    const knopfName = slot.name;
    status(knopfName + " läuft …");

    try {
        await kurzeAtempause();   // damit „läuft …“ vor dem ersten Export erscheint
        const doc = app.activeDocument;
        let dateien = [], ordner = null, zusatz = "";
        letzteAufloesung = 0;
        bereichWarnungen = [];

        if (format !== "PDF" && einstellungen.umfang === "auswahl") {
            const objekte = objekteDerAuswahl();
            if (!objekte.length) { status("Nichts ausgewählt, was sich exportieren ließe.", "fehler"); return; }
            ordner = await zielOrdner(slot);
            if (!ordner) { status("Abgebrochen."); return; }
            dateien = await exportObjekte(slot, ordner, objekte);
        } else {
            let seiten = seitenFuerUmfang(doc);
            if (!seiten.length) {
                status(bereichWarnungen.length
                    ? "Der Seitenbereich trifft keine Seite — " + bereichWarnungen.join(", ") + "."
                    : (einstellungen.umfang === "auswahl"
                        ? "Nichts ausgewählt."
                        : "Der Seitenbereich trifft keine Seite."), "fehler");
                return;
            }
            if (format === "PDF" && einstellungen.umfang === "auswahl") zusatz = " (Seiten der Auswahl)";
            if (format !== "PDF" && einstellungen.druckbogen) seiten = zuDruckbogen(seiten);
            ordner = await zielOrdner(slot);
            if (!ordner) { status("Abgebrochen."); return; }
            dateien = (format === "PDF")
                ? await exportPdf(slot, ordner, seiten)
                : await exportBild(slot, ordner, seiten);
        }

        if (einstellungen.danach === "finder") {
            try { await uxp.shell.openPath(ordner.nativePath); } catch (e) {}
        } else if (einstellungen.danach === "datei" && dateien.length) {
            // Bei genau einer Datei die Datei selbst — sonst der Ordner.
            const pfad = (dateien.length === 1)
                ? pfadVerbinden(ordner.nativePath, dateien[0])
                : ordner.nativePath;
            try { await uxp.shell.openPath(pfad); } catch (e) {}
        }
        const einst = slot.bild;
        if (einst && einst.masz === "pixel" && letzteAufloesung)
            zusatz += " · " + letzteAufloesung + " ppi";
        if (bereichWarnungen.length)
            zusatz += " · " + bereichWarnungen.join(", ");
        statusZiel(ordner.nativePath);
        status((abbruchGewuenscht ? "Angehalten — " : "") + knopfName + ": " +
               dateien.length + (dateien.length === 1 ? " Datei" : " Dateien") +
               zusatz + " → " + ordner.name,
               (abbruchGewuenscht || bereichWarnungen.length) ? undefined : "erfolg");
    } catch (fehler) {
        statusZiel("");
        status("Abgebrochen: " + (fehler && fehler.message ? fehler.message : fehler), "fehler");
    } finally {
        arbeitet = false;
        abbruchGewuenscht = false;
        document.body.classList.remove("arbeitet");
        if (knopf) knopf.textContent = knopfText;
        knoepfeBeleben();
    }
}

// ============================================================================
//  Verpacken
// ----------------------------------------------------------------------------
// Sichert das Dokument und verpackt es wie über Datei ▸ Verpacken: Schriften,
// verknüpfte Grafiken und Farbprofile wandern in einen Ordner
// „‹Dokument› verpackt“ neben der Dokumentdatei — unabhängig vom Zielordner
// der Exporte, denn das Paket gehört zur Quelle, nicht zur Ausgabe. Ist
// „vorhandene Dateien überschreiben“ aus, wird ein belegter Ordnername
// numeriert („… verpackt 2“) statt hineingeschrieben.
// ============================================================================

async function verpacken() {
    if (arbeitet) return;
    const idsn = indesign(), app = idsn.app;
    if (!app.documents.length) { status("Kein Dokument geöffnet.", "fehler"); return; }
    const doc = app.activeDocument;

    // Ohne gesicherte Datei gibt es keinen Ort, neben dem das Paket wohnen
    // könnte — und ein Sichern-Dialog aus dem Bedienfeld heraus ist heikel.
    if (!doc.saved) {
        status("Das Dokument wurde noch nie gesichert — bitte erst „Sichern unter …“.", "fehler");
        return;
    }

    arbeitet = true;
    document.body.classList.add("arbeitet");
    knoepfeSperren(null);   // Verpacken kennt kein Anhalten — alles sperren
    statusZiel("");
    try {
        status("Verpacken läuft …");
        await kurzeAtempause();
        if (doc.modified) doc.save();

        const basis = await ordnerAusPfad(await dokumentOrdnerPfad(doc));
        if (!basis) throw new Error("Der Ordner des Dokuments ließ sich nicht öffnen.");

        const grund = sauberName(ohneEndung(doc.name)) + " verpackt";
        let name = grund, zaehler = 2;
        if (!einstellungen.ueberschreiben) {
            while (await eintragOderNull(basis, name) && zaehler < 1000) {
                name = grund + " " + zaehler;
                zaehler++;
            }
        }
        const vorhanden = await eintragOderNull(basis, name);
        const paket = vorhanden || await basis.createFolder(name);

        const gelungen = doc.packageForPrint(
            pfadVerbinden(basis.nativePath, name),
            true,    // Schriften kopieren
            true,    // verknüpfte Grafiken kopieren
            true,    // Farbprofile kopieren
            true,    // Verknüpfungen im Paket aktualisieren
            false,   // ausgeblendete Ebenen bleiben draußen
            true,    // Preflight-Fehler halten nicht auf
            false,   // kein Bericht
            false,   // kein IDML
            false,   // kein PDF
            "",      // PDF-Vorgabe (ohne PDF ohne Belang)
            false,   // nur Silbentrennungs-Ausnahmen des Dokuments (12. Parameter!
                     // — UXP prüft streng: hier stand der Kommentar, „Boolean erwartet“)
            "",      // Versionskommentar
            false    // gesichert wurde schon oben
        );
        if (gelungen === false) throw new Error("InDesign hat das Verpacken abgelehnt.");
        let zusatz = "";

        // Auf Wunsch ein Druck-PDF mit ins Paket — über die gewählte Vorgabe.
        if (einstellungen.verpackenPdf) {
            try {
                let vorgabe = null;
                try {
                    const treffer = app.pdfExportPresets.itemByName(einstellungen.verpackenVorgabe);
                    if (treffer.isValid) vorgabe = treffer;
                } catch (e) { vorgabe = null; }
                if (!vorgabe && app.pdfExportPresets.length) vorgabe = app.pdfExportPresets.item(0);
                if (!vorgabe) throw new Error("keine PDF-Vorgabe da");
                const altBereich = app.pdfExportPreferences.pageRange;
                try {
                    app.pdfExportPreferences.pageRange = idsn.PageRange.ALL_PAGES;
                    doc.exportFile(idsn.ExportFormat.PDF_TYPE,
                                   pfadVerbinden(paket.nativePath, sauberName(ohneEndung(doc.name)) + ".pdf"),
                                   false, vorgabe);
                } finally {
                    try { app.pdfExportPreferences.pageRange = altBereich; } catch (e) {}
                }
                zusatz += " · PDF liegt bei";
            } catch (e) {
                zusatz += " · PDF scheiterte (" + (e && e.message ? e.message : e) + ")";
            }
        }

        // Auf Wunsch das Paket zusätzlich als ZIP daneben legen. UXP kann
        // selbst nicht packen — die Brücke ist ein AppleScript-Einzeiler,
        // deshalb nur am Mac.
        if (einstellungen.verpackenZip) {
            try {
                if (require("os").platform().indexOf("darwin") < 0)
                    throw new Error("ZIP legt nur der Mac an");
                const posix = (s) => "'" + String(s).replace(/'/g, "'\\''") + "'";
                let schale = "cd " + posix(basis.nativePath) + " && rm -f " + posix(name + ".zip") +
                             " && /usr/bin/zip -qry " + posix(name + ".zip") + " " + posix(name);
                const alsAppleText = '"' + schale.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
                app.doScript("do shell script " + alsAppleText, idsn.ScriptLanguage.APPLESCRIPT_LANGUAGE);
                zusatz += " · ZIP liegt daneben";
            } catch (e) {
                zusatz += " · ZIP scheiterte (" + (e && e.message ? e.message : e) + ")";
            }
        }

        if (einstellungen.danach !== "nichts") {
            try { await uxp.shell.openPath(paket.nativePath); } catch (e) {}
        }
        statusZiel(paket.nativePath);
        status("Gesichert und verpackt → " + name + zusatz, "erfolg");
    } catch (fehler) {
        statusZiel("");
        status("Verpacken abgebrochen: " + (fehler && fehler.message ? fehler.message : fehler), "fehler");
    } finally {
        arbeitet = false;
        document.body.classList.remove("arbeitet");
        knoepfeBeleben();
    }
}

// ============================================================================
//  Fenster „Export einstellen“
// ============================================================================

function auswahlFuellen(element, paare, wert) {
    element.innerHTML = "";
    for (const [text, schluessel] of paare) {
        const option = document.createElement("option");
        option.value = schluessel;
        option.textContent = text;
        element.appendChild(option);
    }
    element.value = wert;
}

// Die Knöpfe sind eine freie Liste: hinzufügen, löschen, verschieben, Format
// wechseln. Gearbeitet wird auf einem Entwurf; erst „Sichern“ übernimmt ihn.
let slotsEntwurf = [];
let vorgabenNamenImDialog = [];
// Welcher Bild-Knopf gerade in den Abschnitten JPG/PNG bearbeitet wird —
// gemerkt als Verweis auf den Entwurfs-Slot, denn Indizes verschieben sich
// beim Sortieren und Löschen.
const bildWahl = { JPG: null, PNG: null };

function neuerSlot() {
    return {
        name: "PDF",
        format: "PDF",
        vorgabe: vorgabenNamenImDialog[0] || "",
        unterordner: "",
        einzelseiten: false,
        bild: null
    };
}

// Was gerade in den Feldern steht, in den Entwurf zurückschreiben — sonst
// gehen Eingaben beim Hinzufügen oder Verschieben verloren. Erst die
// Bild-Abschnitte, dann die Tabelle: ein Formatwechsel soll die zuletzt
// getippte Garnitur noch mitnehmen.
function slotsAusFeldern() {
    bildFelderZurueckschreiben();
    slotsEntwurf.forEach((slot, i) => {
        const name    = document.getElementById("slotName" + i);
        const format  = document.getElementById("slotFormat" + i);
        const vorgabe = document.getElementById("slotVorgabe" + i);
        const unter   = document.getElementById("slotUnter" + i);
        const einzeln = document.getElementById("slotEinzeln" + i);
        if (!name) return;
        const text = name.value.replace(/^\s+|\s+$/g, "");
        slot.name         = text.length ? text : slot.name;
        slot.format       = format ? format.value : (slot.format || "PDF");
        slot.vorgabe      = vorgabe ? vorgabe.value : slot.vorgabe;
        slot.unterordner  = unter ? unter.value.replace(/^\s+|\s+$/g, "") : slot.unterordner;
        slot.einzelseiten = einzeln ? einzeln.checked : slot.einzelseiten;
        // Beim Wechsel auf ein Bildformat bekommt der Knopf eine Garnitur,
        // PDF braucht keine.
        slot.bild = (slot.format === "PDF") ? null : bildSaeubern(slot.bild, slot.format);
    });
}

function kleinerKnopf(zeichen, hinweis, tun) {
    const knopf = document.createElement("div");
    knopf.setAttribute("role", "button");
    knopf.setAttribute("tabindex", "0");
    knopf.className = "knopf winzig";
    knopf.textContent = zeichen;
    knopf.setAttribute("title", hinweis);
    knopf.addEventListener("click", () => {
        slotsAusFeldern(); tun(); slotZeilenBauen();
        bildAbschnitteFuellen(); musterVorschauZeigen();
    });
    return knopf;
}

function slotZeilenBauen() {
    const behaelter = document.getElementById("slots");
    const namen = vorgabenNamenImDialog;
    behaelter.innerHTML = "";

    slotsEntwurf.forEach((slot, i) => {
        const zeile = document.createElement("div");
        zeile.className = "slotZeile";

        const name = document.createElement("input");
        name.type = "text"; name.className = "name"; name.value = slot.name;
        name.id = "slotName" + i;
        name.setAttribute("title", "Aufschrift des Knopfes");

        const format = document.createElement("select");
        format.className = "format"; format.id = "slotFormat" + i;
        auswahlFuellen(format, [["PDF", "PDF"], ["JPG", "JPG"], ["PNG", "PNG"]],
                       slot.format || "PDF");
        format.setAttribute("title", "Format des Knopfes");
        format.addEventListener("change", () => {
            slotsAusFeldern(); slotZeilenBauen();
            bildAbschnitteFuellen(); musterVorschauZeigen();
        });

        // PDF-Kn\u00f6pfe w\u00e4hlen eine Vorgabe; Bild-Kn\u00f6pfe zeigen an ihrer Stelle
        // die eigene Garnitur \u2014 eingestellt wird sie in den Abschnitten unten.
        let vorgabe;
        if ((slot.format || "PDF") === "PDF") {
            vorgabe = document.createElement("select");
            vorgabe.className = "vorgabe"; vorgabe.id = "slotVorgabe" + i;
            auswahlFuellen(vorgabe, namen.map(n => [n, n]),
                           namen.indexOf(slot.vorgabe) >= 0 ? slot.vorgabe : (namen[0] || ""));
        } else {
            vorgabe = document.createElement("div");
            vorgabe.className = "vorgabe stumm";
            vorgabe.textContent = bildBeschreibung(slot);
            vorgabe.setAttribute("title",
                "Garnitur dieses Knopfes \u2014 einstellbar im Abschnitt \u201e" + slot.format + "-Kn\u00f6pfe\u201c unten");
        }

        const unter = document.createElement("input");
        unter.type = "text"; unter.className = "unter"; unter.value = slot.unterordner;
        unter.setAttribute("placeholder", "Unterordner");
        unter.id = "slotUnter" + i;

        // \u201eje Seite\u201c gilt nur f\u00fcr PDF \u2014 Bilder entstehen ohnehin je Seite.
        let marke;
        if ((slot.format || "PDF") === "PDF") {
            const einzeln = document.createElement("input");
            einzeln.type = "checkbox"; einzeln.id = "slotEinzeln" + i;
            einzeln.checked = slot.einzelseiten === true;
            marke = document.createElement("label");
            marke.className = "einzeln";
            marke.setAttribute("for", "slotEinzeln" + i);
            marke.appendChild(einzeln);
        } else {
            marke = document.createElement("span");
            marke.className = "einzeln";
        }

        const rauf = kleinerKnopf("\u2191", "nach oben", () => {
            if (i > 0) { const x = slotsEntwurf[i - 1]; slotsEntwurf[i - 1] = slotsEntwurf[i]; slotsEntwurf[i] = x; }
        });
        const runter = kleinerKnopf("\u2193", "nach unten", () => {
            if (i < slotsEntwurf.length - 1) { const x = slotsEntwurf[i + 1]; slotsEntwurf[i + 1] = slotsEntwurf[i]; slotsEntwurf[i] = x; }
        });
        const weg = kleinerKnopf("\u2715", "diesen Knopf löschen", () => {
            slotsEntwurf.splice(i, 1);
        });
        knopfGesperrt(rauf, i === 0);
        knopfGesperrt(runter, i === slotsEntwurf.length - 1);

        zeile.appendChild(name);
        zeile.appendChild(format);
        zeile.appendChild(vorgabe);
        zeile.appendChild(unter);
        zeile.appendChild(marke);
        zeile.appendChild(rauf);
        zeile.appendChild(runter);
        zeile.appendChild(weg);
        behaelter.appendChild(zeile);
    });

    if (!slotsEntwurf.length) {
        const leer = document.createElement("div");
        leer.className = "hinweis";
        leer.textContent = "Keine Knöpfe — mit „+ Knopf“ einen anlegen.";
        behaelter.appendChild(leer);
    }
    rollHinweiseAuffrischen();
}

function felderFuellen() {
    let namen = [];
    try { namen = pdfVorgabenNamen(); } catch (e) { namen = []; }
    const hinweis = document.getElementById("dialogHinweis");
    hinweis.textContent = namen.length ? "" : "Keine PDF-Exportvorgaben gefunden.";
    vorgabenNamenImDialog = namen;
    slotZeilenBauen();

    document.querySelectorAll('input[name="ziel"]').forEach(feld => {
        feld.checked = (feld.value === einstellungen.zielArt);
    });
    document.getElementById("festerOrdner").value = einstellungen.zielOrdner || "";
    document.getElementById("unterordner").value  = einstellungen.unterordner || "";
    document.getElementById("muster").value       = einstellungen.muster || "{dok}";
    document.getElementById("umfang").value       = einstellungen.umfang;
    document.getElementById("bereich").value      = einstellungen.bereich || "";
    document.getElementById("druckbogen").checked = einstellungen.druckbogen === true;
    document.getElementById("ueberschreiben").checked = einstellungen.ueberschreiben === true;
    document.getElementById("danach").value       = einstellungen.danach;

    document.getElementById("verpackenPdf").checked = einstellungen.verpackenPdf === true;
    document.getElementById("verpackenZip").checked = einstellungen.verpackenZip === true;
    auswahlFuellen(document.getElementById("verpackenVorgabe"), namen.map(n => [n, n]),
                   namen.indexOf(einstellungen.verpackenVorgabe) >= 0
                       ? einstellungen.verpackenVorgabe : (namen[0] || ""));

    bildWahl.JPG = null;
    bildWahl.PNG = null;
    bildAbschnitteFuellen();
    bereichSchalten();
    musterVorschauZeigen();
}

// Nur die Felder anbieten, die zur gewählten Art passen — und alles sperren,
// wenn es gar keinen Knopf mit diesem Format gibt.
function maszSchalten() {
    [["JPG", "jpg"], ["PNG", "png"]].forEach(([format, kurz]) => {
        const gesperrt = !bildWahl[format];
        const art = document.getElementById(kurz + "Masz").value;
        document.getElementById(kurz + "Masz").disabled       = gesperrt;
        document.getElementById(kurz + "Aufloesung").disabled = gesperrt || (art !== "ppi");
        document.getElementById(kurz + "BreitePx").disabled   = gesperrt || (art !== "pixel");
        document.getElementById(kurz + "HoehePx").disabled    = gesperrt || (art !== "pixel");
    });
}

// Das Bereichsfeld zählt nur beim Umfang „Seitenbereich“ — sonst ist es aus.
function bereichSchalten() {
    document.getElementById("bereich").disabled =
        (document.getElementById("umfang").value !== "bereich");
}

// Graue Beispielzeile unter dem Muster-Feld: was der erste Knopf mit dem
// gerade getippten Muster als Dateinamen ergäbe.
function musterVorschauZeigen() {
    const feld  = document.getElementById("muster");
    const zeile = document.getElementById("musterVorschau");
    if (!feld || !zeile) return;
    const slot = slotsEntwurf[0] || null;
    const endung = (slot && slot.format !== "PDF") ? slot.format.toLowerCase() : "pdf";
    let beispiel = "";
    try {
        beispiel = nameBauen(slot ? slot.name : "PDF", endung.toUpperCase(), "1", 1, feld.value);
    } catch (e) { beispiel = ""; }
    zeile.textContent = beispiel
        ? ("Beispiel (erster Knopf, Seite 1): " + beispiel + "." + endung)
        : "";
}

// ---------------------------------------------------------- Bild-Abschnitte
// Die Abschnitte „JPG-Knöpfe“ und „PNG-Knöpfe“ bearbeiten je einen Knopf aus
// der Liste; welcher, wählt das Ausklappfeld darüber.

function bildSlotsImEntwurf(format) {
    return slotsEntwurf.filter(slot => slot.format === format);
}

// Die Feldwerte der beiden Abschnitte in die gerade gewählten Entwurfs-Slots
// zurückschreiben — vor jedem Wechsel und vor dem Sichern.
function bildFelderZurueckschreiben() {
    [["JPG", "jpg"], ["PNG", "png"]].forEach(([format, kurz]) => {
        const slot = bildWahl[format];
        if (!slot || slot.format !== format || slotsEntwurf.indexOf(slot) < 0) return;
        const bild = slot.bild || standardBild(format);
        bild.qualitaet  = document.getElementById(kurz + "Qualitaet").value || bild.qualitaet;
        bild.masz       = document.getElementById(kurz + "Masz").value;
        bild.aufloesung = Math.max(9, Math.min(2400, Math.round(zahl(
            document.getElementById(kurz + "Aufloesung").value, (format === "PNG") ? 150 : 300))));
        bild.breitePx   = Math.max(0, Math.round(zahl(document.getElementById(kurz + "BreitePx").value, 0)));
        bild.hoehePx    = Math.max(0, Math.round(zahl(document.getElementById(kurz + "HoehePx").value, 0)));
        bild.farbraum   = document.getElementById(kurz + "Farbraum").value;
        if (format === "JPG") bild.icc = document.getElementById("jpgIcc").checked;
        else bild.transparenz = document.getElementById("pngTransparenz").checked;
        bild.kanten     = document.getElementById(kurz + "Kanten").checked;
        bild.anschnitt  = document.getElementById(kurz + "Anschnitt").checked;
        slot.bild = bild;
    });
}

// Knopf-Auswahl neu füllen und die Felder aus dem gewählten Slot laden.
function bildAbschnittFuellen(format) {
    const kurz = format.toLowerCase();
    const wahl = document.getElementById(kurz + "KnopfWahl");
    if (!wahl) return;
    const kandidaten = bildSlotsImEntwurf(format);
    if (bildWahl[format] && kandidaten.indexOf(bildWahl[format]) < 0) bildWahl[format] = null;
    if (!bildWahl[format]) bildWahl[format] = kandidaten[0] || null;

    wahl.innerHTML = "";
    if (kandidaten.length) {
        kandidaten.forEach((slot, i) => {
            const option = document.createElement("option");
            option.value = String(i);
            option.textContent = slot.name;
            wahl.appendChild(option);
        });
        wahl.value = String(Math.max(0, kandidaten.indexOf(bildWahl[format])));
    } else {
        const option = document.createElement("option");
        option.value = "";
        option.textContent = "kein " + format + "-Knopf angelegt";
        wahl.appendChild(option);
        wahl.value = "";
    }
    wahl.disabled = kandidaten.length < 2;

    const slot = bildWahl[format];
    const bild = slot ? (slot.bild || standardBild(format)) : standardBild(format);
    const gesperrt = !slot;
    auswahlFuellen(document.getElementById(kurz + "Qualitaet"), QUALITAETEN, bild.qualitaet);
    document.getElementById(kurz + "Masz").value       = bild.masz || "ppi";
    document.getElementById(kurz + "Aufloesung").value = bild.aufloesung;
    document.getElementById(kurz + "BreitePx").value   = bild.breitePx || "";
    document.getElementById(kurz + "HoehePx").value    = bild.hoehePx || "";
    document.getElementById(kurz + "Farbraum").value   = bild.farbraum;
    if (format === "JPG") document.getElementById("jpgIcc").checked = bild.icc === true;
    else document.getElementById("pngTransparenz").checked = bild.transparenz === true;
    document.getElementById(kurz + "Kanten").checked    = bild.kanten === true;
    document.getElementById(kurz + "Anschnitt").checked = bild.anschnitt === true;

    document.getElementById(kurz + "Qualitaet").disabled = gesperrt;
    document.getElementById(kurz + "Farbraum").disabled  = gesperrt;
    if (format === "JPG") document.getElementById("jpgIcc").disabled = gesperrt;
    else document.getElementById("pngTransparenz").disabled = gesperrt;
    document.getElementById(kurz + "Kanten").disabled    = gesperrt;
    document.getElementById(kurz + "Anschnitt").disabled = gesperrt;
    maszSchalten();
}

function bildAbschnitteFuellen() {
    bildAbschnittFuellen("JPG");
    bildAbschnittFuellen("PNG");
}

function felderLesen() {
    // slotsAusFeldern schreibt auch die Bild-Garnituren zurück — jeder Knopf
    // trägt seine eigene, ein globales JPG/PNG gibt es nicht mehr.
    slotsAusFeldern();
    einstellungen.slots = slotsEntwurf;
    const ziel = document.querySelector('input[name="ziel"]:checked');
    einstellungen.zielArt        = ziel ? ziel.value : "dokument";
    einstellungen.zielOrdner     = document.getElementById("festerOrdner").value;
    einstellungen.unterordner    = document.getElementById("unterordner").value.replace(/^\s+|\s+$/g, "");
    einstellungen.muster         = document.getElementById("muster").value.replace(/^\s+|\s+$/g, "") || "{dok}";
    einstellungen.umfang         = document.getElementById("umfang").value;
    einstellungen.bereich        = document.getElementById("bereich").value.replace(/^\s+|\s+$/g, "");
    einstellungen.druckbogen     = document.getElementById("druckbogen").checked;
    einstellungen.ueberschreiben = document.getElementById("ueberschreiben").checked;
    einstellungen.danach         = document.getElementById("danach").value;
    einstellungen.verpackenPdf     = document.getElementById("verpackenPdf").checked;
    einstellungen.verpackenZip     = document.getElementById("verpackenZip").checked;
    einstellungen.verpackenVorgabe = document.getElementById("verpackenVorgabe").value || "";
}

// Wie breit der Wirt das Fenster tatsächlich aufmacht, lässt sich nicht
// vorgeben — aber nachlesen. Beim Schließen wird das Maß notiert; danach
// lässt sich die Aufteilung genau darauf abstimmen.
async function fenstermassNotieren() {
    try {
        const fenster = document.getElementById("fenster");
        const rumpf   = document.querySelector(".rumpf");
        const bloecke = [];
        document.querySelectorAll(".abschnitt").forEach(el => {
            const t = el.querySelector(".titel");
            const r = el.getBoundingClientRect();
            // scrollHeight > clientHeight heißt: der Block ist gestaucht und
            // sein Inhalt läuft heraus — genau das erzeugt Überlagerungen.
            const gestaucht = el.scrollHeight > el.clientHeight + 1;
            bloecke.push((t ? t.textContent : "?") + " " + Math.round(r.width) +
                         "x" + Math.round(r.height) +
                         " @" + Math.round(r.left) + "/" + Math.round(r.top) +
                         (gestaucht ? " GESTAUCHT (Inhalt " + el.scrollHeight + ")" : ""));
        });
        const zeilen = [
            "Fenster innen " + window.innerWidth + "x" + window.innerHeight,
            "Dialog " + Math.round(fenster.clientWidth) + "x" + Math.round(fenster.clientHeight),
            "Rumpf sichtbar " + (rumpf ? rumpf.clientHeight : "?") +
                ", Inhalt " + (rumpf ? rumpf.scrollHeight : "?") +
                ", Breite " + (rumpf ? rumpf.clientWidth : "?") +
                " / nötig " + (rumpf ? rumpf.scrollWidth : "?"),
            "Blöcke: " + bloecke.join(" | ")
        ];
        const ordner = await datenOrdner();
        const datei = await ordner.createFile("fenster-mass.txt", { overwrite: true });
        await datei.write(zeilen.join("\n"));
    } catch (e) { /* Maß ist Beiwerk */ }
}

let dialogOffen = false;
// Woran der Wirt ein geschlossenes Fenster erkennt, ist nicht verlässlich:
// wird das Formular abgeschickt, kommt aus uxpShowModal() nicht unbedingt der
// Wert des gedrückten Knopfes zurück. Deshalb merkt sich der Klick selbst,
// was gemeint war.
let dialogWunsch = "abbruch";

async function einstellungenZeigen(fokusSlot) {
    if (dialogOffen || arbeitet) return;
    dialogOffen = true;
    const fenster = document.getElementById("fenster");
    // Stand beim Öffnen merken: „Abbrechen“ nimmt auch ein Zurücksetzen
    // wieder zurück, denn das wirkt zunächst nur in den Feldern.
    const sicherung = JSON.parse(JSON.stringify(einstellungen));
    try {
        slotsEntwurf = einstellungen.slots.map(slot => ({
            name: slot.name, format: slot.format || "PDF", vorgabe: slot.vorgabe,
            unterordner: slot.unterordner, einzelseiten: slot.einzelseiten,
            bild: slot.bild ? JSON.parse(JSON.stringify(slot.bild)) : null
        }));
        felderFuellen();
        if (fokusSlot !== undefined && fokusSlot !== null) {
            const slotZiel = slotsEntwurf[fokusSlot];
            // Bei einem Bild-Knopf gleich dessen Garnitur in den Abschnitt holen.
            if (slotZiel && slotZiel.format !== "PDF") {
                bildWahl[slotZiel.format] = slotZiel;
                bildAbschnittFuellen(slotZiel.format);
            }
            const feld = document.getElementById(
                (slotZiel && slotZiel.format === "PDF")
                    ? "slotVorgabe" + fokusSlot
                    : "slotName" + fokusSlot);
            if (feld) setTimeout(() => { try { feld.focus(); } catch (e) {} }, 60);
        }
        dialogWunsch = "abbruch";
        // Solange der Dialog zu ist, misst der Rumpf 0 — die Roll-Hinweise
        // kurz nach dem Aufgehen nachziehen (uxpShowModal kehrt erst beim
        // Schließen zurück, deshalb vorab eingeplant).
        setTimeout(rollHinweiseAuffrischen, 150);
        setTimeout(rollHinweiseAuffrischen, 500);
        let ergebnis;
        if (typeof fenster.uxpShowModal === "function") {
            // Die Breite nimmt der Wirt sich selbst — angeforderte Werte
            // ignoriert er (880 → real 558). Die Höhe wird deshalb vorab
            // unsichtbar gemessen (bei ebendiesen 558 px, der schmalsten
            // beobachteten Zuteilung) und AUSDRÜCKLICH angefordert — auf
            // „das Fenster wächst mit dem Inhalt“ ist kein Verlass, die
            // Titelleiste ging sonst zulasten des Fußes. Der Rumpf-Deckel
            // (max-height 620) hält das Maß bildschirmsicher.
            const gemessen = dialogHoeheMessen(fenster, 558);
            const wunschHoehe = gemessen > 100 ? Math.min(740, gemessen + 56) : 700;
            // Falls ein früherer Fehler das Fenster halb offen hinterließ:
            // aufräumen, sonst wirft uxpShowModal einen InvalidStateError.
            try { fenster.close(); } catch (e) {}
            try { fenster.removeAttribute("open"); } catch (e) {}
            ergebnis = await fenster.uxpShowModal({
                title: "Export dwb — Export einstellen",
                resize: "both",
                size: { width: 880, height: wunschHoehe }
            });
        } else {
            ergebnis = await fenster.showModal();
        }
        await fenstermassNotieren();
        if (dialogWunsch === "sichern" || ergebnis === "sichern") {
            felderLesen();
            await einstellungenSichern();
            knoepfeBauen();
            umfangSchnellZeigen();
            status("Einstellungen gesichert.");
        } else {
            einstellungen = sicherung;
            umfangSchnellZeigen();
            status("bereit");
        }
    } catch (e) {
        einstellungen = sicherung;
        status("Fenster ging nicht auf: " + e, "fehler");
    } finally {
        dialogOffen = false;
    }
}

// ============================================================================
//  Oberfläche
// ============================================================================

// Beschreibt die Bild-Garnitur eines Knopfes in einem Satz — für den Tooltip
// im Bedienfeld und die Zusammenfassung im Einstellungsfenster.
function bildBeschreibung(slot) {
    const e = slot.bild || standardBild(slot.format);
    const teile = [];
    for (const [text, schluessel] of QUALITAETEN)
        if (schluessel === e.qualitaet) teile.push(text);
    if (e.masz === "pixel") {
        const px = [];
        if (e.breitePx > 0) px.push(e.breitePx + " px breit");
        if (e.hoehePx > 0)  px.push(e.hoehePx + " px hoch");
        teile.push(px.length ? px.join(", ") : "Pixelmaß leer");
    } else {
        teile.push(Math.round(zahl(e.aufloesung, 0)) + " ppi");
    }
    teile.push(e.farbraum === "GRAY" ? "Graustufen" : e.farbraum);
    if (slot.format === "PNG" && e.transparenz) teile.push("transparent");
    if (slot.format === "JPG" && e.icc) teile.push("mit Profil");
    if (e.anschnitt) teile.push("mit Anschnitt");
    return teile.join(" · ");
}

// Die Knöpfe entstehen aus der Liste — beliebig viele, auch keiner. PDF-Knöpfe
// kommen in die erste Reihe, Bild-Knöpfe in die zweite vor das Zahnrad.
function knoepfeBauen() {
    const pdfLeiste  = document.getElementById("pdfLeiste");
    const bildLeiste = document.getElementById("bildLeiste");
    const zahnrad    = document.getElementById("zahnrad");
    // Bild-Knöpfe reihen sich vor „Verpacken“ und dem Zahnrad ein.
    const anker      = document.getElementById("verpacken") || zahnrad;
    if (!pdfLeiste || !bildLeiste || !zahnrad) return;
    pdfLeiste.innerHTML = "";
    bildLeiste.querySelectorAll(".knopf.dynamisch").forEach(alt => {
        alt.parentNode.removeChild(alt);
    });

    einstellungen.slots.forEach((slot, i) => {
        const istPdf = (slot.format || "PDF") === "PDF";
        const knopf = document.createElement("div");
        knopf.setAttribute("role", "button");
        knopf.setAttribute("tabindex", "0");
        knopf.className = "knopf dynamisch " + (istPdf ? "pdf" : "bild");
        knopf.id = "slotKnopf" + i;
        knopf.textContent = slot.name;
        knopf.setAttribute("title", istPdf
            ? (slot.name + " → PDF-Vorgabe „" + (slot.vorgabe || "–") + "“" +
               (slot.unterordner ? ", Unterordner " + slot.unterordner : "") +
               (slot.einzelseiten ? ", eine Datei je Seite" : "") +
               "  ·  Alt-Klick oder Rechtsklick: bearbeiten")
            : (slot.name + " → " + slot.format + " · " + bildBeschreibung(slot) +
               (slot.unterordner ? " · Unterordner " + slot.unterordner : "") +
               "  ·  Alt-Klick oder Rechtsklick: bearbeiten"));
        knopf.addEventListener("click", (e) => {
            if (e && e.altKey) einstellungenZeigen(i);
            else exportieren(i, knopf);
        });
        knopf.addEventListener("contextmenu", (e) => {
            if (e && e.preventDefault) e.preventDefault();
            einstellungenZeigen(i);
        });
        if (istPdf) pdfLeiste.appendChild(knopf);
        else bildLeiste.insertBefore(knopf, anker);
    });
    if (!einstellungen.slots.length) {
        const hinweis = document.createElement("div");
        hinweis.className = "status";
        hinweis.style.marginTop = "0px";
        hinweis.textContent = "keine Knöpfe — „…“ öffnet die Einstellungen";
        pdfLeiste.appendChild(hinweis);
    }
    rollHinweiseAuffrischen();
    knoepfeKuerzen(true);
}

// Die Schnellwahl unter den Knöpfen spiegelt den Umfang aus den Einstellungen;
// das Bereichsfeld daneben erscheint nur bei „Seitenbereich“.
function umfangSchnellZeigen() {
    const wahl = document.getElementById("umfangSchnell");
    const feld = document.getElementById("bereichSchnell");
    if (!wahl || !feld) return;
    wahl.value = einstellungen.umfang;
    feld.value = einstellungen.bereich || "";
    feld.style.display = (einstellungen.umfang === "bereich") ? "" : "none";
}

// InDesigns Oberfläche kennt vier Helligkeiten (0 = dunkelgrau … 1 = hell).
// Die mittlere Stufe 0,5 ist immer noch ein kräftiges Grau — dort gehört
// weißer Text hin. Als hell zählt deshalb erst alles über 0,6.
function helligkeitUebernehmen() {
    let hell = false;
    try {
        const wert = indesign().app.generalPreferences.uiBrightnessPreference;
        hell = (typeof wert === "number") ? wert > 0.6 : false;
    } catch (e) { hell = false; }
    document.documentElement.classList.toggle("hell", hell);
    // Der Wächter läuft ohnehin alle paar Sekunden — er hält nebenbei die
    // Wandhöhe und die Roll-Hinweise frisch (UXP meldet manche
    // Größenwechsel nicht als resize).
    wandMasseSetzen();
}

// UXP meldet keinen Wechsel der Oberflächenhelligkeit — deshalb wird sie
// alle paar Sekunden nachgelesen (ein reiner Property-Read, das Umschalten
// der Klasse ist ohnehin idempotent).
let helligkeitsWaechter = null;

let verdrahtet = false;

function verdrahten() {
    if (verdrahtet) return;
    const zahnrad = document.getElementById("zahnrad");
    if (!zahnrad) return;
    verdrahtet = true;

    document.getElementById("zahnrad").addEventListener("click", () => einstellungenZeigen(null));
    document.getElementById("verpacken").addEventListener("click", () => verpacken());

    // Rollbereiche anbinden: das Bedienfeld selbst und der Rumpf des
    // Einstellfensters. Beim Größerziehen werden Wandhöhe und Hinweise
    // nachgezogen.
    rollHinweiseAnbinden(document.getElementById("wandInhalt"));
    rollHinweiseAnbinden(document.querySelector(".rumpf"));
    window.addEventListener("resize", wandMasseSetzen);
    wandMasseSetzen();

    // Kurz nach dem Aufbau festhalten, was der Wirt wirklich zeichnet und
    // misst — mess-knoepfe.txt im Datenordner. Verzögert, damit Schrift und
    // Umbruch stehen.
    messenWennBereit();

    // Ein Klick auf die Statuszeile öffnet nach einem gelungenen Export den
    // Zielordner — die Unterstreichung zeigt an, wann das geht.
    document.getElementById("status").addEventListener("click", async () => {
        if (!letzterZielPfad || arbeitet) return;
        try { await uxp.shell.openPath(letzterZielPfad); } catch (e) {}
    });

    // Umfang-Schnellwahl im Bedienfeld: schreibt direkt in die Einstellungen
    // und sichert sie — der Einstellungsdialog muss dafür nicht mehr auf.
    document.getElementById("umfangSchnell").addEventListener("change", async () => {
        einstellungen.umfang = document.getElementById("umfangSchnell").value;
        umfangSchnellZeigen();
        await einstellungenSichern();
    });
    const bereichSchnell = document.getElementById("bereichSchnell");
    // „input“ hält den Wert aktuell (Export ohne vorheriges Verlassen des
    // Feldes), „change“ sichert ihn auf die Platte.
    bereichSchnell.addEventListener("input", () => {
        einstellungen.bereich = bereichSchnell.value.replace(/^\s+|\s+$/g, "");
    });
    bereichSchnell.addEventListener("change", async () => {
        einstellungen.bereich = bereichSchnell.value.replace(/^\s+|\s+$/g, "");
        await einstellungenSichern();
    });

    document.getElementById("abbrechen").addEventListener("click", () => {
        dialogWunsch = "abbruch";
        try { document.getElementById("fenster").close("abbruch"); } catch (e) {}
    });
    document.getElementById("sichern").addEventListener("click", () => {
        dialogWunsch = "sichern";
        try { document.getElementById("fenster").close("sichern"); } catch (e) {}
    });
    // Zweite Sicherung für die Tastatur: Eingabetaste heißt sichern,
    // Esc heißt abbrechen — unabhängig davon, ob der Wirt das Formular
    // überhaupt abschickt.
    const fensterElement = document.getElementById("fenster");
    fensterElement.addEventListener("keydown", (e) => {
        const taste = e && (e.key || e.code);
        const ziel = e && e.target;
        if (taste === "Enter" || taste === "NumpadEnter")
            dialogWunsch = (ziel && ziel.id === "abbrechen") ? "abbruch" : "sichern";
        if (taste === "Escape" || taste === "Esc") dialogWunsch = "abbruch";
    });

    ["jpgMasz", "pngMasz"].forEach(id => {
        const feld = document.getElementById(id);
        if (feld) feld.addEventListener("change", maszSchalten);
    });
    // Das Bereichsfeld folgt dem Umfang, die Beispielzeile dem Muster-Feld.
    document.getElementById("umfang").addEventListener("change", bereichSchalten);
    document.getElementById("muster").addEventListener("input", musterVorschauZeigen);

    // Die Knopf-Auswahl über den Bild-Abschnitten: erst den bisherigen Knopf
    // zurückschreiben, dann den neuen laden.
    [["JPG", "jpg"], ["PNG", "png"]].forEach(([format, kurz]) => {
        const wahl = document.getElementById(kurz + "KnopfWahl");
        if (!wahl) return;
        wahl.addEventListener("change", () => {
            bildFelderZurueckschreiben();
            const kandidaten = bildSlotsImEntwurf(format);
            bildWahl[format] = kandidaten[parseInt(wahl.value, 10)] || kandidaten[0] || null;
            bildAbschnittFuellen(format);
        });
    });

    // Alles auf Werkseinstellung. Wirkt nur in den Feldern — „Sichern“
    // übernimmt es, „Abbrechen“ verwirft es wieder.
    document.getElementById("zuruecksetzen").addEventListener("click", async () => {
        einstellungen = standardEinstellungen();
        await vorgabenErgaenzen();
        slotsEntwurf = einstellungen.slots.map(slot => ({
            name: slot.name, format: slot.format || "PDF", vorgabe: slot.vorgabe,
            unterordner: slot.unterordner, einzelseiten: slot.einzelseiten,
            bild: slot.bild ? JSON.parse(JSON.stringify(slot.bild)) : null
        }));
        felderFuellen();
        document.getElementById("dialogHinweis").textContent =
            "Werkseinstellungen eingesetzt — „Sichern“ übernimmt sie, „Abbrechen“ verwirft sie.";
    });

    document.getElementById("slotHinzu").addEventListener("click", () => {
        slotsAusFeldern();
        slotsEntwurf.push(neuerSlot());
        slotZeilenBauen();
        bildAbschnitteFuellen();
        musterVorschauZeigen();
        // Die neue Zeile kann unter dem Falz liegen — den Rumpf so weit
        // rollen, dass sie samt „+ Knopf“ zu sehen ist.
        const rumpf = document.querySelector(".rumpf");
        const hinzu = document.getElementById("slotHinzu");
        if (rumpf && hinzu) {
            const delta = hinzu.getBoundingClientRect().bottom -
                          rumpf.getBoundingClientRect().bottom + 8;
            if (delta > 0) rumpf.scrollTop += delta;
        }
        rollHinweiseAuffrischen();
    });
    document.getElementById("ordnerWaehlen").addEventListener("click", async () => {
        try {
            const ordner = await lfs.getFolder();
            if (ordner) {
                document.getElementById("festerOrdner").value = ordner.nativePath;
                const feld = document.querySelector('input[name="ziel"][value="fest"]');
                if (feld) feld.checked = true;
            }
        } catch (e) { /* abgebrochen */ }
    });
}

async function starten() {
    helligkeitUebernehmen();
    if (!helligkeitsWaechter) helligkeitsWaechter = setInterval(helligkeitUebernehmen, 3000);
    verdrahten();
    await einstellungenLaden();
    knoepfeBauen();
    umfangSchnellZeigen();
    status("bereit");
}

try {
    const { entrypoints } = require("uxp");
    entrypoints.setup({
        panels: {
            dwbExport: {
                show() { starten(); messenWennBereit(); },
                menuItems: [
                    { id: "einstellungen", label: "Export einstellen…" },
                    { id: "verpacken",     label: "Sichern und verpacken" },
                    { id: "selbsttest",    label: "Selbsttest" }
                ],
                invokeMenu(id) {
                    if (id === "einstellungen") einstellungenZeigen(null);
                    if (id === "verpacken") verpacken();
                    if (id === "selbsttest") selbsttest();
                }
            }
        }
    });
} catch (e) {
    status("Bedienfeld konnte sich nicht anmelden: " + e, "fehler");
}

document.addEventListener("DOMContentLoaded", () => { starten(); });
starten();

// ============================================================================
//  Selbsttest
// ----------------------------------------------------------------------------
// Legt ein Testdokument an, exportiert einmal in alle drei Formate und
// schreibt ein Protokoll in den Datenordner des Plugins. Aufruf über das
// Bedienfeldmenü — oder beim Start, wenn im Datenordner eine Datei
// „selbsttest.txt“ liegt (so lässt sich das Plugin ohne Klicken prüfen).
// ============================================================================

async function selbsttest() {
    // Während eines laufenden Exports würde der Selbsttest über den
    // Anhalten-Zweig von exportieren() den Export des Nutzers abbrechen —
    // deshalb erst gar nicht anfangen.
    if (arbeitet) { status("Es läuft gerade ein Export — Selbsttest bitte danach.", "fehler"); return; }
    const zeilen = [];
    const merke = (t) => { zeilen.push(String(t)); status("Selbsttest: " + t); };
    let doc = null;
    try {
        const idsn = indesign(), app = idsn.app;
        merke("InDesign " + app.version);
        await einstellungenLaden();
        const ordner = await datenOrdner();
        merke("Datenordner: " + ordner.nativePath);

        doc = app.documents.add();
        doc.documentPreferences.pagesPerDocument = 3;
        const r = doc.pages.item(0).rectangles.add();
        r.geometricBounds = [20, 20, 60, 80];
        merke("Testdokument mit " + doc.pages.length + " Seiten");

        const pruefOrdner = await unterordnerAnlegen(ordner, "selbsttest-ausgabe");
        merke("Ausgabeordner: " + pruefOrdner.nativePath);

        // Bequemer Zugriff auf die Knöpfe je Format — immer frisch geholt,
        // denn nach einem Neuladen wechseln die Verweise.
        const bildSlot = (f) => {
            const i = slotIndexFuerFormat(f);
            return (i >= 0) ? einstellungen.slots[i] : null;
        };

        const gemerkt = JSON.parse(JSON.stringify(einstellungen));
        einstellungen.zielArt = "fest";
        einstellungen.zielOrdner = pruefOrdner.nativePath;
        einstellungen.unterordner = "";
        einstellungen.muster = "{dok}_{seite}";
        einstellungen.umfang = "bereich";
        einstellungen.bereich = "1-2";
        einstellungen.danach = "nichts";
        if (bildSlot("JPG")) bildSlot("JPG").bild.aufloesung = 72;
        if (bildSlot("PNG")) bildSlot("PNG").bild.aufloesung = 72;

        merke("Knöpfe (" + einstellungen.slots.length + "): " +
              einstellungen.slots.map(s2 => s2.name + " [" + s2.format + "]" +
                  (s2.format === "PDF" ? " → " + s2.vorgabe : "")).join(", "));

        if (slotIndexFuerFormat("PDF") >= 0) await exportieren(slotIndexFuerFormat("PDF"));
        merke("PDF: " + document.getElementById("status").textContent);
        if (slotIndexFuerFormat("JPG") >= 0) await exportieren(slotIndexFuerFormat("JPG"));
        merke("JPG: " + document.getElementById("status").textContent);
        if (slotIndexFuerFormat("PNG") >= 0) await exportieren(slotIndexFuerFormat("PNG"));
        merke("PNG: " + document.getElementById("status").textContent);

        einstellungen.umfang = "auswahl";
        app.select(r);
        if (slotIndexFuerFormat("PNG") >= 0) await exportieren(slotIndexFuerFormat("PNG"));
        merke("Auswahl-PNG: " + document.getElementById("status").textContent);
        if (slotIndexFuerFormat("PDF") >= 0) await exportieren(slotIndexFuerFormat("PDF"));
        merke("Auswahl-PDF: " + document.getElementById("status").textContent);

        // Verpacken: das Testdokument ist nie gesichert worden — hier muss der
        // freundliche Hinweis kommen, nicht ein Paketordner.
        await verpacken();
        merke("Verpacken (ungesichert): " + document.getElementById("status").textContent);

        merke("Bereich '9-99' ergibt " + seitenAusBereich(doc, "9-99").length + " Seiten");

        // Werden Einstellungen wirklich gesichert und wiedergefunden?
        if (bildSlot("JPG")) bildSlot("JPG").bild.aufloesung = 72;
        await einstellungenSichern();
        const zwischenspeicher = JSON.parse(JSON.stringify(einstellungen));
        if (bildSlot("JPG")) bildSlot("JPG").bild.aufloesung = 999;
        await einstellungenLaden();
        merke("Sichern/Laden: 72 gesetzt → nach dem Laden " +
              (bildSlot("JPG") ? bildSlot("JPG").bild.aufloesung : "kein JPG-Knopf"));

        // Und wirkt die Auflösung auch im Export? 72 gegen 300 vergleichen.
        try {
            einstellungen.umfang = "bereich"; einstellungen.bereich = "1";
            einstellungen.muster = "aufloesung{nr}";
            if (bildSlot("JPG")) {
                bildSlot("JPG").bild.aufloesung = 72;
                await exportieren(slotIndexFuerFormat("JPG"));
                bildSlot("JPG").bild.aufloesung = 300;
                await exportieren(slotIndexFuerFormat("JPG"));
            }
            const dateienJpg = await pruefOrdner.getEntries();
            const groessen = [];
            for (const e of dateienJpg) {
                if (!/^aufloesung/.test(e.name)) continue;
                const daten = await e.read({ format: require("uxp").storage.formats.binary });
                groessen.push(e.name + " " + (daten.byteLength || daten.length) + " Byte");
            }
            groessen.sort();
            merke("Auflösung wirkt? " + groessen.join(" | "));
        } catch (e) { merke("Auflösungsprobe: " + e); }
        einstellungen = zwischenspeicher;
        await einstellungenSichern();
        merke("pngSuffix nach dem Export: '" + app.pngExportPreferences.pngSuffix + "'");

        const dateien = await pruefOrdner.getEntries();
        merke("Dateien: " + dateien.map(e => e.name).sort().join(", "));

        // Sitzt die Beschriftung in den Knöpfen? (nur messbar, wenn das
        // Bedienfeld gerade sichtbar ist)
        const gemessen = [];
        const knopfIds = einstellungen.slots.map((s2, i) => "slotKnopf" + i).concat(["zahnrad"]);
        knopfIds.forEach(id => {
            const knopf = document.getElementById(id);
            if (!knopf) return;
            const rechteck = knopf.getBoundingClientRect();
            gemessen.push(id + " " + Math.round(rechteck.width) + "x" + Math.round(rechteck.height) +
                          (knopf.scrollWidth > knopf.clientWidth + 1 ? " ABGESCHNITTEN" : ""));
        });
        merke("Knöpfe: " + (gemessen.length ? gemessen.join(" | ") : "nicht messbar"));
        merke("Bedienfeld: body " + document.body.clientWidth + "x" + document.body.clientHeight +
              " · innen " + window.innerWidth + "x" + window.innerHeight +
              " · Wand " + (document.getElementById("wandInhalt") ?
                  document.getElementById("wandInhalt").clientHeight + " sichtbar / " +
                  document.getElementById("wandInhalt").scrollHeight + " Inhalt" : "fehlt"));

        // Farben: Text und Fläche müssen sich unterscheiden, sonst steht grau
        // auf grau. Die Werte lassen sich auch bei geschlossenem Dialog lesen.
        let helligkeit = "?";
        try { helligkeit = indesign().app.generalPreferences.uiBrightnessPreference; } catch (e) {}
        merke("Oberflächenhelligkeit " + helligkeit + ", Klasse „" +
              document.documentElement.className + "“");
        const farbe = (wahl) => {
            const el = document.querySelector(wahl);
            if (!el) return wahl + ": fehlt";
            const stil = getComputedStyle(el);
            return wahl + " Text " + stil.color + " auf " + stil.backgroundColor;
        };
        ["#fenster", ".abschnitt", ".titel", ".hinweis", "#muster", "#umfang", ".knopf",
         ".zeile.haken label", ".zeile.haken input", ".marke"]
            .forEach(wahl => merke(farbe(wahl)));

        // Pixelmaß: kommt wirklich die gewünschte Breite heraus?
        try {
            const pngSlot = bildSlot("PNG");
            if (pngSlot) {
                einstellungen.umfang = "bereich"; einstellungen.bereich = "1";
                einstellungen.muster = "pixelprobe";
                pngSlot.bild.masz = "pixel";
                pngSlot.bild.breitePx = 800;
                pngSlot.bild.hoehePx = 0;
                pngSlot.bild.anschnitt = false;
                await exportieren(slotIndexFuerFormat("PNG"));
                const formate = require("uxp").storage.formats;
                const dateienPng = await pruefOrdner.getEntries();
                for (const e of dateienPng) {
                    if (!/^pixelprobe.*\.png$/.test(e.name)) continue;
                    const puffer = await e.read({ format: formate.binary });
                    const sicht = new DataView(puffer.buffer ? puffer.buffer : puffer);
                    merke("Pixelmaß: 800 px gewünscht → " + sicht.getUint32(16) +
                          " x " + sicht.getUint32(20) + " px  (" + e.name + ")");
                    break;
                }
                pngSlot.bild.masz = "ppi";
                pngSlot.bild.breitePx = 0;
            }
        } catch (e) { merke("Pixelmaß-Probe: FEHLER " + e); }

        // Zurücksetzen prüfen
        try {
            if (bildSlot("JPG")) bildSlot("JPG").bild.aufloesung = 999;
            einstellungen.slots.push({ name: "Probe", format: "PDF", vorgabe: "",
                                       unterordner: "", einzelseiten: true, bild: null });
            felderFuellen();
            const vorher = einstellungen.slots.length + " Knöpfe, " +
                  (bildSlot("JPG") ? bildSlot("JPG").bild.aufloesung : "-") + " ppi";
            document.getElementById("zuruecksetzen").dispatchEvent(new Event("click"));
            await new Promise(r => setTimeout(r, 300));
            merke("Zurücksetzen: vorher " + vorher + " → nachher " +
                  einstellungen.slots.length + " Knöpfe, " +
                  (bildSlot("JPG") ? bildSlot("JPG").bild.aufloesung : "-") + " ppi, " +
                  "Entwurfszeilen " + slotsEntwurf.length +
                  ", erster Knopf „" + (einstellungen.slots[0] ? einstellungen.slots[0].name : "-") + "“");
        } catch (e) { merke("Zurücksetzen: FEHLER " + e); }

        // Layout prüfen, ohne den Dialog modal zu öffnen: das Fenster wird
        // unsichtbar im Bedienfeld ausgelegt und vermessen. Ein modal
        // geöffneter Dialog ließe sich aus dem Skript nicht wieder schließen.
        try {
            const fenster = document.getElementById("fenster");
            felderFuellen();
            // show() öffnet das Fenster NICHT modal — es blockiert nichts und
            // lässt sich aus dem Skript wieder schließen (im Gegensatz zu
            // uxpShowModal()).
            for (const breite of [850, 558]) {
                fenster.style.position   = "absolute";
                fenster.style.visibility = "hidden";
                fenster.style.left       = "-4000px";
                fenster.style.top        = "0px";
                fenster.style.width      = breite + "px";
                try { fenster.show(); } catch (e) { merke("show(): " + e); }
                await new Promise(r => setTimeout(r, 250));
                // Überlagerungen zählen: zwei Blöcke, die sich waagerecht UND
                // senkrecht überschneiden, liegen übereinander.
                const kaesten = [], bloecke = [];
                document.querySelectorAll(".abschnitt").forEach(el => {
                    const t = el.querySelector(".titel");
                    const r = el.getBoundingClientRect();
                    const gestaucht = el.scrollHeight > el.clientHeight + 1;
                    kaesten.push(r);
                    bloecke.push((t ? t.textContent : "?") + " " +
                                 Math.round(r.width) + "x" + Math.round(r.height) +
                                 " @" + Math.round(r.left) + "/" + Math.round(r.top) +
                                 (gestaucht ? " GESTAUCHT" : ""));
                });
                let ueberlappung = 0;
                for (let a = 0; a < kaesten.length; a++) {
                    for (let b = a + 1; b < kaesten.length; b++) {
                        const x = Math.min(kaesten[a].right, kaesten[b].right) -
                                  Math.max(kaesten[a].left, kaesten[b].left);
                        const y = Math.min(kaesten[a].bottom, kaesten[b].bottom) -
                                  Math.max(kaesten[a].top, kaesten[b].top);
                        if (x > 1 && y > 1) ueberlappung++;
                    }
                }
                const rumpf = document.querySelector(".rumpf");
                merke("Bei " + breite + " px: Rumpf " + (rumpf ? rumpf.clientHeight : "?") +
                      " sichtbar / " + (rumpf ? rumpf.scrollHeight : "?") + " Inhalt" +
                      (rumpf && rumpf.scrollHeight > rumpf.clientHeight + 2 ? " → scrollt" : " → passt") +
                      ", Überlagerungen: " + ueberlappung);
                bloecke.forEach(b => merke("   " + b));
                const kSichern = document.getElementById("sichern").getBoundingClientRect();
                const kAbbruch = document.getElementById("abbrechen").getBoundingClientRect();
                merke("   Fußleiste: Abbrechen @" + Math.round(kAbbruch.left) +
                      ", Sichern @" + Math.round(kSichern.left) +
                      (kSichern.left > kAbbruch.left ? " → Sichern steht rechts" : " → REIHENFOLGE VERTAUSCHT"));
                try { fenster.close("probe"); } catch (e) { merke("close(): " + e); }
                await new Promise(r => setTimeout(r, 120));
            }
            fenster.style.display    = "";
            fenster.style.position   = "";
            fenster.style.visibility = "";
            fenster.style.left       = "";
            fenster.style.top        = "";
            fenster.style.width      = "";
        } catch (e) {
            merke("Layoutprobe: " + e);
        }
        einstellungen = gemerkt;
        merke("fertig");
    } catch (fehler) {
        zeilen.push("ABBRUCH: " + fehler + (fehler && fehler.stack ? " | " + fehler.stack : ""));
    }
    try {
        if (doc) doc.close(indesign().SaveOptions.NO);
    } catch (e) { zeilen.push("Schließen: " + e); }
    try {
        const ordner = await datenOrdner();
        const datei = await ordner.createFile(PROTOKOLLDATEI, { overwrite: true });
        await datei.write(zeilen.join("\n"));
    } catch (e) { /* dann eben nicht */ }
    status("Selbsttest fertig — Protokoll im Datenordner.");
}

// Beim Start prüfen, ob ein Selbsttest gewünscht ist.
setTimeout(async () => {
    try {
        const ordner = await datenOrdner();
        const marke = await eintragOderNull(ordner, SELBSTTEST_MARKE);
        if (marke) {
            await marke.delete();
            await selbsttest();
        }
    } catch (e) { /* kein Selbsttest */ }
}, 12000);
