// ============================================================================
// Prüfung dwb — UXP-Bedienfeld für Adobe InDesign                 Version 1.0
// ----------------------------------------------------------------------------
// Die Reinzeichnungs-Ampel: EIN Klick prüft das Dokument auf die Fehler, die
// sonst erst im fertigen PDF auffallen —
//
//   • Übersatztext
//   • fehlende und geänderte Verknüpfungen
//   • RGB-Bilder
//   • effektive Bildauflösung unter der Schwelle (unter 150 ppi: ernst)
//   • Haarlinien (Konturen unter der Schwelle)
//   • Objekte, die an der Seitenkante enden, aber nicht in den Anschnitt reichen
//
// Jeder Fund ist eine Zeile; ein Klick darauf wählt das Objekt aus und passt
// es ins Fenster ein. Die beiden Schwellen (Auflösung, Linienstärke) stehen
// direkt im Bedienfeld und werden gemerkt.
//
// Was NICHT geprüft wird: Tabellen-Übersatz in Zellen, Objektformate,
// Überdrucken. Ist der Anschnitt des Dokuments 0, entfällt die
// Anschnittprüfung (die Statuszeile sagt es).
//
// Einstellungen liegen im Datenordner des Plugins:
//   …/UXP/PluginsStorage/IDSN/<Version>/External/de.dwb.pruefung/PluginData/
// © 2026 dwbkd · www.dwbkd.de
// ============================================================================

const uxp = require("uxp");
const lfs = uxp.storage.localFileSystem;

const EINSTELLUNGSDATEI = "einstellungen.json";
const PROTOKOLLDATEI    = "selbsttest-protokoll.txt";
const SELBSTTEST_MARKE  = "selbsttest.txt";
// „Auswahl in Fenster einpassen“ gibt es im Skriptmodell nicht — nur als
// Menübefehl mit dieser festen, sprachunabhängigen ID (siehe Ansicht dwb).
const MENUE_AUSWAHL = 118790;

let einstellungen = { aufloesung: 250, linie: 0.25 };
let statusFeld = null;
let prueft = false;
let funde = [];               // { text, stufe: "ernst"|"warn", objektId, hinweis }

// ============================================================================
//  Kleinkram
// ============================================================================

function indesign() { return require("indesign"); }

function status(text, art) {
    if (!statusFeld) statusFeld = document.getElementById("status");
    if (!statusFeld) return;
    statusFeld.textContent = "";
    if (art === "erfolg") {
        const punkt = document.createElement("span");
        punkt.className = "punkt";
        punkt.textContent = "● ";
        statusFeld.appendChild(punkt);
    }
    statusFeld.appendChild(document.createTextNode(String(text)));
    statusFeld.setAttribute("title", String(text));
    statusFeld.classList.toggle("fehler", art === "fehler");
}

function kurzeAtempause() {
    return new Promise(fertig => setTimeout(fertig, 0));
}

function zahl(wert, ersatz) {
    const n = parseFloat(String(wert).replace(",", "."));
    return isNaN(n) ? ersatz : n;
}

function alsText(n) {
    return String(Math.round(n * 100) / 100).replace(".", ",");
}

// ============================================================================
//  Roll-Hinweise (siehe Ansicht/Export — gleiche Mechanik)
// ============================================================================

const rollBereiche = [];

function rollHinweiseAnbinden(bereich) {
    if (!bereich || bereich.dataset.rollt === "ja") return;
    bereich.dataset.rollt = "ja";
    const rahmen = bereich.parentElement;
    const oben  = rahmen ? rahmen.querySelector(".rollhinweis.oben")  : null;
    const unten = rahmen ? rahmen.querySelector(".rollhinweis.unten") : null;
    const zeigen = () => {
        const kannOben  = bereich.clientHeight > 0 && bereich.scrollTop > 2;
        const kannUnten = bereich.clientHeight > 0 &&
            bereich.scrollTop + bereich.clientHeight < bereich.scrollHeight - 2;
        if (oben)  oben.classList.toggle("sichtbar", kannOben);
        if (unten) unten.classList.toggle("sichtbar", kannUnten);
    };
    const rollen = (richtung) => {
        bereich.scrollTop += richtung * Math.max(40, Math.round(bereich.clientHeight * 0.8));
        zeigen();
    };
    bereich.addEventListener("scroll", zeigen);
    if (oben)  oben.addEventListener("click",  () => rollen(-1));
    if (unten) unten.addEventListener("click", () => rollen(1));
    rollBereiche.push(zeigen);
    zeigen();
}

// Beim Start festhalten, wie hoch der Inhalt wirklich ist — nur daraus lässt
// sich maximumSize im Manifest richtig setzen (Baulehre 20/23). Höhen gibt
// der Wirt heraus, Breiten nicht.
async function hoeheMessen(notiz) {
    try {
        const wand = document.getElementById("wandInhalt");
        if (!wand) return;
        const zeilen = [
            "Gemessen " + new Date().toLocaleString(),
            "Zustand: " + (notiz || "-"),
            "HÖHE nötig " + wand.scrollHeight + " · vorhanden " + wand.clientHeight,
            "BREITE " + wand.clientWidth
        ];
        const ordner = await require("uxp").storage.localFileSystem.getDataFolder();
        const datei  = await ordner.createFile("mess-hoehe.txt", { overwrite: true });
        await datei.write(zeilen.join("\n"));
    } catch (e) { /* Messung ist Beiwerk */ }
}

// Der Wirt gibt erst Maße heraus, wenn das Bedienfeld tatsächlich SICHTBAR ist.
// Bei "loadEvent": "startup" wird das Dokument lange vorher aufgebaut — eine
// Messung kurz nach dem Laden lieferte deshalb durchweg 0 (auch scrollHeight).
let messLauf = 0;
function messenWennBereit() {
    const lauf = ++messLauf;
    let versuche = 0;
    const takt = setInterval(() => {
        if (lauf !== messLauf) { clearInterval(takt); return; }
        versuche++;
        const wand = document.getElementById("wandInhalt");
        const da = wand && wand.clientHeight > 0;
        if (da || versuche >= 40) {
            clearInterval(takt);
            hoeheMessen(da ? "sichtbar nach " + (versuche * 500) + " ms"
                           : "NIE Maße bekommen (40 Versuche)");
        }
    }, 500);
}

// Die Bedienfeldknöpfe sind <div role="button"> (Baulehre 30): nur so kommen
// Füllung, Ecken und Höhe aus dem CSS an — ein <button> malt der Wirt selbst.
// Ein DIV kennt aber kein disabled. Deshalb: gesperrt = Attribut „disabled“
// (dafür greift das CSS), ein Wächter in der Fangphase lässt Klicks auf
// Gesperrte gar nicht erst ankommen, und Enter/Leertaste lösen aus wie beim
// echten Knopf (dispatchEvent — click() tut in UXP nichts, Baulehre 2).
function knopfGesperrt(element, aus) {
    if (!element) return;
    // Gesperrte DIV-Knöpfe auch aus der Tab-Reihe nehmen — ein <button disabled>
    // wäre von selbst unerreichbar, ein DIV mit tabindex 0 nicht.
    if (aus) { element.setAttribute("disabled", ""); element.setAttribute("tabindex", "-1"); }
    else     { element.removeAttribute("disabled");  element.setAttribute("tabindex", "0"); }
}
function knopfVon(ziel) {
    let el = ziel;
    while (el && el !== document) {
        if (el.classList && el.classList.contains("knopf")) return el;
        el = el.parentNode;
    }
    return null;
}
function knopfWaechterAnbinden(wurzel) {
    if (!wurzel || wurzel.getAttribute("data-waechter") === "ja") return;
    wurzel.setAttribute("data-waechter", "ja");
    wurzel.addEventListener("click", (e) => {
        const knopf = knopfVon(e && e.target);
        if (knopf && knopf.hasAttribute("disabled")) {
            if (e.stopPropagation) e.stopPropagation();
            if (e.preventDefault) e.preventDefault();
        }
    }, true);
    // Fangphase: läuft VOR dem keydown des Dialogs, und der Stopp sorgt dafür,
    // dass Enter auf einem DIV-Knopf nur diesen drückt — nicht zugleich als
    // „Eingabetaste = sichern“ des Fensters zählt.
    wurzel.addEventListener("keydown", (e) => {
        const taste = e && (e.key || e.code);
        if (taste !== "Enter" && taste !== "NumpadEnter" && taste !== " " && taste !== "Space") return;
        const knopf = knopfVon(e.target);
        if (!knopf) return;
        if (e.preventDefault) e.preventDefault();
        if (e.stopPropagation) e.stopPropagation();
        // Gesperrt: Taste schlucken — sonst zählte sie als Eingabetaste des
        // Fensters („sichern“), obwohl der Knopf sichtbar nichts tut.
        if (knopf.hasAttribute("disabled")) return;
        knopf.dispatchEvent(new Event("click"));
    }, true);
    // Fokus-Ring in Dialogen nur nach Tab, nie nach Mausklick (der sah aus wie
    // „aktiv“). Per Klasse, weil nur :focus im Wirt belegt ist; beim
    // unsichtbaren Absende-Knopf auf die Hülle gespiegelt. Feuert focusin im
    // Wirt nicht, passiert schlicht nichts.
    if (String(wurzel.tagName).toUpperCase() !== "DIALOG") return;
    const traeger = (ziel) => {
        const k = knopfVon(ziel);
        if (k) return k;
        const p = ziel && ziel.parentNode;
        return (p && p.classList && p.classList.contains("huelle")) ? p : null;
    };
    wurzel.addEventListener("keydown", (e) => {
        if ((e && (e.key || e.code)) === "Tab") wurzel.setAttribute("data-tastatur", "ja");
    }, true);
    wurzel.addEventListener("mousedown", () => wurzel.setAttribute("data-tastatur", ""), true);
    wurzel.addEventListener("focusin", (e) => {
        const t = traeger(e && e.target);
        if (t && wurzel.getAttribute("data-tastatur") === "ja") t.classList.add("fokus");
    }, true);
    wurzel.addEventListener("focusout", (e) => {
        const t = traeger(e && e.target);
        if (t) t.classList.remove("fokus");
    }, true);
}
// Wächter auf Bedienfeld UND Dialoge; dazu die Absende-Hüllen (Baulehre 31):
// greift die unsichtbare Schaltfläche den Klick nicht ab — etwa weil der
// Wirt ihre absolute Lage ignoriert —, reicht die sichtbare Fläche ihn an
// den echten Knopf weiter und schickt das Formular danach NATIV ab. Nur das
// schließt ein uxpShowModal-Fenster verlässlich; die Klick-Handler allein
// (Wunsch merken + close()) wären genau der Einfrier-Pfad aus Baulehre 11.
// Kennt der Wirt kein requestSubmit, tut der Rückfall lieber gar nichts.
function knopfWaechterAlle() {
    knopfWaechterAnbinden(document.getElementById("wandInhalt"));
    document.querySelectorAll("dialog").forEach(knopfWaechterAnbinden);
    document.querySelectorAll(".huelle").forEach((huelle) => {
        if (huelle.getAttribute("data-waechter") === "ja") return;
        huelle.setAttribute("data-waechter", "ja");
        const flaeche = huelle.querySelector(".knopf");
        const echt    = huelle.querySelector("button");
        if (!flaeche || !echt) return;
        flaeche.addEventListener("click", () => {
            let form = echt.form || null;
            if (!form) { let p = huelle.parentNode; while (p && String(p.tagName).toUpperCase() !== "FORM") p = p.parentNode; form = p || null; }
            if (!form || typeof form.requestSubmit !== "function") return;
            // Erst die Handler des echten Knopfs (Wunsch merken, Eingabe prüfen) —
            // cancelable, damit ein preventDefault („Anlegen“ bei ungültiger
            // Eingabe) ankommt und das Fenster offen bleibt.
            const ev = new Event("click", { cancelable: true });
            echt.dispatchEvent(ev);
            if (ev.defaultPrevented) return;
            let dialog = huelle.parentNode; while (dialog && String(dialog.tagName).toUpperCase() !== "DIALOG") dialog = dialog.parentNode;
            if (dialog && dialog.open === false) return;      // close() hat schon gegriffen
            try { form.requestSubmit(echt); } catch (e) { /* dann bleibt Enter/Esc */ }
        });
    });
}
if (document.getElementById("wandInhalt")) knopfWaechterAlle();
else document.addEventListener("DOMContentLoaded", knopfWaechterAlle);

function rollHinweiseAuffrischen() {
    for (const zeigen of rollBereiche) { try { zeigen(); } catch (e) {} }
}

// Die Wand auf die gemessene Fensterhöhe setzen. height:100% läuft in
// InDesigns UXP-Wirt ins Leere (html/body werden nicht auf die
// Bedienfeldhöhe gezwungen — die Wand wüchse mit dem Inhalt und nichts
// rollte, der Wirt schnitte unten ab). Aufruf bei Start, resize und im
// Helligkeitstakt, denn An- und Abdocken meldet nicht immer ein resize.
let wandHoeheZuletzt = 0;
function wandMasseSetzen() {
    const wand   = document.querySelector(".rollrahmen.wand");
    const inhalt = document.getElementById("wandInhalt");
    if (wand && inhalt) {
        let h = 0;
        try { h = window.innerHeight || 0; } catch (e) { h = 0; }
        if (!h) { try { h = document.documentElement.clientHeight || 0; } catch (e) {} }
        if (h > 40 && h !== wandHoeheZuletzt) {
            wandHoeheZuletzt = h;
            wand.style.height   = h + "px";
            inhalt.style.height = h + "px";
        }
    }
    rollHinweiseAuffrischen();
}

// ============================================================================
//  Einstellungen
// ============================================================================

async function datenOrdner() {
    return await lfs.getDataFolder();
}

async function eintragOderNull(ordner, name) {
    try { return await ordner.getEntry(name); } catch (e) { return null; }
}

function einstellungenSaeubern() {
    einstellungen.aufloesung = Math.max(36, Math.min(1200, Math.round(zahl(einstellungen.aufloesung, 250))));
    einstellungen.linie = Math.max(0.05, Math.min(3, zahl(einstellungen.linie, 0.25)));
}

async function einstellungenLaden() {
    try {
        const ordner = await datenOrdner();
        const datei = await eintragOderNull(ordner, EINSTELLUNGSDATEI);
        if (datei) einstellungen = Object.assign(einstellungen, JSON.parse(await datei.read()));
    } catch (e) { /* dann die Vorgabewerte */ }
    einstellungenSaeubern();
}

async function einstellungenSichern() {
    try {
        const ordner = await datenOrdner();
        const datei = await ordner.createFile(EINSTELLUNGSDATEI, { overwrite: true });
        await datei.write(JSON.stringify(einstellungen, null, 2));
    } catch (e) { /* nicht schlimm — dann eben beim nächsten Mal */ }
}

// ============================================================================
//  Die Prüfungen
// ----------------------------------------------------------------------------
// Alle Maße in Punkt: die Maßeinheit wird für die Dauer der Prüfung
// umgestellt und danach zurückgedreht (Muster aus dem Export-Bedienfeld).
// ============================================================================

function mitPunkt(fn) {
    const idsn = indesign(), app = idsn.app;
    let alt = null;
    try { alt = app.scriptPreferences.measurementUnit; } catch (e) {}
    try {
        app.scriptPreferences.measurementUnit = idsn.MeasurementUnits.POINTS;
        return fn();
    } finally {
        try { if (alt !== null) app.scriptPreferences.measurementUnit = alt; } catch (e) {}
    }
}

function seitenName(objekt) {
    try {
        const seite = objekt.parentPage;
        return seite ? " · Seite " + String(seite.name) : "";
    } catch (e) { return ""; }
}

function fund(stufe, text, objektId) {
    funde.push({ stufe: stufe, text: text, objektId: objektId || 0 });
}

function pruefUebersatz(doc) {
    for (let i = 0; i < doc.stories.length; i++) {
        const geschichte = doc.stories.item(i);
        let voll = false;
        try { voll = geschichte.overflows === true; } catch (e) { voll = false; }
        if (!voll) continue;
        let rahmen = null;
        try {
            const behaelter = geschichte.textContainers;
            rahmen = behaelter[behaelter.length - 1];
        } catch (e) { rahmen = null; }
        let probe = "";
        try {
            probe = String(geschichte.contents).replace(/\s+/g, " ").substring(0, 24);
        } catch (e) { probe = ""; }
        fund("ernst", "Übersatztext" + (rahmen ? seitenName(rahmen) : "") +
             (probe ? " · „" + probe + "…“" : ""), rahmen ? rahmen.id : 0);
    }
}

function pruefVerknuepfungen(doc) {
    const idsn = indesign();
    for (let i = 0; i < doc.links.length; i++) {
        const glied = doc.links.item(i);
        let zustand = null, name = "";
        try { zustand = glied.status; } catch (e) { zustand = null; }
        try { name = String(glied.name); } catch (e) { name = "?"; }
        let rahmen = null;
        try { rahmen = glied.parent.parent; } catch (e) { rahmen = null; }
        const kennung = rahmen ? rahmen.id : 0;
        const wo = rahmen ? seitenName(rahmen) : "";
        try {
            if (zustand === idsn.LinkStatus.LINK_MISSING)
                fund("ernst", "Verknüpfung fehlt: " + name + wo, kennung);
            else if (zustand === idsn.LinkStatus.LINK_OUT_OF_DATE)
                fund("warn", "Verknüpfung geändert (neu laden): " + name + wo, kennung);
        } catch (e) { /* Enum nicht lesbar — überspringen */ }
    }
}

function pruefBilder(doc) {
    let grafiken = [];
    try { grafiken = doc.allGraphics; } catch (e) { grafiken = []; }
    for (let i = 0; i < grafiken.length; i++) {
        const bild = grafiken[i];
        let rahmen = null, name = "";
        try { rahmen = bild.parent; } catch (e) { rahmen = null; }
        try { name = bild.itemLink ? String(bild.itemLink.name) : ""; } catch (e) { name = ""; }
        const kennung = rahmen ? rahmen.id : 0;
        const wo = rahmen ? seitenName(rahmen) : "";

        // Farbraum kennt nur die Bildklasse — PDF, EPS und AI melden hier
        // nichts und bleiben still.
        try {
            const raum = String(bild.space);
            if (raum.toUpperCase().indexOf("RGB") >= 0)
                fund("warn", "RGB-Bild: " + (name || "eingebettet") + wo, kennung);
        } catch (e) { /* keine Bilddatei */ }

        // Effektive Auflösung: der kleinere der beiden Werte zählt.
        try {
            const ppi = bild.effectivePpi;
            const kleinste = Math.round(Math.min(ppi[0], ppi[1]));
            if (kleinste > 0 && kleinste < einstellungen.aufloesung)
                fund(kleinste < 150 ? "ernst" : "warn",
                     "Auflösung " + kleinste + " ppi: " + (name || "Bild") + wo, kennung);
        } catch (e) { /* keine Rasterdaten */ }
    }
}

function konturSichtbar(objekt) {
    try {
        const farbe = objekt.strokeColor;
        const name = farbe ? String(farbe.name) : "";
        if (name.indexOf("None") >= 0 || name.indexOf("Ohne") >= 0) return false;
    } catch (e) { /* dann zählt die Stärke allein */ }
    return true;
}

function pruefLinien(doc) {
    let dinge = [];
    try { dinge = doc.allPageItems; } catch (e) { dinge = []; }
    for (let i = 0; i < dinge.length; i++) {
        const ding = dinge[i];
        let staerke = null;
        try { staerke = ding.strokeWeight; } catch (e) { staerke = null; }
        if (typeof staerke !== "number" || staerke <= 0 || staerke >= einstellungen.linie) continue;
        if (!konturSichtbar(ding)) continue;
        // Nur, was auf einer Seite liegt — Montagefläche stört im Druck nicht.
        let aufSeite = false;
        try { aufSeite = !!ding.parentPage; } catch (e) { aufSeite = false; }
        if (!aufSeite) continue;
        fund("warn", "Haarlinie " + alsText(staerke) + " pt" + seitenName(ding), ding.id);
    }
}

// Objekte, die an der Seitenkante enden, aber nicht bis zur Anschnittkante
// reichen — die klassische weiße Blitzkante beim Beschnitt.
function pruefAnschnitt(doc) {
    const b = doc.documentPreferences;
    let anschnitt = 0;
    try {
        anschnitt = Math.min(b.documentBleedTopOffset, b.documentBleedBottomOffset,
                             b.documentBleedInsideOrLeftOffset, b.documentBleedOutsideOrRightOffset);
    } catch (e) { anschnitt = 0; }
    if (anschnitt <= 0.05) return "ohne Anschnitt";

    const eps = 0.75;   // Punkt — kleine Ungenauigkeiten beim Zeichnen verzeihen
    for (let s = 0; s < doc.pages.length; s++) {
        const seite = doc.pages.item(s);
        const sb = seite.bounds;   // [oben, links, unten, rechts]
        let dinge = [];
        try { dinge = seite.pageItems.everyItem().getElements(); } catch (e) { dinge = []; }
        for (let i = 0; i < dinge.length; i++) {
            const ding = dinge[i];
            let gb = null;
            try { gb = ding.visibleBounds; } catch (e) {
                try { gb = ding.geometricBounds; } catch (e2) { gb = null; }
            }
            if (!gb || gb.length !== 4) continue;
            const kanten = [];
            if (gb[1] <= sb[1] + eps && gb[1] > sb[1] - anschnitt + eps) kanten.push("links");
            if (gb[3] >= sb[3] - eps && gb[3] < sb[3] + anschnitt - eps) kanten.push("rechts");
            if (gb[0] <= sb[0] + eps && gb[0] > sb[0] - anschnitt + eps) kanten.push("oben");
            if (gb[2] >= sb[2] - eps && gb[2] < sb[2] + anschnitt - eps) kanten.push("unten");
            if (kanten.length)
                fund("warn", "Reicht nicht in den Anschnitt (" + kanten.join(", ") + ")" +
                     " · Seite " + String(seite.name), ding.id);
        }
    }
    return "";
}

// ============================================================================
//  Prüfung, Liste, Sprung
// ============================================================================

async function pruefen() {
    if (prueft) return;
    const idsn = indesign(), app = idsn.app;
    if (!app.documents.length) { status("Kein Dokument geöffnet.", "fehler"); return; }

    prueft = true;
    const knopf = document.getElementById("pruefKnopf");
    const knopfText = knopf ? knopf.textContent : "";
    if (knopf) { knopf.textContent = "prüft …"; knopfGesperrt(knopf, true); }
    status("Prüfung läuft …");
    funde = [];
    let hinweis = "";
    try {
        await kurzeAtempause();
        const doc = app.activeDocument;
        mitPunkt(() => {
            try { pruefUebersatz(doc); }      catch (e) { fund("warn", "Übersatzprüfung scheiterte: " + e, 0); }
            try { pruefVerknuepfungen(doc); } catch (e) { fund("warn", "Verknüpfungsprüfung scheiterte: " + e, 0); }
            try { pruefBilder(doc); }         catch (e) { fund("warn", "Bildprüfung scheiterte: " + e, 0); }
            try { pruefLinien(doc); }         catch (e) { fund("warn", "Linienprüfung scheiterte: " + e, 0); }
            try { hinweis = pruefAnschnitt(doc) || ""; } catch (e) { fund("warn", "Anschnittprüfung scheiterte: " + e, 0); }
        });
        // Ernstes zuerst, dabei die gefundene Reihenfolge je Stufe behalten.
        const ernst = [], warn = [];
        for (const f of funde) (f.stufe === "ernst" ? ernst : warn).push(f);
        funde = ernst.concat(warn);
        listeBauen();
        if (!funde.length) {
            status("Alles sauber" + (hinweis ? " · " + hinweis : "") + ".", "erfolg");
        } else {
            status(funde.length + (funde.length === 1 ? " Fund" : " Funde") +
                   (ernst.length ? " · " + ernst.length + " ernst" : "") +
                   (hinweis ? " · " + hinweis : ""),
                   ernst.length ? "fehler" : undefined);
        }
    } catch (fehler) {
        status("Prüfung abgebrochen: " + (fehler && fehler.message ? fehler.message : fehler), "fehler");
    } finally {
        prueft = false;
        prueftSchon = true;
        if (knopf) { knopf.textContent = knopfText; knopfGesperrt(knopf, false); }
    }
}

// Ob seit dem Start schon geprüft wurde — leer heißt dann „sauber“, nicht
// „noch nicht gelaufen“.
let prueftSchon = false;

function listeBauen() {
    const liste = document.getElementById("fundListe");
    if (!liste) return;
    liste.innerHTML = "";
    liste.classList.toggle("leer", funde.length === 0);
    if (!funde.length) {
        const zeile = document.createElement("div");
        zeile.className = "fund stumm platzhalter";
        const text = document.createElement("span");
        text.className = "text";
        text.textContent = prueftSchon
            ? "Keine Funde — das Dokument ist sauber."
            : "Noch nicht geprüft. „Prüfen“ kontrolliert Übersatz, Verknüpfungen, RGB, Auflösung, Haarlinien und Anschnitt.";
        zeile.appendChild(text);
        liste.appendChild(zeile);
    }
    for (const f of funde) {
        const zeile = document.createElement("div");
        zeile.className = "fund " + (f.stufe === "ernst" ? "ernst" : "warn") +
                          (f.objektId ? "" : " stumm");
        const punkt = document.createElement("span");
        punkt.className = "punkt";
        punkt.textContent = "●";
        const text = document.createElement("span");
        text.className = "text";
        text.textContent = f.text;
        zeile.appendChild(punkt);
        zeile.appendChild(text);
        zeile.setAttribute("title", f.text + (f.objektId ? "  ·  Klick wählt das Objekt aus" : ""));
        if (f.objektId) zeile.addEventListener("click", () => springen(f));
        liste.appendChild(zeile);
    }
    rollHinweiseAuffrischen();
}

function springen(f) {
    const idsn = indesign(), app = idsn.app;
    if (!app.documents.length) { status("Kein Dokument geöffnet.", "fehler"); return; }
    try {
        const doc = app.activeDocument;
        let objekt = null;
        try {
            objekt = doc.pageItems.itemByID(f.objektId);
            if (!objekt.isValid) objekt = null;
        } catch (e) { objekt = null; }
        if (!objekt) {
            // In Gruppen steckt es tiefer — dann eben der lange Weg.
            const alle = doc.allPageItems;
            for (let i = 0; i < alle.length; i++) {
                if (alle[i].id === f.objektId) { objekt = alle[i]; break; }
            }
        }
        if (!objekt) { status("Das Objekt gibt es nicht mehr — bitte neu prüfen."); return; }
        app.select(objekt);
        // Einpassen über den Menübefehl; hat das Bedienfeld den Fokus, meldet
        // der Befehl enabled=false — dann erst das Layoutfenster nach vorn.
        try {
            const befehl = app.menuActions.itemByID(MENUE_AUSWAHL);
            if (befehl.isValid) {
                if (!befehl.enabled) { try { app.activeWindow.bringToFront(); } catch (e) {} }
                befehl.invoke();
            }
        } catch (e) { /* dann bleibt es bei der Auswahl */ }
        status("Ausgewählt: " + f.text);
    } catch (fehler) {
        status("Sprung ging nicht: " + (fehler && fehler.message ? fehler.message : fehler), "fehler");
    }
}

// ============================================================================
//  Oberfläche
// ============================================================================

function helligkeitUebernehmen() {
    let hell = false;
    try {
        const wert = indesign().app.generalPreferences.uiBrightnessPreference;
        hell = (typeof wert === "number") ? wert > 0.6 : false;
    } catch (e) { hell = false; }
    document.documentElement.classList.toggle("hell", hell);
    wandMasseSetzen();
}

let helligkeitsWaechter = null;
let verdrahtet = false;

function felderZeigen() {
    const a = document.getElementById("feldAufloesung");
    const l = document.getElementById("feldLinie");
    if (a) a.value = String(einstellungen.aufloesung);
    if (l) l.value = alsText(einstellungen.linie);
}

function verdrahten() {
    if (verdrahtet) return;
    const knopf = document.getElementById("pruefKnopf");
    if (!knopf) return;
    verdrahtet = true;

    knopf.addEventListener("click", () => pruefen());

    [["feldAufloesung", "aufloesung"], ["feldLinie", "linie"]].forEach(([id, schluessel]) => {
        const feld = document.getElementById(id);
        if (!feld) return;
        feld.addEventListener("change", async () => {
            einstellungen[schluessel] = zahl(feld.value, einstellungen[schluessel]);
            einstellungenSaeubern();
            felderZeigen();
            await einstellungenSichern();
        });
    });

    rollHinweiseAnbinden(document.getElementById("wandInhalt"));
    window.addEventListener("resize", wandMasseSetzen);
    messenWennBereit();
    wandMasseSetzen();
}

async function starten() {
    helligkeitUebernehmen();
    if (!helligkeitsWaechter) helligkeitsWaechter = setInterval(helligkeitUebernehmen, 3000);
    verdrahten();
    await einstellungenLaden();
    felderZeigen();
    listeBauen();          // leere Liste = Platzhalter im Listenbereich
    status("bereit");
}

try {
    const { entrypoints } = require("uxp");
    entrypoints.setup({
        panels: {
            dwbPruefung: {
                show() { starten(); messenWennBereit(); },
                menuItems: [
                    { id: "pruefen",    label: "Prüfen" },
                    { id: "selbsttest", label: "Selbsttest" }
                ],
                invokeMenu(id) {
                    if (id === "pruefen") pruefen();
                    if (id === "selbsttest") selbsttest();
                }
            }
        }
    });
} catch (e) {
    status("Bedienfeld konnte sich nicht anmelden: " + e, "fehler");
}

document.addEventListener("DOMContentLoaded", () => { starten(); });
starten();

// ============================================================================
//  Selbsttest
// ----------------------------------------------------------------------------
// Baut ein Testdokument mit absichtlichen Fehlern (Übersatz, Haarlinie,
// Kante ohne Anschnitt), prüft es und schreibt das Protokoll in den
// Datenordner. Aufruf über das Bedienfeldmenü — oder beim Start, wenn dort
// eine Datei „selbsttest.txt“ liegt.
// ============================================================================

async function selbsttest() {
    if (prueft) { status("Es läuft gerade eine Prüfung — Selbsttest bitte danach.", "fehler"); return; }
    const zeilen = [];
    const merke = (t) => { zeilen.push(String(t)); status("Selbsttest: " + t); };
    let doc = null;
    try {
        const idsn = indesign(), app = idsn.app;
        merke("InDesign " + app.version);
        await einstellungenLaden();

        doc = app.documents.add();
        doc.documentPreferences.documentBleedUniformSize = true;
        doc.documentPreferences.documentBleedTopOffset = "3mm";

        mitPunkt(() => {
            const seite = doc.pages.item(0);
            const sb = seite.bounds;
            // 1. Übersatz: winziger Rahmen, viel Text.
            const textRahmen = seite.textFrames.add();
            textRahmen.geometricBounds = [sb[0] + 40, sb[1] + 40, sb[0] + 60, sb[1] + 120];
            let text = "Übersatz ";
            for (let i = 0; i < 8; i++) text += text;
            textRahmen.contents = text;
            // 2. Haarlinie mitten auf der Seite.
            const linie = seite.rectangles.add();
            linie.geometricBounds = [sb[0] + 100, sb[1] + 40, sb[0] + 140, sb[1] + 120];
            linie.strokeWeight = 0.1;
            try { linie.strokeColor = doc.swatches.itemByName("Black"); } catch (e) {
                try { linie.strokeColor = doc.swatches.item(3); } catch (e2) {}
            }
            // 3. Fläche exakt bis zur Seitenkante, aber nicht in den Anschnitt.
            const flaeche = seite.rectangles.add();
            flaeche.geometricBounds = [sb[0], sb[1], sb[0] + 80, sb[1] + 60];
        });
        merke("Testdokument mit drei absichtlichen Fehlern steht");

        await pruefen();
        merke("Statuszeile: " + document.getElementById("status").textContent);
        merke("Funde (" + funde.length + "):");
        for (const f of funde) merke("  [" + f.stufe + "] " + f.text + " (Objekt " + f.objektId + ")");

        const uebersatzDa  = funde.some(f => f.text.indexOf("Übersatz") >= 0);
        const linieDa      = funde.some(f => f.text.indexOf("Haarlinie") >= 0);
        const anschnittDa  = funde.some(f => f.text.indexOf("Anschnitt") >= 0);
        merke("Erwartung erfüllt? Übersatz " + uebersatzDa + " · Haarlinie " + linieDa +
              " · Anschnitt " + anschnittDa);

        // Springt der erste Fund?
        if (funde.length && funde[0].objektId) {
            springen(funde[0]);
            const idsn2 = indesign();
            merke("Sprung: Auswahl danach " + idsn2.app.selection.length + " Objekt(e)");
        }

        merke("fertig");
    } catch (fehler) {
        zeilen.push("ABBRUCH: " + fehler + (fehler && fehler.stack ? " | " + fehler.stack : ""));
    }
    try {
        if (doc) doc.close(indesign().SaveOptions.NO);
    } catch (e) { zeilen.push("Schließen: " + e); }
    try {
        const ordner = await datenOrdner();
        const datei = await ordner.createFile(PROTOKOLLDATEI, { overwrite: true });
        await datei.write(zeilen.join("\n"));
    } catch (e) { /* dann eben nicht */ }
    status("Selbsttest fertig — Protokoll im Datenordner.");
}

// Beim Start prüfen, ob ein Selbsttest gewünscht ist.
setTimeout(async () => {
    try {
        const ordner = await datenOrdner();
        const marke = await eintragOderNull(ordner, SELBSTTEST_MARKE);
        if (marke) {
            await marke.delete();
            await selbsttest();
        }
    } catch (e) { /* kein Selbsttest */ }
}, 900);
