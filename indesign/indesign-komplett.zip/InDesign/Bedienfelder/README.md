# dwb-Bedienfelder für InDesign

Zwei eigenständige UXP-Plugins — echte Bedienfelder, die sich andocken lassen
und nach jedem Programmstart da sind:

| Bedienfeld | Was drin ist |
|---|---|
| **Ansicht dwb** | Seite · 100 % · Objekt · Montagefläche · eigene Zoomstufen · Hilfslinien · Importoptionen |
| **Export dwb** | frei angelegte PDF-Knöpfe (ab Werk Print · Newspaper · Web) · JPG · PNG · Verpacken |
| **Prüfung dwb** | Reinzeichnungs-Ampel: Übersatz, Verknüpfungen, RGB, Auflösung, Haarlinien, Anschnitt |

**Stand:** 2026-08-30 · Version 1.0 · geprüft mit InDesign 21.5.1 (2026), macOS

---

## Installation

```bash
"/Users/danielbittner/Claude Code/InDesign/Bedienfelder/installieren.command"
```

Doppelklick tut es auch — dann fragt das Skript kurz, ob es einrichten,
entfernen oder prüfen soll (Eingabetaste = Einrichten). Es kopiert beide
Plugins nach
`~/Library/Application Support/Adobe/UXP/Plugins/External/` und trägt sie in
`~/Library/Application Support/Adobe/UXP/PluginsInfo/v1/ID.json` ein — genau
dort sucht InDesign nach fremden Bedienfeldern. Fremde Einträge in der Datei
bleiben stehen.

**InDesign danach neu starten.** Die Bedienfelder stehen dann unter

    Plug-ins ▸ Ansicht dwb ▸ Ansicht dwb
    Plug-ins ▸ Export dwb ▸ Export dwb

Wieder herausnehmen:

```bash
"/Users/danielbittner/Claude Code/InDesign/Bedienfelder/installieren.command" --entfernen
```

`--entfernen` lässt die Einstellungen (eigene Zoomstufen, Export-Knöpfe,
Protokolle) im PluginsStorage stehen; `--entfernen-alles` löscht auch sie.
`--pruefen` kontrolliert Plugin-Ordner, Verzeichnisdatei und das jüngste
UXP-Log, ohne etwas zu ändern, und `--ausfuehrlich` zeigt jeden Pfad einzeln
statt nur der Häkchen-Bilanz. Beim Update räumt das Skript auch ältere
Versionsordner der Plugins ab und nimmt die gesicherten Einstellungen aus dem
Ordner einer älteren InDesign-Hauptversion mit, wenn der neue noch leer ist.

Nach einer Änderung am Quelltext genügt `installieren.command` und ein
Neustart von InDesign; das Adobe UXP Developer Tool wird nicht gebraucht.

Läuft auf dem Rechner kein Skript, lassen sich beide Schritte — Ordner kopieren
und `ID.json` ergänzen — auch von Hand erledigen:
**[../Handinstallation.md](../Handinstallation.md)**.

---

## Ansicht dwb

| Knopf | Wirkung |
|---|---|
| **Seite** | Seite ins Fenster einpassen · **Alt-Klick:** ganzer Druckbogen |
| **100 %** | Originalgröße. Ist etwas ausgewählt, wird auf die Auswahl gezoomt und dann auf 100 % gestellt |
| **Objekt** | Auswahl ins Fenster einpassen |
| **Montage** | Ganze Montagefläche zeigen |
| **50 %**, **200 %**, … | eigene Stufen, beliebig viele (gestrichelter Rahmen) |
| **Hilfslinien …** | Hilfslinien an genau eingetippten Positionen anlegen (zweite Reihe, abgesetzt) |
| **Importoptionen …** | öffnet das gleichnamige Script (zweite Reihe, abgesetzt) |

Die eigenen Stufen legst du selbst an: **Alt-Klick** oder **Rechtsklick** auf
einen der Knöpfe, oder Bedienfeldmenü ▸ *Zoomstufen festlegen…*. Das Fenster
führt sie als Liste — **+ Stufe** hängt eine an, **✕** löscht, **↑ ↓**
verschieben, **Zurücksetzen** stellt 50 % und 200 % wieder her. Je Zeile eine
Aufschrift (leer = der Wert steht auf dem Knopf) und der Zoomwert, 5 bis
4000 %. Auch gar keine eigene Stufe ist erlaubt.

Ist etwas ausgewählt, springen die Knöpfe auf die Auswahl und stellen dort die
Stufe ein — sonst zoomen sie um die Fenstermitte. Die Liste liegt im
Datenordner des Plugins und übersteht den Neustart.

Die Knöpfe brechen um, wenn das Bedienfeld schmal angedockt ist — bei rund
210 px stehen sie zu zweit in drei Reihen, breiter nebeneinander.

### Der Knopf „Hilfslinien …“

Öffnet ein Fenster, in dem du Hilfslinien an exakten Positionen anlegst — ein
Feld für horizontale Linien (gemessen von der Oberkante der Seite), eines für
vertikale (von der linken Kante). Mehrere Werte auf einmal, durch Leerzeichen
oder Semikolon getrennt; das Komma ist das Dezimalkomma (`10  148,5  200`).
Die Einheit wählst du darunter (Millimeter · Zentimeter · Punkt · Zoll ·
Pixel, vorbelegt mit der Maßeinheit des Dokuments); eine Einheit direkt am
Wert (`12mm`, `3cm`, `100pt`, `1in`) überstimmt die Auswahl. Negative Werte
legen die Linie auf die Montagefläche.

Beim Öffnen zeigt das Fenster zuerst den **Bestand**: die Hilfslinien der
aktuellen Seite (samt Druckbogenlinien) auf der **aktiven Ebene**, als
Werteliste in der gewählten Einheit — wechselst du die Einheit, rechnet die
Anzeige um. Linien auf anderen Ebenen werden nur gezählt. **In die Felder
übernehmen** stellt die Werte in die Eingabefelder — zum Anpassen und, mit
„vorher entfernen“, erneuten Anlegen (die Werte sind dabei auf zwei
Nachkommastellen der Einheit gerundet).

Dazu drei Schalter: **Wirkt auf** (aktuelle Seite oder alle Seiten), **über
den ganzen Druckbogen ziehen** (die Linie endet nicht an der Seitenkante) und
**Hilfslinien der aktiven Ebene vorher entfernen** (räumt Seiten- und
Druckbogenlinien der Zielseiten ab — nur auf der aktiven Ebene, fremde
Ebenen bleiben unberührt). Alles zusammen ist EIN Rückgängig-Schritt.
Gemessen wird immer ab der Seitenkante — Nullpunkt und Linealursprung des
Dokuments bleiben unangetastet, das Fenster stellt sie intern kurz um und
wieder zurück. Auch über das Bedienfeldmenü ▸ *Hilfslinien anlegen…*
erreichbar; die letzten Eingaben stehen beim nächsten Öffnen wieder da (bis
zum InDesign-Neustart).

### Der Knopf „Importoptionen …“

Er gehört nicht zum Zoomen und steht deshalb durch eine Linie abgesetzt in
einer eigenen Reihe. Dahinter liegt kein UXP-Code, sondern das ExtendScript
`Claude Code/InDesign/Importoptionen/Importoptionen.jsx` — es ändert Seite,
Beschnitt und Ebenen einer bereits platzierten Datei nachträglich.

Aufgerufen wird es über den Menübefehl **Objekt ▸ Importoptionen ändern …**,
den `Menue-Startup.jsx` beim Programmstart anlegt: `app.scriptMenuActions
.itemByName(…).invoke()` — derselbe Weg, über den auch „Objekt“ den
InDesign-Befehl 118790 aufruft. Fehlt der Menübefehl, sucht der Knopf die
Datei im Skriptbedienfeld. Ein UXP-Bedienfeld kann ExtendScript nicht direkt
ausführen; der Umweg über eine Menüaktion ist die verlässliche Brücke.

---

## Export dwb

Fünf Knöpfe, jeder ein fertiger Export ohne Dialog:

* **PDF-Knöpfe** — so viele, wie du willst. Ab Werk sind es drei (Print,
  Newspaper, Web) mit passenden Vorschlägen: Print → *[Druckausgabequalität]*,
  Newspaper → *[Qualitativ hochwertiger Druck]*, Web → deine Vorgabe *web*.
  Im Einstellfenster legst du beliebig viele an („**+ Knopf**“), löschst sie
  („**✕**“), verschiebst sie („**↑ ↓**“) und bestimmst je Knopf Aufschrift,
  PDF-Exportvorgabe, Unterordner und „eine Datei je Seite“. Auch gar kein
  PDF-Knopf ist erlaubt.
* **JPG** und **PNG** — Qualität, Farbraum und Größe stehen in den
  Einstellungen. Die Größe wahlweise als **Auflösung in ppi** oder als
  **Pixelmaß**: dann gibst du Breite und/oder Höhe in Bildpunkten an, und das
  Bedienfeld rechnet je Datei die nötige Auflösung aus — der höhere der beiden
  Wünsche gewinnt, ein leeres Feld zählt nicht mit. Praktisch für „längste
  Seite 2000 px“, ohne selbst zu rechnen. Weil Seiten, Druckbögen und einzelne
  Objekte verschieden groß sind, wird die Auflösung **je Datei neu** ermittelt;
  ein eingeschalteter Anschnitt wird mitgerechnet. Die Statuszeile nennt danach
  die tatsächlich verwendete Auflösung.
* **Verpacken** — sichert das Dokument und verpackt es wie über
  Datei ▸ Verpacken: Schriften, verknüpfte Grafiken und Farbprofile wandern in
  einen Ordner **„‹Dokument› verpackt“ neben der Dokumentdatei** (bewusst nicht
  in den Export-Zielordner — das Paket gehört zur Quelle). Ist der Name belegt,
  wird numeriert („… verpackt 2“); nur bei eingeschaltetem „vorhandene Dateien
  überschreiben“ wird derselbe Ordner wiederverwendet. Ohne Bericht und IDML.
  Im Abschnitt **„Verpacken“** des Einstellfensters gibt es zwei Zugaben:
  ein **Druck-PDF mit ins Paket** (Vorgabe wählbar) und das Paket zusätzlich
  **als ZIP daneben** — fertig für die Mail an die Druckerei (ZIP nur am Mac;
  die Brücke ist ein AppleScript-Einzeiler, UXP kann selbst nicht packen).
  Ein noch nie gesichertes Dokument wird nicht verpackt, sondern freundlich um
  „Sichern unter …“ gebeten. Steht „Danach“ nicht auf „nichts tun“, öffnet
  sich der Paketordner.

Im Einstellfenster sichert die **Eingabetaste**, **Esc** bricht ab. Links unten
setzt **Zurücksetzen** alles auf den Auslieferungszustand zurück — zunächst nur
in den Feldern: „Sichern“ übernimmt es, „Abbrechen“ verwirft es wieder. Im
Zoomstufen-Fenster des Ansicht-Bedienfelds gibt es denselben Knopf (zurück auf
50 % und 200 %).

Das Fenster **„Export einstellen“** liegt im Querformat: oben die drei
PDF-Knöpfe als Tabelle (Aufschrift · PDF-Exportvorgabe · Unterordner · eine je
Seite), darunter zwei Spalten — „Ziel und Dateiname“ neben „Umfang“, „JPG“
neben „PNG“. Wird das Fenster schmal gezogen, rutschen die Spalten
untereinander. Es öffnet sich über den Knopf **…**, über
**Alt-Klick** oder **Rechtsklick** auf einen der Knöpfe (dann steht gleich die
richtige Zeile im Zugriff) oder über das Bedienfeldmenü.

### Was sich einstellen lässt

**PDF-Knöpfe** — die Liste ganz oben: je Zeile Aufschrift,
PDF-Exportvorgabe, eigener Unterordner, „je Seite“, dazu **↑ ↓** zum
Verschieben und **✕** zum Löschen. „**+ Knopf**“ hängt einen neuen an.

**Ziel und Dateiname**

* Ordner des Dokuments · fester Ordner · jedes Mal fragen
* Unterordner (wird angelegt, wenn es ihn nicht gibt)
* Dateiname mit Platzhaltern:
  `{dok}` `{knopf}` `{seite}` `{nr}` `{datum}` `{zeit}` `{format}`

**Umfang** — alle Seiten · aktuelle Seite · Seitenbereich · Auswahl.
Der Seitenbereich versteht `1-3, 5, 8-`; Zahlen werden zuerst als Seitenname
gelesen (Abschnitte, römische Ziffern), sonst als laufende Nummer.

**Auswahl** heißt bei JPG und PNG: jedes markierte Objekt wird als eigene
Bilddatei exportiert. Beim PDF gibt es das nicht — dort werden die *Seiten*
exportiert, auf denen die Auswahl liegt.

Dazu: Druckbogen statt Einzelseiten (JPG/PNG), vorhandene Dateien
überschreiben (sonst `_2`, `_3` …), danach den Ordner im Finder zeigen.

### Selbsttest

Bedienfeldmenü ▸ **Selbsttest**. Legt ein Testdokument an, exportiert einmal
in alle Formate und schreibt ein Protokoll in den Datenordner des Plugins:

    ~/Library/Application Support/Adobe/UXP/PluginsStorage/IDSN/<Versionsnummer>/External/de.dwb.export/PluginData/

Dort liegen auch die Einstellungen (`einstellungen.json`). Liegt in diesem
Ordner eine Datei `selbsttest.txt`, läuft der Selbsttest beim nächsten Start
von allein — so lässt sich das Bedienfeld ohne einen einzigen Klick prüfen.

---

## Prüfung dwb

Die Reinzeichnungs-Ampel: **ein Klick auf „Prüfen“** kontrolliert das ganze
Dokument auf die Fehler, die sonst erst im fertigen PDF auffallen —

* **Übersatztext** (ernst)
* **fehlende Verknüpfungen** (ernst) und **geänderte** (Warnung)
* **RGB-Bilder** (Warnung; PDF/EPS/AI melden keinen Farbraum und bleiben still)
* **effektive Bildauflösung** unter der Schwelle — der kleinere der beiden
  ppi-Werte zählt; unter 150 ppi wird es ernst
* **Haarlinien** — Konturen unter der Schwelle, nur auf Seiten (die
  Montagefläche stört im Druck nicht)
* **Anschnitt-Lücken** — Objekte, die an der Seitenkante enden, aber nicht
  bis zur Anschnittkante reichen (die klassische weiße Blitzkante). Ist der
  Anschnitt des Dokuments 0, entfällt diese Prüfung; die Statuszeile sagt es.

Jeder Fund ist eine Zeile, Ernstes zuerst (roter Punkt, Warnungen orange).
**Ein Klick auf die Zeile wählt das Objekt aus und passt es ins Fenster ein**
(über den Menübefehl 118790 — wie beim Ansicht-Bedienfeld). Die beiden
Schwellen — Auflösung (ab Werk 250 ppi) und Linienstärke (ab Werk 0,25 pt) —
stehen direkt im Bedienfeld und werden gemerkt.

Nicht geprüft werden: Tabellen-Übersatz in einzelnen Zellen, Objektformate
und Überdrucken. Der **Selbsttest** (Bedienfeldmenü) baut ein Testdokument
mit drei absichtlichen Fehlern, prüft es und schreibt das Protokoll in den
Datenordner (`…/External/de.dwb.pruefung/PluginData/`).

---

## Was beim Bauen Zeit gekostet hat

1. **Der Manifest-Fehler steht im Log, nicht auf dem Bildschirm.** InDesign
   schweigt, wenn ein Plugin nicht lädt. Warum es scheitert, steht in
   `~/Library/Logs/Adobe/Adobe InDesign */UXPLogs_<Datum>.log` — der
   Jahresordner im Pfad wächst nicht mit der InDesign-Version mit, deshalb
   der Stern; `installieren.command --pruefen` durchsucht das jüngste Log
   von selbst.
   Dort stand auch der entscheidende Satz:
   *„Expected the host attribute to be an object for the 3P Plugin“* —
   Adobes eigene Bedienfelder schreiben `"host": [ … ]` als Liste, fremde
   müssen `"host": { "app": "ID", … }` als Objekt schreiben.

2. **`element.click()` tut in UXP nichts.** Die Methode existiert, löst aber
   keine Ereignisse aus. Wer einen Knopf aus dem Skript heraus drücken will
   (Selbsttest), braucht `element.dispatchEvent(new Event("click"))`.

3. **`exportFile` nimmt einen einfachen Pfad als Zeichenkette.** Der Umweg
   über `localFileSystem.createEntryWithUrl` ist nur nötig, um Ordner
   anzulegen oder zu lesen — und der scheitert, wenn der übergeordnete Ordner
   noch nicht existiert. `require("fs")` kann in UXP zwar `writeFileSync`,
   aber kein `mkdirSync`.

4. **InDesign hängt an Bilddateien einen eigenen Anhang an.** In den
   Voreinstellungen steht in `pngExportPreferences.pngSuffix` gern noch etwas
   wie `_1200dpi` vom letzten Export über den Dialog — und dann heißt die
   Datei nicht so, wie das Bedienfeld sie nennt. Muss vor jedem Bildexport
   auf leer gesetzt und danach zurückgestellt werden.

5. **Ein ungültiger Seitenbereich beim Bildexport reißt InDesign mit.**
   `pageString = "+99"` in einem Dokument mit vier Seiten hat 21.5.1 beim
   Test abgeschossen. Das Bedienfeld löst den eingegebenen Bereich deshalb
   erst in echte Seitenobjekte auf; an den Export geht nur, was es gibt.

6. **„Auswahl einpassen“ gibt es im Skriptmodell nicht.** `ZoomOptions` kennt
   nur Seite, Druckbogen, Originalgröße und Montagefläche. Der Rest läuft über
   den Menübefehl mit der ID **118790** (in allen Sprachen dieselbe). Hat das
   Bedienfeld den Tastaturfokus, meldet der Befehl sich als deaktiviert — dann
   hilft ein `bringToFront()` auf das Dokumentfenster.

7. **Der Wirt malt die Dialogfläche nicht mit.** Ein `<dialog>` in UXP bekommt
   keine Hintergrundfarbe vom Programm — wer keine setzt, hat grauen Text auf
   grauem Grund. Fläche, Felder und Schrift werden hier deshalb selbst
   gesetzt, ebenso bei `input` und `select`.

8. **`uiBrightnessPreference` ist 0,5 im mittleren Grau.** InDesign kennt vier
   Oberflächenhelligkeiten; die zweite (Standard) meldet 0,5 — immer noch ein
   kräftiges Grau, in dem weißer Text stehen muss. Als hell zählt hier erst
   alles über 0,6. Gemessene Kontraste im Dialog: weißer Text auf #3A3A3A
   (11,4:1), auf #454545 (9,6:1), Hinweiszeilen #D2D2D2 auf #454545 (6,4:1) —
   alle deutlich über den 4,5:1 der WCAG-Stufe AA.

9. **Bei der Fenstergröße eines UXP-Dialogs zählt nur die Höhe — und die als
   Mindestmaß.** Die Breite aus `size: { width, height }` ignoriert der Wirt
   (900 angefordert → 650 bekommen, 880 → 558), und eine feste CSS-Breite wird
   gekappt, sodass der Inhalt rechts abgeschnitten wird. Die **Höhe** dagegen
   setzt er als Untergrenze durch: mit `height: 880` stand unter dem Inhalt
   ein handbreiter leerer Streifen. Also klein anfordern (`height: 200`) und
   den Inhalt die Höhe bestimmen lassen. Was gilt: `#fenster { width: 100 % }`, damit der Inhalt genau so breit
   ist wie das Fenster, und ein Rumpf mit **fester Höhe plus eigenem
   Scrollbalken** (`height` + `overflow-y: auto`) — sonst wächst das Fenster
   in der Höhe über den Bildschirmrand hinaus und schneidet unten ab.
   Nachmessen statt raten: das Bedienfeld schreibt beim Schließen des Dialogs
   `fenster-mass.txt` in seinen Datenordner. Genau daraus kam der zweite
   Fehler ans Licht — die Spalten hatten 268 px Grundbreite, der Rumpf war
   534 px breit, und 2 × 268 + 10 Abstand liegen 12 px darüber: also alles
   untereinander. Jetzt sind es 226 px.

10. **Ein Flex-Container mit fester Höhe staucht seine Kinder, statt zu
   scrollen.** `display: flex; flex-direction: column; height: 540px` hat die
   Blöcke zusammengedrückt; ihr Inhalt lief aus dem Kasten heraus und legte
   sich über den nächsten Block. Der Rumpf ist deshalb ein schlichter
   **Block** mit `height` + `overflow-y: auto`, die Abstände kommen aus
   `margin-bottom` statt aus `gap`.

11. **Ein modal geöffneter UXP-Dialog lässt sich aus dem Skript heraus nicht
   wieder schließen.** `dialog.close(...)` greift bei einem mit
   `uxpShowModal()` geöffneten Fenster nicht — InDesign steht dann auf
   `modalState = true`, nimmt keine Menübefehle mehr an und lässt sich auch
   nicht mehr beenden. **`dialog.show()` dagegen schon:** nicht modal, blockiert
   nichts, schließt sich per `close()` wieder. Genau so vermisst der Selbsttest
   den Dialog — unsichtbar geparkt, auf 850 und auf 558 px Breite, und zählt
   dabei gestauchte und überlappende Blöcke.

12. **Ein `<span>` im `<label>` sieht in UXP aus wie deaktiviert.** Steht der
   Text eines Ankreuzfeldes in einem verschachtelten `<span>`, zeichnet UXP
   ihn grau statt in der Schriftfarbe — er wirkt ausgegraut, obwohl nichts
   deaktiviert ist. Ankreuf- und Radiozeilen deshalb als
   `<div><input id="x"><label for="x">Text</label></div>` bauen: das Kästchen
   und ein eigenes, per `for` verknüpftes Label. Nachgemessen: die Labels
   rechnen jetzt auf `#FFFFFF`.

13. **Die Eingabetaste schickt das Formular ab — und trifft den ERSTEN
   Knopf.** Stand „Abbrechen“ vorn, warf Return die gerade getippte Eingabe
   weg. Deshalb steht „Sichern“ jetzt zuerst im Markup und wird nur per
   `order` im Stil nach rechts gesetzt; zusätzlich hört das Fenster auf
   `keydown` (Return = sichern, Esc = abbrechen).

14. **Der Rückgabewert von `uxpShowModal()` taugt nicht als Entscheidung.**
   Schließt das Fenster über das abgeschickte Formular
   (`<button type="submit">` in `<form method="dialog">`), kommt aus dem
   Aufruf nicht zuverlässig der Wert des gedrückten Knopfes zurück — die
   Abfrage `if (ergebnis === "sichern")` lief dann ins Leere und die
   Einstellungen wurden stillschweigend verworfen. Der Klick merkt sich die
   Absicht deshalb selbst in einer Variablen.

15. **Absolute Seitenangaben.** `"+7"` meint die siebte Seite des Dokuments,
   unabhängig von Abschnitten und Nummerierung. Damit stimmt der Export auch
   in Dokumenten mit römischen Seitenzahlen.

16. **`spread.guides` enthält auch die Seitenlinien.** Wer die Hilfslinien
   einer Seite über `page.guides` UND `page.parent.guides` einsammelt,
   bekommt jede Linie doppelt (so stand im Hilfslinien-Fenster zuerst
   „10 10 20 20“). Deshalb über die `id` ausfiltern — und dabei die
   Seitenlinien der Nachbarseiten aussortieren, die in der
   Druckbogen-Sammlung ebenfalls stecken (sonst löscht „aktuelle Seite“
   auf Doppelseiten auch die Linien nebenan).

17. **Der Wirt deckelt die Dialoghöhe und schneidet kommentarlos ab** —
   beim ersten Hilfslinien-Fenster fehlten unten schlicht die Knöpfe
   Anlegen/Abbrechen; und auf „das Fenster wächst schon mit dem Inhalt“
   ist auch kein Verlass: er baute es rund 30 px zu kurz (die Titelleiste
   geht vom Inhalt ab). Verlässlich sind nur zwei Dinge — eine
   AUSDRÜCKLICH angeforderte Höhe wird exakt umgesetzt (Baulehre 8), und
   messen lässt sich die natürliche Höhe an einem KLON des Fensters
   (unsichtbar angehängt, gemessen, entfernt). ALLE Fenster (Hilfslinien,
   Zoomstufen, Export einstellen) messen sich deshalb vor jedem Öffnen
   selbst (`dialogHoeheMessen`) und fordern die gemessene Höhe samt
   Zuschlag an; dazu der Rumpf als Block mit Höhendeckel (`max-height` +
   `overflow-y: auto`) zwischen Titel und Fuß, Roll-Hinweise dran — der
   Fuß bleibt so in jedem Fall sichtbar. **Achtung:** das ECHTE
   Dialog-Element vor `uxpShowModal()` nie per `show()`/`close()`
   anfassen — danach wirft das Öffnen einen `InvalidStateError`
   (live passiert); genau deshalb wird am Klon gemessen.

18. **UXP kennt auf Knöpfen kein `text-overflow`** — bei zentriertem Text
   wird Übermaß an BEIDEN Seiten stumm abgeschnitten: aus „Newspaper“
   wurde „ewspap“, ohne jedes Anzeichen einer Kürzung. Und
   **`scrollWidth` meldet dabei keinen Überlauf** (live nachgesehen:
   scrollWidth = clientWidth trotz abgeschnittenem Text) — als Prüfung
   unbrauchbar. Ansicht- und Export-Bedienfeld messen die Textbreite
   deshalb selbst mit einem unsichtbaren Mess-Span und kürzen
   (`knoepfeKuerzen`): echtes „…“ am Ende, voller Text als Tooltip, bei
   mehr Platz kommt der Volltext von allein zurück. Läuft nach jedem
   Knopfbau und huckepack auf `wandMasseSetzen`, aber nur wenn sich die
   Panelbreite geändert hat.

19. **Ein Select in einem geschlossenen Dialog nimmt `.value` nur intern
   an** — die Anzeige bleibt auf der ersten Option stehen. Live so
   passiert: das Hilfslinien-Fenster rechnete den Bestand „in px“ (das
   Dokument stand auf Pixel, die Vorbelegung hatte intern gegriffen),
   sichtbar stand aber „Millimeter“. Selects deshalb über den
   Optionsindex setzen und lesen (`auswahlSetzen`/`auswahlWert`,
   `selectedIndex` statt `value`) und die Vorbelegung kurz nach dem
   Aufgehen des Fensters noch einmal nachziehen.

20. **Die Bedienfeldgröße kommt aus dem Manifest, nicht aus dem Gedächtnis.**
   InDesign merkt sich die Maße zwar — sie stehen als
   `preferred-unconstrained-size` in
   `~/Library/Preferences/Adobe InDesign/Version 21.0/de_DE/Workspaces/
   <Arbeitsbereich>_CurrentWorkspace.xml`, nachgesehen am 2026-09-03:
   Ansicht 250×347, Export 250×220, Prüfung 250×470 (also nie gesichert).
   Beim Öffnen setzt der Wirt aber `preferredDockedSize` aus dem Manifest
   durch — standen dort 208×264 bzw. 236×132, kam das Bedienfeld jedes Mal
   zu schmal und zu kurz hoch und musste von Hand gezogen werden. Deshalb
   gilt: **`preferredDockedSize` = das Maß, das man wirklich benutzt**, und
   **`minimumSize` = die Höhe, die der Inhalt braucht** — nur das Mindestmaß
   setzt der Wirt hart durch, unter ihm kann er das Feld im Stapel nicht
   zusammenquetschen. Ein zu knappes `maximumSize` (erst 560 bzw. 500)
   deckelt beim Ziehen — aber ein zu GROSSES ist schlimmer: mit 2000 blies
   InDesign das Export-Feld im schwebenden Stapel auf rund 470 px auf, weil
   ein Bedienfeld die freie Höhe des Docks bis zu seinem Maximum aufsaugt.
   Also **`maximumSize` knapp über die Inhaltshöhe** — dann bleibt das Feld,
   wie es ist, und der Rest des Docks bleibt leer (Unterkante einmal
   hochziehen). Gemessene Inhaltshöhen bei 250 px Breite: Ansicht 258,
   Export 138 (mit acht Knöpfen; UXP bricht eine Zeile früher um als ein
   Browser, real ~166), Prüfung 79 leer. Dazu lädt jedes
   Plugin per `"data": { "loadEvent": "startup" }` beim Programmstart, damit
   das Bedienfeld schon existiert, wenn der Arbeitsbereich wiederhergestellt
   wird. Wirklich fest wird die Anordnung erst mit einem **eigenen
   Arbeitsbereich** (Fenster ▸ Arbeitsbereich ▸ Neuer Arbeitsbereich…) — die
   mitgelieferten („Grundlagen“, „Einstieg“) werden von InDesign
   überschrieben.

21. **`window.innerWidth` und `window.innerHeight` sind in InDesigns UXP
   `undefined`.** Steht schwarz auf weiß in der eigenen Messdatei
   (`fenster-mass.txt`: „Fenster innen undefinedxundefined“), während
   `element.clientWidth` daneben saubere 976 lieferte. Wer die
   Bedienfeldbreite braucht, misst am Element — und zwar über
   `getBoundingClientRect()` mit `offsetWidth`/`clientWidth` als Rückfall
   (`elementBreite`).

22. **Ein `visibility: hidden`-Knoten lässt sich nicht mehr messen.** Das
   Mess-Span aus Baulehre 18 hing unsichtbar an der Seite — und gab
   offenbar 0 zurück. Damit galt jeder Text als kurz genug, die Kürzung
   sprang nie an, und „Newspaper“ stand weiter als „ewspap“ auf dem Knopf.
   Jetzt aus dem Bild geschoben und `opacity: 0` statt versteckt, dazu eine
   Schätzung (0,55 em je Zeichen) als letzter Rückfall — lieber grob
   gekürzt als gar nicht. Was der Wirt beim Messen wirklich meldet,
   schreibt das Export-Feld beim Start nach `mess-knoepfe.txt` in seinen
   Datenordner, samt `background-color` und `border-radius` jedes Knopfes.

23. **Für Flex-Kinder gibt der Wirt gar keine Breite heraus — alles 0.**
   Gemessen im laufenden Bedienfeld (`mess-knoepfe.txt`): `wandInhalt`
   0 px, jeder Knopf 0 px, über `getBoundingClientRect()` **und**
   `clientWidth`. **Höhen** liefert er dagegen (`clientHeight`,
   `scrollHeight` — daran hängen die Roll-Hinweise), und ein absolut
   gesetztes, auf den Inhalt geschrumpftes Mess-Span liefert eine echte
   Textbreite („Newspaper“ = 54 px bei 11 px). Damit ist **Kürzen
   grundsätzlich unmöglich** — ohne verfügbare Breite gibt es nichts zu
   vergleichen, und `knopfTextKuerzen` stieg bei `0 - 10 < 12` jedes Mal
   sofort aus (deshalb stand „ewspap“ trotz Baulehre 18 immer noch da).
   Der Weg ist der umgekehrte: die gemessene **Textbreite als
   `flex-basis` und `min-width` auf den Knopf** schreiben, nur nach oben
   (`knopfBreiteSichern`) — dann bricht die Leiste eine Zeile mehr um,
   statt Aufschriften abzuschneiden. Nebenbei: `element.dataset` blieb im
   Bedienfeld leer, und `window.innerWidth/innerHeight` sind `undefined`
   (Baulehre 21) — als Maßquelle taugt im Bedienfeld nur die Höhe.

24. **Die berechnete Formatvorlage stimmt, die Pixel nicht.**
   `getComputedStyle` meldet für jeden Knopf brav `background-color
   #545454` und `border-radius 4px` — gezeichnet wird trotzdem eine
   hohle Pille mit UXP-eigener Form. Auch `.knopf.stark` (Prüfen) bleibt
   ungefüllt und zeigt nur einen blauen Ring. Der Wirt malt `<button>`
   also selbst und nimmt aus dem Stil nur Rand**farbe** und
   Rand**art** (die gestrichelten Zoomstufen kommen an). Wer Fläche und
   Ecken wirklich bestimmen will, darf kein `<button>` benutzen.
   Nebenwirkung fürs Maß: UXP zeichnet Knöpfe rund **32 px** hoch statt
   der 24 aus dem CSS (Segmente 28 statt 20) — wer die Bedienfeldhöhe
   aus dem Stylesheet hochrechnet, liegt je Reihe 8 px daneben.

25. **Schwebend schrumpft, angedockt bläht.** Am Arbeitsbereich abgelesen
   (`Grundlagen_CurrentWorkspace.xml`, 2026-09-03 23:35): das schwebende
   Prüfung-Feld stand auf `250 161`, obwohl das Manifest 260 anforderte — es
   hat sich auf seinen Inhalt gesetzt. Export und Ansicht standen dagegen
   exakt auf ihrem `maximumSize` (235 bzw. 365) und rollten. **Ein
   schwebendes Bedienfeld richtet sich nach dem Inhalt, ein angedocktes
   füllt die Docksäule bis `maximumSize`.** Daraus folgt: der Deckel ist
   NUR die Notbremse fürs Andocken und darf großzügig sein (600) — ein zu
   knapper Deckel erzeugt Rollbalken, ein zu weiter nur im Dock Grauraum.
   Genau andersherum, als es Baulehre 20 zuerst nahelegte.

26. **Inhaltsbreite kann nicht abschneiden.** Der einzige Knopf, der in
   allen Bildschirmfotos NIE beschnitten war, ist „Verpacken“ — und der
   einzige mit `flex: 0 0 auto` (`.knopf.klein`). Wo eine feste Grundbreite
   steht (`flex: 1 1 44px`), schneidet UXP zentrierten Text beidseitig ab,
   und messen lässt es sich nicht (Baulehre 23). Frei benannte Knöpfe
   deshalb grundsätzlich auf `flex: 0 0 auto` — dann bestimmt die
   Aufschrift die Breite, und passt einer nicht mehr in die Zeile, bricht
   er um. Kein `flex-shrink`, sonst quetscht die Zeile ihn doch wieder.
   Das Nachrechnen der Textbreite (`knopfBreiteSichern`) bleibt nur noch
   für Knöpfe mit fester Grundbreite und fasst `auto` nicht an.

27. **`dialogHoeheMessen` maß am versteckten Klon — also 0.** Der Klon aus
   Baulehre 17 hing mit `visibility: hidden` an der Seite, und so versteckt
   gibt der Wirt keine Maße heraus (Baulehre 22). `gemessen` war deshalb
   immer 0, der Rückfallwert 540 griff, und den fordert der Dialog als
   MINDESThöhe an (Baulehre 8) — daher stand unter „Anlegen“ ein
   handbreiter grauer Streifen. Klon jetzt `opacity: 0` statt versteckt,
   in Ansicht und Export.

28. **Ein DOM-Schreibzugriff je Tastendruck kostet die nächste Taste.**
   Im Hilfslinien-Fenster ließ sich nichts über zwei Zeichen eintippen —
   der dritte Tastendruck kam gar nicht mehr an. Kein `maxlength` im
   Markup, keine Obergrenze in `masseZerlegen`; der Lauscher schrieb aber
   bei JEDEM `input` in den Baum: `classList.toggle("ungueltig", …)`
   schreibt auch dann, wenn der Zustand schon stimmt, und die
   Meldungszeile wurde jedes Mal neu auf `""` gesetzt. Beides jetzt nur
   noch bei echter Änderung — ebenso in `wertPruefen` (Zoomfeld und
   Zoomstufen). Wer im Bedienfeld auf `input` lauscht, prüft vorher, ob
   sich überhaupt etwas ändert.

29. **Die echten Inhaltshöhen — endlich gemessen, nicht geschätzt.** Die
   Messung, die auf Sichtbarkeit wartet (`messenWennBereit`), lieferte am
   2026-09-05 bei 250 px Breite: **Ansicht 334 · Export 210 (acht Knöpfe)
   · Prüfung 130 (leere Liste)**. Alle Rechnungen aus dem Stylesheet und
   alle Ablesungen aus Bildschirmfotos lagen daneben — UXP zeichnet
   Knöpfe und Zeilenabstände anders als das CSS sagt. Regel daraus:
   Ansicht und Export **gedeckelt** (`preferredDockedSize` = `maximumSize`
   = Inhalt + 6 px), dann saugen sie angedockt keine Säulenhöhe mehr auf
   und sind schwebend genau so groß wie ihr Inhalt. **`minimumSize` aber
   KLEIN lassen (120):** mit `minimumSize` = `maximumSize` waren die Felder
   starr, und beim Start klappte InDesign zwei von dreien ein — beim
   Wiederherstellen des Arbeitsbereichs ist die Docksäule kurz zu niedrig,
   ein flexibles Feld wird dann vorübergehend gestaucht, ein starres
   eingeklappt und so gelassen (live gesehen, 2026-09-05 21:47).
   Prüfung war zunächst dehnbar (max 600) — als unterstes Feld schluckte es
   dann aber die ganze freie Höhe der Gruppe und sah bei leerer Liste nach
   Loch aus. Seit 1.0.7 ebenfalls **fest (228)**: 130 Inhalt + 92 px
   Listenbereich für vier Funde (`.fundListe { min-height }`), leer mit
   Platzhalter im gestrichelten Rahmen, damit die Fläche als Liste lesbar
   ist. Mehr als vier Funde rollen die Wand (Roll-Hinweise).
   Wer im Export mehr Knöpfe anlegt oder in der Ansicht mehr Zoomstufen,
   hebt die Zahl im Manifest um 28 px je zusätzliche Reihe an; die
   Messdateien `mess-hoehe.txt` im PluginData-Ordner nennen den Bedarf.
   Nebenbefund: das Mess-Span (`textBreite`) meldet für JEDEN Text 60 px —
   die Textmessung ist unbrauchbar, was seit Baulehre 26 (Inhaltsbreite)
   aber nichts mehr kostet: `knopfBreiteSichern` läuft damit ins Leere.

30. **Die Bedienfeldknöpfe sind keine `<button>` mehr.** Baulehre 24 hatte
   es belegt: der Wirt malt `<button>` selbst — Füllung, Ecken und Höhe aus
   dem CSS kommen nie an, nur Randfarbe und Randart. Daraus wurden vier
   Ringsorten für drei Zustände (weiß, blau „aktiv“, gestrichelt „frei“,
   blauer Fokus-Schein), und der gefüllte Prüfen-Knopf war ein blauer Ring.
   Seit 1.4.0 sind alle Knöpfe IM BEDIENFELD `<div role="button"
   tabindex="0">` — ein DIV malt der Wirt nach CSS (die „▼ mehr“-Balken
   bewiesen es). Was dafür nachgebaut werden musste: **gesperrt** ist das
   Attribut `disabled` (`knopfGesperrt`), damit `.knopf[disabled]` greift;
   ein **Wächter in der Fangphase** an `#wandInhalt` lässt Klicks auf
   Gesperrte nicht ankommen; **Enter/Leertaste** lösen per `dispatchEvent`
   aus; `.knopf` rechnet `box-sizing: border-box` mit `line-height` 22
   (Segmente 18), weil das DIV den Rand sonst außen anlegt; der
   `:focus`-Ring ist gestrichen, weil ein DIV nach dem Mausklick sonst blau
   dastand wie „aktiv“. Die Knöpfe in den DIALOGEN bleiben `<button>` —
   dort hängen Formular-Absenden und Eingabetaste dran (Baulehre 13/14).

31. **Auch die Dialogknöpfe sind DIVs — bis auf die, die das Fenster
   schließen.** Sichern/Abbrechen/Anlegen sind `<button type="submit">` in
   `<form method="dialog">`, und NUR das native Absenden schließt ein
   `uxpShowModal`-Fenster verlässlich (Baulehre 11 — `close()` aus dem
   Skript hat InDesign schon eingefroren). Sie bleiben deshalb echte
   Knöpfe, liegen aber **unsichtbar (`opacity: 0`, absolut, volle Größe)
   über einer DIV-Fläche** in einer `.huelle`: der Wirt behält sein
   Formular samt „Eingabetaste trifft den ersten Knopf“ (Baulehre 13), das
   Auge bekommt das CSS. Die `order`-Regeln der Fußzeile zielen auf die
   Hülle (`.h-<id>`), nicht mehr auf den Knopf. Rückfall, falls der Wirt
   die absolute Lage ignoriert: die Fläche reicht ihren Klick per
   `dispatchEvent` an den echten Knopf weiter **und schickt das Formular
   danach per `requestSubmit` nativ ab** — die Klick-Handler allein (Wunsch
   merken + `close()`) wären der Einfrier-Pfad aus Baulehre 11; kennt der
   Wirt kein `requestSubmit`, tut der Rückfall gar nichts. Enter auf dem
   fokussierten Abbrechen-Knopf heißt abbrechen (nicht sichern, und im
   Hilfslinien-Fenster nicht Eingabeprüfung). Gesperrte DIV-Knöpfe bekommen
   `tabindex -1`, Enter/Leertaste auf ihnen wird geschluckt. Einzelne
   Knöpfe außerhalb einer Leiste stehen in einer `.knopfZeile` (Flex),
   sonst macht `display: block` sie zu Vollbreiten-Balken. Fokus-Ring per
   Klasse `.fokus`, nur nach Tab. Alle anderen Dialogknöpfe
   (Zurücksetzen, + Stufe, + Knopf, Wählen…, In die Felder übernehmen,
   die kleinen ↑↓✕ aus den Fabriken) sind DIVs wie im Bedienfeld; der
   Wächter hängt jetzt an Bedienfeld UND Dialogen — in der Fangphase und
   mit `stopPropagation`, sonst zählte Enter auf einem DIV-Knopf zugleich
   als „Eingabetaste = sichern“ des Fensters.

32. **`doc.filePath` und `doc.fullName` sind im UXP-DOM Promises.** Live
   gemessen (2026-09-05): `typeof doc.filePath` = object,
   `String(doc.filePath)` = „[object Promise]“; aufgelöst kommt ein echter
   UXP-Ordnereintrag (`isFolder`, `nativePath`, `url`, sogar `createFolder`).
   `name`, `saved`, `modified` sind dagegen gewöhnliche Werte. Wer an der
   Promise `nativePath` liest, bekommt undefined und hält das Dokument für
   ortlos — genau so brach „Verpacken“ mit „Der Ordner des Dokuments ließ
   sich nicht öffnen“ ab, und der Export nach „Ordner des Dokuments“ fiel
   STILL auf den Ordner-Auswahldialog zurück. `dokumentOrdnerPfad` ist
   deshalb async und wartet die Promise ab. Messen ohne Klick: ein `.idjs`
   per `app.doScript(File, ScriptLanguage.UXPSCRIPT)` aus ExtendScript
   starten — es läuft aber erst NACH dem aufrufenden ExtendScript, also
   Ergebnis in ein Dokument-Label schreiben (`doc.insertLabel`, nicht
   `app.insertLabel` — das kam nicht durch) und in einem ZWEITEN Aufruf
   auslesen; und `await` nur auf oberster Ebene, eine asynchrone
   Fortsetzung nach dem synchronen Skriptende läuft nicht mehr.

33. **`packageForPrint` hat 14 Parameter, und UXP prüft jeden streng.** Der
   12. ist `useDocumentHyphenationExceptionsOnly` (Boolean) — dort stand
   der Versionskommentar `""`: „Ungültiger Wert für Parameter …, Boolean
   erwartet, aber "" erhalten“. ExtendScript hätte das stillschweigend
   umgedeutet, das UXP-DOM wirft. Reihenfolge: to, copyingFonts,
   copyingLinkedGraphics, copyingProfiles, updatingGraphics,
   includingHiddenLayers, ignorePreflightErrors, creatingReport,
   includeIdml, includePdf, pdfStyle, useDocumentHyphenationExceptionsOnly,
   versionComments, forceSave. Der Zielordner darf als Pfad-String kommen.

---

## Aufbau

```
Bedienfelder/
├── installieren.command    Einrichten und Entfernen
├── ansicht/
│   ├── manifest.json       Bedienfeld, Größe, Rechte
│   ├── index.html          Knöpfe + Fenster „Eigene Zoomstufen“ und „Hilfslinien“
│   ├── stil.css
│   └── index.js            Zoomlogik, eigene Stufen, Hilfslinien, Selbsttest
├── export/
│   ├── manifest.json
│   ├── index.html          Knöpfe + Fenster „Export einstellen“
│   ├── stil.css
│   └── index.js            Exportlogik, Verpacken, Einstellungen, Selbsttest
└── pruefung/
    ├── manifest.json
    ├── index.html          Prüfen-Knopf, Schwellen, Fundliste
    ├── stil.css
    └── index.js            die sechs Prüfungen, Sprung zum Fund, Selbsttest
```

Alle Plugins brauchen InDesign 18.5 oder neuer (davor gab es keine
UXP-Bedienfelder). Für ältere Fassungen liegt in `../Zoom-Export/`
eine ScriptUI-Palette mit Zoom und Export.
