// ============================================================================
// Ansicht dwb — UXP-Bedienfeld für Adobe InDesign                Version 1.3
// ----------------------------------------------------------------------------
// Zoomknöpfe: Seite, Originalgröße, Auswahl, Montagefläche und eigene
// Stufen, die man selbst festlegt (Alt-Klick oder Rechtsklick auf den
// Knopf, oder Bedienfeldmenü ▸ Zoomstufen festlegen…). Die Werte liegen
// im Datenordner des Plugins. Dazu eine Zoomleiste (Minus, Eingabefeld,
// Plus, Zurück), Umschalter für Bildschirmmodus und Anzeigeleistung und
// der Knopf „Hilfslinien …“: Hilfslinien an genau eingetippten Positionen,
// horizontal wie vertikal, mehrere auf einmal — das Fenster zeigt beim
// Öffnen zuerst den Bestand der Seite (aktive Ebene) und kann ihn in die
// Felder übernehmen.
//
// Ein Taktgeber schaut jede Sekunde nach, solange das Bedienfeld sichtbar
// ist (UXP liefert kein Zoom-Ereignis): Zoomwert und Seite stehen live in
// der Statuszeile, die aktive Stufe und die aktiven Modi sind markiert,
// ohne Dokument sind die Knöpfe ausgegraut.
//
// „Auswahl einpassen“ gibt es im Skriptmodell nicht (ZoomOptions kennt nur
// Seite, Druckbogen, Originalgröße und Montagefläche) — dafür wird der
// Menübefehl mit der festen ID 118790 aufgerufen; die ist in allen Sprachen
// gleich.
// © 2026 dwbkd · www.dwbkd.de
// ============================================================================

const MENUE_AUSWAHL = 118790;
const EINSTELLUNGSDATEI = "einstellungen.json";
const BEFEHL_IMPORT = "Importoptionen ändern …";

let statusFeld = null;
let stufen = [{ name: "", wert: 50 }, { name: "", wert: 200 }];
let stufenEntwurf = [];
let statusHaltBis = 0;      // solange bleibt eine Klick- oder Fehlermeldung stehen
let zoomMerker = null;      // Prozentwert vor der letzten Zoomänderung aus dem Panel
let taktUhr = null;         // Taktgeber der Live-Anzeige

function statusSchreiben(text, fehler) {
    if (!statusFeld) statusFeld = document.getElementById("status");
    if (!statusFeld) return;
    statusFeld.textContent = String(text);
    statusFeld.setAttribute("title", String(text));
    statusFeld.classList.toggle("fehler", !!fehler);
}

// Eine Meldung nach einem Klick hält ein paar Sekunden — danach übernimmt
// wieder die Live-Anzeige aus dem Taktgeber.
function status(text) {
    statusHaltBis = Date.now() + 4000;
    statusSchreiben(text, false);
}

// Misserfolge heben sich farblich ab und bleiben etwas länger stehen.
function statusFehler(text) {
    statusHaltBis = Date.now() + 6000;
    statusSchreiben(text, true);
}

// Die Live-Anzeige schreibt nur, wenn gerade keine Meldung gilt.
function statusLive(text) {
    if (Date.now() < statusHaltBis) return;
    statusSchreiben(text, false);
}

function indesign() {
    return require("indesign");
}

// Läuft gerade ein Layoutfenster? Ein Textmodus-Fenster kennt kein
// zoomPercentage — der Zugriff wirft dann, und genau das ist die Prüfung.
function layoutFenster() {
    try {
        const { app } = indesign();
        if (!app.documents.length) return null;
        const fenster = app.activeWindow;
        if (typeof fenster.zoomPercentage !== "number") return null;
        return fenster;
    } catch (e) {
        return null;
    }
}

function prozent(fenster) {
    try { return Math.round(fenster.zoomPercentage) + " %"; } catch (e) { return ""; }
}

// Für den Zurück-Knopf: den Stand VOR der Änderung aufheben. Nur der
// Prozentwert — die Scrollposition ist per Skript ohnehin nicht erreichbar.
function zoomMerken(fenster) {
    try { zoomMerker = Math.round(fenster.zoomPercentage * 10) / 10; } catch (e) { /* dann eben nicht */ }
}

function zoomen(art, meldung) {
    const fenster = layoutFenster();
    if (!fenster) { status("Kein Dokumentfenster offen."); return; }
    try {
        zoomMerken(fenster);
        fenster.zoom(art);
        status(meldung + " · " + prozent(fenster));
    } catch (e) {
        statusFehler("Zoom ging nicht: " + e);
    }
}

// Stellt den Prozentwert von vor der letzten Panel-Zoomänderung wieder her;
// ein zweiter Druck wechselt wieder vor — die beiden Stände tauschen.
function zoomZurueck() {
    const fenster = layoutFenster();
    if (!fenster) { status("Kein Dokumentfenster offen."); return; }
    if (zoomMerker === null) { status("Noch keine vorige Zoomstufe."); return; }
    try {
        const jetzt = Math.round(fenster.zoomPercentage * 10) / 10;
        fenster.zoomPercentage = zoomMerker;
        status("Zurück auf " + alsText(zoomMerker) + " %");
        zoomMerker = jetzt;
    } catch (e) {
        statusFehler("Zoom ging nicht: " + e);
    }
}

// Die Plus/Minus-Knöpfe: eine InDesign-Zoomstufe vor oder zurück.
function zoomSchritt(richtung) {
    const fenster = layoutFenster();
    if (!fenster) { status("Kein Dokumentfenster offen."); return; }
    try {
        const Z = indesign().ZoomOptions;
        zoomMerken(fenster);
        fenster.zoom(richtung > 0 ? Z.ZOOM_IN : Z.ZOOM_OUT);
        status(prozent(fenster));
    } catch (e) {
        statusFehler("Zoom ging nicht: " + e);
    }
}

// Das Eingabefeld in der Zoomleiste: Wert tippen, Eingabetaste — mit
// demselben Komfort wie die freien Knöpfe (bei einer Auswahl erst dorthin).
function zoomFeldAnwenden() {
    const feld = document.getElementById("zoomFeld");
    if (!feld) return;
    const n = parseFloat(String(feld.value).replace(",", "."));
    if (isNaN(n)) { statusFehler("Zoomwert nicht verstanden: " + feld.value); return; }
    const wert = Math.max(5, Math.min(4000, Math.round(n * 10) / 10));
    const fenster = layoutFenster();
    if (!fenster) { status("Kein Dokumentfenster offen."); return; }
    zoomMerken(fenster);
    if (auswahlDa() && auswahlEinpassen(true)) {
        try { fenster.zoomPercentage = wert; } catch (e) {}
        feld.value = alsText(wert);
        wertPruefen(feld);
        status("Auswahl bei " + alsText(wert) + " %");
        return;
    }
    try {
        fenster.zoomPercentage = wert;
        feld.value = alsText(wert);
        wertPruefen(feld);
        status(alsText(wert) + " %");
    } catch (e) {
        statusFehler("Zoom ging nicht: " + e);
    }
}

// Pfeil hoch/runter in einem Zoomfeld: 5er-Schritte, mit Umschalttaste 25 —
// wie man es aus InDesign-Feldern kennt.
function wertSchritt(feld, richtung, gross) {
    const n = parseFloat(String(feld.value).replace(",", "."));
    const basis = isNaN(n) ? 100 : n;
    const schritt = gross ? 25 : 5;
    const neu = Math.max(5, Math.min(4000, Math.round((basis + richtung * schritt) * 10) / 10));
    feld.value = alsText(neu);
    wertPruefen(feld);
}

// Sofort zeigen, ob der Wert taugt (Zahl, 5 bis 4000) — roter Rand statt
// stillschweigendem Rückfall erst beim Sichern.
function wertPruefen(feld) {
    const n = parseFloat(String(feld.value).replace(",", "."));
    const gut = !isNaN(n) && n >= 5 && n <= 4000;
    // Nur bei echter Änderung schreiben — siehe hilfsFeldPruefen: ein
    // DOM-Schreibzugriff je Tastendruck kostet im UXP-Wirt die nächste Taste.
    if (feld.classList.contains("ungueltig") === !!gut) {
        feld.classList.toggle("ungueltig", !gut);
    }
    return gut;
}

function auswahlDa() {
    try {
        const { app } = indesign();
        return app.selection && app.selection.length > 0;
    } catch (e) {
        return false;
    }
}

// Der Menübefehl meldet sich als deaktiviert, solange das Bedienfeld den
// Tastaturfokus hat. Das Dokumentfenster nach vorn zu holen reicht.
function auswahlEinpassen(leise) {
    const fenster = layoutFenster();
    if (!fenster) { if (!leise) status("Kein Dokumentfenster offen."); return false; }
    if (!auswahlDa()) { if (!leise) status("Nichts ausgewählt."); return false; }
    try {
        const { app } = indesign();
        const befehl = app.menuActions.itemByID(MENUE_AUSWAHL);
        if (!befehl.isValid) { if (!leise) statusFehler("Befehl „Auswahl einpassen“ nicht gefunden."); return false; }
        if (!leise) zoomMerken(fenster);
        if (!befehl.enabled) { try { fenster.bringToFront(); } catch (e) {} }
        befehl.invoke();
        if (!leise) status("Auswahl eingepasst · " + prozent(fenster));
        return true;
    } catch (e) {
        if (!leise) statusFehler("Auswahl ließ sich nicht einpassen.");
        return false;
    }
}

function originalgroesse() {
    const fenster = layoutFenster();
    if (!fenster) { status("Kein Dokumentfenster offen."); return; }
    zoomMerken(fenster);
    if (auswahlDa() && auswahlEinpassen(true)) {
        try { fenster.zoomPercentage = 100; } catch (e) {}
        status("Auswahl in Originalgröße · 100 %");
        return;
    }
    zoomen(indesign().ZoomOptions.ACTUAL_SIZE, "Originalgröße");
}

// ------------------------------------------------------------ Importoptionen
// Öffnet „Importoptionen.jsx“ — das Script, das Seite, Beschnitt und Ebenen
// einer bereits platzierten Datei nachträglich ändert. Es ist ExtendScript und
// lebt außerhalb dieses Bedienfelds; aufgerufen wird es über den Menübefehl,
// den „Menue-Startup.jsx“ beim Programmstart anlegt. Fehlt der, wird die Datei
// im Skriptbedienfeld direkt gestartet.

function importbefehlFinden() {
    const { app } = indesign();
    try {
        const genau = app.scriptMenuActions.itemByName(BEFEHL_IMPORT);
        if (genau.isValid) return genau;
    } catch (e) { /* weiter suchen */ }
    // Nachsichtig, falls die Beschriftung im Startup-Script geändert wurde.
    try {
        for (let i = 0; i < app.scriptMenuActions.length; i++) {
            const a = app.scriptMenuActions.item(i);
            if (/Importoptionen/i.test(a.name)) return a;
        }
    } catch (e) { /* dann eben nicht */ }
    return null;
}

function importoptionen() {
    const befehl = importbefehlFinden();
    if (befehl) {
        try {
            befehl.invoke();
            status("Importoptionen geöffnet.");
            return;
        } catch (e) { /* zweiter Weg */ }
    }
    try {
        const { app, ScriptLanguage } = indesign();
        const pfad = String(app.scriptPreferences.scriptsFolder) + "/Scripts Panel/Importoptionen.jsx";
        app.doScript("app.doScript(File(" + JSON.stringify(pfad) + "), ScriptLanguage.javascript)",
                     ScriptLanguage.JAVASCRIPT);
        status("Importoptionen über das Skriptbedienfeld gestartet.");
    } catch (e) {
        statusFehler("Importoptionen.jsx nicht gefunden — Menue-Startup.jsx einrichten.");
    }
}

// ---------------------------------------------------------------- Hilfslinien
// Hilfslinien an genau eingetippten Positionen: horizontal (von der Oberkante
// der Seite) und vertikal (von der linken Kante), mehrere Werte auf einmal,
// wahlweise für die aktuelle oder alle Seiten. Gerechnet wird intern in Punkt;
// dafür stellt die Funktion Maßeinheit, Linealursprung und Nullpunkt kurz um
// und in einem finally wieder zurück — die eingetippten Werte gelten so immer
// ab der Seitenkante, egal wie das Lineal gerade steht.

const EINHEIT_IN_PUNKT = { mm: 72 / 25.4, cm: 720 / 25.4, pt: 1, in: 72, zoll: 72, px: 1 };

let hilfsOffen = false;
// Wie beim Zoomstufen-Fenster: der Rückgabewert von uxpShowModal() ist nicht
// verlässlich, der Klick merkt sich die Absicht selbst.
let hilfsWunsch = "abbruch";
// Die letzten Eingaben bleiben fürs nächste Öffnen stehen — wer dasselbe
// Raster mehrmals braucht, tippt es nur einmal.
const hilfsMerker = { h: "", v: "", einheit: "", bereich: "seite", druckbogen: false, loeschen: false };

// Zerlegt „10  148,5  12mm; 3cm“ in Punktwerte. Getrennt wird an Leerzeichen
// und Semikolons; ein Komma zwischen Ziffern ist das Dezimalkomma, ein Komma
// am Ende („10, 20“) nur ein Trenner. „12 mm“ wird vorab zu „12mm“ verklebt,
// damit die Einheit nicht als eigener Brocken übrig bleibt.
function masseZerlegen(text, vorgabeEinheit) {
    const werte = [], schlechte = [];
    String(text || "")
        .replace(/(\d)\s+(mm|cm|pt|in|zoll|px)\b/gi, "$1$2")
        .split(/[;\s]+/)
        .forEach(roh => {
            const token = roh.replace(/,+$/, "");
            if (!token) return;
            const treffer = /^([+-]?\d+(?:[.,]\d+)?)(mm|cm|pt|in|zoll|px)?$/i.exec(token);
            if (!treffer) { schlechte.push(roh); return; }
            const zahl = parseFloat(treffer[1].replace(",", "."));
            const einheit = (treffer[2] || vorgabeEinheit || "mm").toLowerCase();
            werte.push(zahl * (EINHEIT_IN_PUNKT[einheit] || EINHEIT_IN_PUNKT.mm));
        });
    return { werte: werte, schlechte: schlechte };
}

function hilfsFeldPruefen(feld) {
    const einheitFeld = document.getElementById("hilfsEinheit");
    const ergebnis = masseZerlegen(feld.value, auswahlWert(einheitFeld, "mm"));
    // NUR schreiben, wenn sich wirklich etwas ändert. Ein DOM-Schreibzugriff
    // bei JEDEM Tastendruck ist im UXP-Wirt nicht harmlos: er baut das Feld
    // neu auf und verschluckt dabei die folgende Taste — die Eingabe kam über
    // zwei Zeichen nicht hinaus. classList.toggle schreibt auch dann, wenn der
    // Zustand schon stimmt.
    const schlecht = ergebnis.schlechte.length > 0;
    if (feld.classList.contains("ungueltig") !== schlecht) {
        feld.classList.toggle("ungueltig", schlecht);
    }
    return ergebnis;
}

// Vor dem Absenden: stimmt in beiden Feldern alles? Schreibt die Meldung ins
// Fenster (die Statuszeile des Bedienfelds ist hinter dem Dialog nicht zu
// sehen) und liefert true bei Fehlern oder komplett leeren Feldern.
function hilfsEingabeSchlecht() {
    const feldH = document.getElementById("hilfsH");
    const feldV = document.getElementById("hilfsV");
    const meldung = document.getElementById("hilfsMeldung");
    const h = feldH ? hilfsFeldPruefen(feldH) : { werte: [], schlechte: [] };
    const v = feldV ? hilfsFeldPruefen(feldV) : { werte: [], schlechte: [] };
    let text = "";
    if (h.schlechte.length || v.schlechte.length)
        text = "Nicht verstanden: " + h.schlechte.concat(v.schlechte).join("  ");
    else if (!h.werte.length && !v.werte.length)
        text = "Mindestens einen Wert eintragen — oder Abbrechen.";
    if (meldung) meldung.textContent = text;
    return !!text;
}

// Die Einheit startet mit der Maßeinheit des Dokuments, sofern sie eine der
// wählbaren ist — danach zählt, was zuletzt gewählt war.
function dokumentEinheit() {
    try {
        const idsn = indesign();
        const wert = idsn.app.activeDocument.viewPreferences.horizontalMeasurementUnits;
        const karte = [["MILLIMETERS", "mm"], ["CENTIMETERS", "cm"], ["POINTS", "pt"],
                       ["INCHES", "in"], ["INCHES_DECIMAL", "in"], ["PIXELS", "px"]];
        for (let i = 0; i < karte.length; i++) {
            if (enumGleich(wert, idsn.MeasurementUnits[karte[i][0]])) return karte[i][1];
        }
    } catch (e) { /* dann Millimeter */ }
    return "mm";
}

// Ein UXP-Select in einem noch GESCHLOSSENEN Dialog nimmt eine
// .value-Zuweisung nur intern an — die Anzeige bleibt auf der ersten
// Option stehen (live: Kopfzeile rechnete „in px“, sichtbar stand
// „Millimeter“). Deshalb wird über den Optionsindex gesetzt und gelesen,
// und die Vorbelegung nach dem Aufgehen noch einmal nachgezogen.
function auswahlSetzen(select, wert) {
    if (!select) return;
    const optionen = select.options || [];
    let index = 0;
    for (let i = 0; i < optionen.length; i++) {
        if (optionen[i] && optionen[i].value === wert) { index = i; break; }
    }
    try { select.selectedIndex = index; } catch (e) {}
    try { select.value = optionen[index] ? optionen[index].value : wert; } catch (e) {}
}
function auswahlWert(select, ersatz) {
    if (!select) return ersatz;
    try {
        const optionen = select.options || [];
        const i = select.selectedIndex;
        if (i >= 0 && optionen[i] && typeof optionen[i].value === "string")
            return optionen[i].value;
    } catch (e) { /* dann über value */ }
    return (typeof select.value === "string" && select.value) ? select.value : ersatz;
}

// Punktwert in der gewählten Einheit anzeigen — auf zwei Stellen gerundet,
// ohne nachlaufende Nullen, mit Dezimalkomma.
function massAlsText(punkte, einheit) {
    const wert = punkte / (EINHEIT_IN_PUNKT[einheit] || EINHEIT_IN_PUNKT.mm);
    return String(Math.round(wert * 100) / 100).replace(".", ",");
}

// Der Bestand beim Öffnen des Fensters: die Hilfslinien der aktiven Seite,
// gemessen ab der Seitenkante, in Punkt. Nur die aktive Ebene — Linien auf
// anderen Ebenen werden gezählt, aber nicht gelistet.
let hilfsBestand = { da: false, h: [], v: [], andere: 0, ebene: "" };

// Liest die vorhandenen Hilfslinien der aktiven Seite (Seiten- UND
// Druckbogenlinien). Gemessen wird über den Druckbogen-Ursprung: EIN
// Nullpunkt für alle Linien des Druckbogens, die Seitenkante wird danach
// über page.bounds abgezogen — mit dem Seiten-Ursprung wäre unklar, auf
// welche Seite sich eine Druckbogenlinie bezieht.
function hilfslinienLesen() {
    const leer = { da: false, h: [], v: [], andere: 0, ebene: "" };
    const idsn = indesign(), app = idsn.app;
    const fenster = layoutFenster();
    if (!fenster) return leer;
    let doc, seite;
    try { doc = app.activeDocument; seite = fenster.activePage; } catch (e) { return leer; }
    const ergebnis = { da: true, h: [], v: [], andere: 0, ebene: "" };
    let aktiveEbene = null;
    try { aktiveEbene = doc.activeLayer.id; ergebnis.ebene = doc.activeLayer.name; } catch (e) {}
    const script = app.scriptPreferences;
    const sicht = doc.viewPreferences;
    const altEinheit = script.measurementUnit;
    script.measurementUnit = idsn.MeasurementUnits.POINTS;
    const altUrsprung = sicht.rulerOrigin;
    let altNull = null;
    try { altNull = doc.zeroPoint; } catch (e) { altNull = null; }
    try {
        sicht.rulerOrigin = idsn.RulerOrigin.SPREAD_ORIGIN;
        try { doc.zeroPoint = [0, 0]; } catch (e) {}
        const grenzen = seite.bounds;               // [oben, links, unten, rechts]
        const HV = idsn.HorizontalOrVertical;
        // Die Druckbogen-Sammlung enthält AUCH die Seitenlinien — ohne
        // id-Abgleich käme jede Linie doppelt (so war es zuerst). Und die
        // Seitenlinien der NACHBARSEITEN gehören gar nicht in die Liste.
        const gesehen = {};
        const verboten = {};
        try {
            const nachbarn = seite.parent.pages;
            for (let i = 0; i < nachbarn.length; i++) {
                const nachbar = nachbarn.item(i);
                if (nachbar.id === seite.id) continue;
                for (let j = 0; j < nachbar.guides.length; j++) {
                    try { verboten[nachbar.guides.item(j).id] = true; } catch (e) {}
                }
            }
        } catch (e) { /* einseitiger Druckbogen */ }
        const sammeln = (linien) => {
            for (let i = 0; i < linien.length; i++) {
                try {
                    const linie = linien.item(i);
                    if (gesehen[linie.id] || verboten[linie.id]) continue;
                    gesehen[linie.id] = true;
                    if (aktiveEbene !== null && linie.itemLayer.id !== aktiveEbene) {
                        ergebnis.andere++;
                        continue;
                    }
                    const senkrecht = enumGleich(linie.orientation, HV.VERTICAL);
                    const wert = Number(linie.location) - (senkrecht ? Number(grenzen[1]) : Number(grenzen[0]));
                    (senkrecht ? ergebnis.v : ergebnis.h).push(wert);
                } catch (e) { /* die Linie dann eben nicht */ }
            }
        };
        try { sammeln(seite.guides); } catch (e) {}
        try { sammeln(seite.parent.guides); } catch (e) {}
        ergebnis.h.sort((a, b) => a - b);
        ergebnis.v.sort((a, b) => a - b);
    } catch (e) {
        /* dann eben ohne Bestand */
    } finally {
        try { sicht.rulerOrigin = altUrsprung; } catch (e) {}
        try { if (altNull) doc.zeroPoint = altNull; } catch (e) {}
        try { script.measurementUnit = altEinheit; } catch (e) {}
    }
    return ergebnis;
}

// Schreibt den Bestand ins Fenster — in der gerade gewählten Einheit; beim
// Einheitenwechsel wird aus den gemerkten Punktwerten neu gerechnet.
function hilfsBestandZeigen() {
    const kopf = document.getElementById("hilfsBestandKopf");
    if (!kopf) return;
    const zeileH = document.getElementById("hilfsBestandH");
    const zeileV = document.getElementById("hilfsBestandV");
    const andere = document.getElementById("hilfsBestandAndere");
    const knopf = document.getElementById("hilfsUebernehmen");
    const einheitFeld = document.getElementById("hilfsEinheit");
    const einheit = auswahlWert(einheitFeld, "mm");
    const zeigen = (element, an) => { if (element) element.style.display = an ? "" : "none"; };
    const b = hilfsBestand;
    if (!b.da) {
        kopf.textContent = "";
        zeigen(kopf, false); zeigen(zeileH, false); zeigen(zeileV, false);
        zeigen(andere, false); zeigen(knopf, false);
        return;
    }
    zeigen(kopf, true);
    const ebenenWort = b.ebene ? " auf der Ebene „" + b.ebene + "“" : "";
    if (!b.h.length && !b.v.length) {
        kopf.textContent = "Auf der Seite liegen" + ebenenWort + " noch keine Hilfslinien.";
        zeigen(zeileH, false); zeigen(zeileV, false); zeigen(knopf, false);
    } else {
        kopf.textContent = "Vorhanden auf der Seite" + ebenenWort + " — in " + einheit + ":";
        if (zeileH) zeileH.textContent = "Horizontal: " +
            (b.h.length ? b.h.map(wert => massAlsText(wert, einheit)).join("  ") : "—");
        if (zeileV) zeileV.textContent = "Vertikal: " +
            (b.v.length ? b.v.map(wert => massAlsText(wert, einheit)).join("  ") : "—");
        zeigen(zeileH, true); zeigen(zeileV, true); zeigen(knopf, true);
    }
    if (andere) andere.textContent = b.andere
        ? "Dazu " + b.andere + " auf anderen Ebenen (bleiben hier außen vor)."
        : "";
    zeigen(andere, !!b.andere);
    // Der Bestand ändert die Rumpfhöhe — die Roll-Hinweise nachziehen.
    rollHinweiseAuffrischen();
}

// Legt die Linien an. Alles zusammen ist EIN Rückgängig-Schritt (app.doScript
// mit UndoModes.ENTIRE_SCRIPT); schlägt dieser Weg fehl, bevor er angefangen
// hat, laufen die Linien direkt — dann eben mit Einzelschritten.
function hilfslinienAnlegen(eingabe) {
    const idsn = indesign(), app = idsn.app;
    const fenster = layoutFenster();
    if (!fenster) { statusFehler("Kein Dokumentfenster offen."); return; }
    let doc, seiten;
    try {
        doc = app.activeDocument;
        seiten = eingabe.alleSeiten ? doc.pages.everyItem().getElements() : [fenster.activePage];
    } catch (e) { statusFehler("Keine Seite gefunden: " + e); return; }

    let angelegt = 0, daneben = 0, entfernt = 0, angefangen = false;
    const arbeit = () => {
        angefangen = true;
        const script = app.scriptPreferences;
        const sicht = doc.viewPreferences;
        const altEinheit = script.measurementUnit;
        script.measurementUnit = idsn.MeasurementUnits.POINTS;
        const altUrsprung = sicht.rulerOrigin;
        let altNull = null;
        // Den Nullpunkt erst NACH dem Umstellen auf Punkt lesen — sonst käme
        // er in Dokumenteinheiten zurück und würde falsch zurückgeschrieben.
        try { altNull = doc.zeroPoint; } catch (e) { altNull = null; }
        try {
            sicht.rulerOrigin = idsn.RulerOrigin.PAGE_ORIGIN;
            try { doc.zeroPoint = [0, 0]; } catch (e) { /* Ursprung reicht meist */ }
            const HV = idsn.HorizontalOrVertical;
            let aktiveEbene = null;
            try { aktiveEbene = doc.activeLayer.id; } catch (e) { aktiveEbene = null; }
            // Nur Linien der aktiven Ebene entfernen — fremde Ebenen bleiben
            // unberührt. Rückwärts, weil die Sammlung beim Entfernen nachrückt.
            const wegDamit = (linien, verboten) => {
                for (let i = linien.length - 1; i >= 0; i--) {
                    try {
                        const linie = linien.item(i);
                        if (verboten && verboten[linie.id]) continue;
                        if (aktiveEbene !== null && linie.itemLayer.id !== aktiveEbene) continue;
                        linie.remove();
                        entfernt++;
                    } catch (e) { /* dann bleibt sie stehen */ }
                }
            };
            seiten.forEach(seite => {
                if (eingabe.loeschen) {
                    // Die Druckbogen-Sammlung enthält auch die Seitenlinien
                    // der Nachbarseiten — bei „aktuelle Seite“ bleiben die
                    // stehen (bei „alle Seiten“ kommen ohnehin alle dran).
                    const verboten = {};
                    if (!eingabe.alleSeiten) {
                        try {
                            const nachbarn = seite.parent.pages;
                            for (let i = 0; i < nachbarn.length; i++) {
                                const nachbar = nachbarn.item(i);
                                if (nachbar.id === seite.id) continue;
                                for (let j = 0; j < nachbar.guides.length; j++) {
                                    try { verboten[nachbar.guides.item(j).id] = true; } catch (e) {}
                                }
                            }
                        } catch (e) { /* einseitiger Druckbogen */ }
                    }
                    try { wegDamit(seite.guides, verboten); } catch (e) {}
                    try { wegDamit(seite.parent.guides, verboten); } catch (e) {}
                }
                const setzen = (ausrichtung, wert) => {
                    const eigenschaften = { orientation: ausrichtung, location: wert, fitToPage: !eingabe.druckbogen };
                    try { seite.guides.add(undefined, eigenschaften); angelegt++; return; } catch (e) {}
                    try { seite.guides.add(doc.activeLayer, eigenschaften); angelegt++; } catch (e) { daneben++; }
                };
                eingabe.h.forEach(wert => setzen(HV.HORIZONTAL, wert));
                eingabe.v.forEach(wert => setzen(HV.VERTICAL, wert));
            });
        } finally {
            try { sicht.rulerOrigin = altUrsprung; } catch (e) {}
            try { if (altNull) doc.zeroPoint = altNull; } catch (e) {}
            try { script.measurementUnit = altEinheit; } catch (e) {}
        }
    };
    try {
        app.doScript(arbeit, idsn.ScriptLanguage.UXPSCRIPT, [],
                     idsn.UndoModes.ENTIRE_SCRIPT, "Hilfslinien anlegen");
    } catch (e) {
        // Lief die Arbeit schon, würde ein zweiter Anlauf alles doppelt
        // anlegen — dann nur noch melden, was übrig blieb.
        if (!angefangen) {
            try { arbeit(); } catch (e2) { statusFehler("Hilfslinien gingen nicht: " + e2); return; }
        } else if (!angelegt) {
            statusFehler("Hilfslinien gingen nicht: " + e);
            return;
        }
    }
    let text = angelegt + (angelegt === 1 ? " Hilfslinie" : " Hilfslinien") + " angelegt";
    if (eingabe.alleSeiten && seiten.length > 1) text += " · " + seiten.length + " Seiten";
    if (entfernt) text += " · " + entfernt + " alte entfernt";
    if (daneben)  text += " · " + daneben + " gingen nicht";
    status(text);
}

async function hilfsFensterOeffnen() {
    if (hilfsOffen) return;
    hilfsOffen = true;
    const fenster = document.getElementById("hilfsFenster");
    try {
        const feldH = document.getElementById("hilfsH");
        const feldV = document.getElementById("hilfsV");
        const einheit = document.getElementById("hilfsEinheit");
        const bereich = document.getElementById("hilfsBereich");
        const druckbogen = document.getElementById("hilfsDruckbogen");
        const loeschen = document.getElementById("hilfsLoeschen");
        const meldung = document.getElementById("hilfsMeldung");
        feldH.value = hilfsMerker.h;
        feldV.value = hilfsMerker.v;
        const sollEinheit = hilfsMerker.einheit || dokumentEinheit();
        auswahlSetzen(einheit, sollEinheit);
        auswahlSetzen(bereich, hilfsMerker.bereich);
        druckbogen.checked = hilfsMerker.druckbogen;
        loeschen.checked = hilfsMerker.loeschen;
        if (meldung) meldung.textContent = "";
        feldH.classList.remove("ungueltig");
        feldV.classList.remove("ungueltig");
        // Erst schauen, was schon da ist — der Bestand steht oben im Fenster.
        hilfsBestand = hilfslinienLesen();
        hilfsBestandZeigen();
        hilfsWunsch = "abbruch";
        // Höhe messen und ausdrücklich anfordern (dialogHoeheMessen) —
        // Rückfall 540, falls das Messen scheitert: lieber etwas Leerraum
        // unten als abgeschnittene Knöpfe.
        const gemessen = dialogHoeheMessen(fenster, 340);
        const wunschHoehe = gemessen > 100 ? Math.min(560, gemessen + 56) : 540;
        // Falls ein früherer Fehler das Fenster halb offen hinterließ:
        // aufräumen, sonst wirft uxpShowModal einen InvalidStateError.
        try { fenster.close(); } catch (e) {}
        try { fenster.removeAttribute("open"); } catch (e) {}
        // Solange der Dialog zu ist, misst der Rumpf 0 und die Selects
        // übernehmen die Vorbelegung nur intern — kurz nach dem Aufgehen
        // beides nachziehen (uxpShowModal kehrt erst beim Schließen zurück,
        // deshalb vorab eingeplant).
        const nachziehen = () => {
            auswahlSetzen(einheit, sollEinheit);
            auswahlSetzen(bereich, hilfsMerker.bereich);
            hilfsBestandZeigen();
            rollHinweiseAuffrischen();
        };
        setTimeout(nachziehen, 150);
        setTimeout(nachziehen, 500);
        let ergebnis;
        if (typeof fenster.uxpShowModal === "function") {
            ergebnis = await fenster.uxpShowModal({
                title: "Ansicht dwb — Hilfslinien",
                resize: "both",
                size: { width: 340, height: wunschHoehe }
            });
        } else {
            ergebnis = await fenster.showModal();
        }
        // Eingaben in jedem Fall aufheben — auch nach Abbruch soll das
        // Getippte beim nächsten Öffnen wieder dastehen.
        tippMitschriftSchreiben();
        hilfsMerker.h = feldH.value;
        hilfsMerker.v = feldV.value;
        hilfsMerker.einheit = auswahlWert(einheit, "mm");
        hilfsMerker.bereich = auswahlWert(bereich, "seite");
        hilfsMerker.druckbogen = !!druckbogen.checked;
        hilfsMerker.loeschen = !!loeschen.checked;
        if (hilfsWunsch === "anlegen" || (hilfsWunsch !== "abbruch!" && ergebnis === "anlegen")) {
            const h = masseZerlegen(feldH.value, hilfsMerker.einheit);
            const v = masseZerlegen(feldV.value, hilfsMerker.einheit);
            if (h.schlechte.length || v.schlechte.length) {
                statusFehler("Nicht verstanden: " + h.schlechte.concat(v.schlechte).join("  "));
                return;
            }
            if (!h.werte.length && !v.werte.length) { status("Keine Werte eingegeben."); return; }
            hilfslinienAnlegen({
                h: h.werte, v: v.werte,
                alleSeiten: hilfsMerker.bereich === "alle",
                druckbogen: !!druckbogen.checked,
                loeschen: !!loeschen.checked
            });
        } else {
            status("bereit");
        }
    } catch (e) {
        statusFehler("Fenster ging nicht auf: " + e);
    } finally {
        hilfsOffen = false;
    }
}

// ------------------------------------- Bildschirmmodus und Anzeigeleistung
// Die dritte Reihe bündelt die häufigsten Ansicht-Griffe neben dem Zoom:
// W-Taste (Normal/Vorschau), die Anschnittvorschau und die Anzeigeleistung.
// Beides sitzt am Layoutfenster (screenMode bzw. viewDisplaySetting).

function modusWerte() {
    const S = indesign().ScreenModeOptions;
    return { normal: S.PREVIEW_OFF, vorschau: S.PREVIEW_TO_PAGE, anschnitt: S.PREVIEW_TO_BLEED };
}

function leistungWerte() {
    const V = indesign().ViewDisplaySettings;
    return { schnell: V.OPTIMIZED, typisch: V.TYPICAL, hoch: V.HIGH_QUALITY };
}

// Enum-Werte kommen aus UXP je nach Fassung als Zahl oder Objekt zurück —
// der Textvergleich trifft beide.
function enumGleich(a, b) {
    try { return String(a) === String(b); } catch (e) { return false; }
}

function bildschirmmodus(schluessel, wort) {
    const fenster = layoutFenster();
    if (!fenster) { status("Kein Dokumentfenster offen."); return; }
    try {
        fenster.screenMode = modusWerte()[schluessel];
        status("Bildschirmmodus: " + wort);
    } catch (e) {
        statusFehler("Bildschirmmodus ging nicht: " + e);
    }
}

function anzeigeleistung(schluessel, wort) {
    const fenster = layoutFenster();
    if (!fenster) { status("Kein Dokumentfenster offen."); return; }
    try {
        fenster.viewDisplaySetting = leistungWerte()[schluessel];
        status("Anzeigeleistung: " + wort);
    } catch (e) {
        statusFehler("Anzeigeleistung ging nicht: " + e);
    }
}

// InDesigns Oberfläche kennt vier Helligkeiten (0 = dunkelgrau … 1 = hell).
// Die mittlere Stufe 0,5 ist immer noch ein kräftiges Grau — dort gehört
// weißer Text hin. Als hell zählt deshalb erst alles über 0,6.
function helligkeitUebernehmen() {
    let hell = false;
    try {
        const { app } = indesign();
        const wert = app.generalPreferences.uiBrightnessPreference;
        hell = (typeof wert === "number") ? wert > 0.6 : false;
    } catch (e) { hell = false; }
    document.documentElement.classList.toggle("hell", hell);
}

// -------------------------------------------------------------- Live-Anzeige
// UXP liefert kein Zoom-Ereignis. Deshalb schaut ein leichter Taktgeber jede
// Sekunde nach, solange das Bedienfeld sichtbar ist: Zoomwert und Seite in
// die Statuszeile, aktive Stufe und Modi markieren, Knöpfe ohne Dokument
// ausgrauen und die Oberflächen-Helligkeit nachziehen.

function schalten(id, aus) {
    const element = document.getElementById(id);
    if (element && element.hasAttribute("disabled") !== !!aus) knopfGesperrt(element, aus);
}

function markieren(id, an) {
    const element = document.getElementById(id);
    if (element) element.classList.toggle("aktiv", !!an);
}

function anzeigeTakt() {
    try {
        helligkeitUebernehmen();
        // Der Sekundentakt hält auch Wandhöhe und Roll-Hinweise frisch — UXP
        // meldet manche Größenwechsel (An- und Abdocken) nicht als resize.
        wandMasseSetzen();
        if (stufenOffen || hilfsOffen) return;      // solange ruht die Anzeige
        const fenster = layoutFenster();
        const dokumentDa = !!fenster;
        const auswahl = dokumentDa && auswahlDa();

        // Ohne Dokument sind die Knöpfe gesperrt statt erst nach dem Klick
        // zu meckern; „Objekt“ braucht zusätzlich eine Auswahl.
        ["seite", "hundert", "montage", "zoomMinus", "zoomPlus", "zoomFeld",
         "modusNormal", "modusVorschau", "modusAnschnitt",
         "leistungSchnell", "leistungTypisch", "leistungHoch",
         "hilfslinien", "importoptionen"].forEach(id => schalten(id, !dokumentDa));
        schalten("objekt", !auswahl);
        schalten("zoomZurueck", !dokumentDa || zoomMerker === null);

        // Die freien Knöpfe nur dimmen, nicht sperren — Alt-Klick und
        // Rechtsklick zum Bearbeiten der Stufen sollen weiter gehen.
        stufen.forEach((stufe, i) => {
            const knopf = document.getElementById("frei" + i);
            if (knopf) knopf.classList.toggle("aus", !dokumentDa);
        });

        let zoomWert = null;
        if (dokumentDa) {
            try { zoomWert = Math.round(fenster.zoomPercentage * 10) / 10; } catch (e) { zoomWert = null; }
        }

        // Die Stufe, die gerade gilt, bekommt den Akzentrahmen.
        markieren("hundert", zoomWert !== null && Math.abs(zoomWert - 100) < 0.5);
        stufen.forEach((stufe, i) => {
            markieren("frei" + i, zoomWert !== null && Math.abs(zoomWert - stufe.wert) < 0.5);
        });

        // Bildschirmmodus und Anzeigeleistung als gedrückten Zustand zeigen.
        let modus = null, leistung = null;
        if (dokumentDa) {
            try { modus = fenster.screenMode; } catch (e) { modus = null; }
            try { leistung = fenster.viewDisplaySetting; } catch (e) { leistung = null; }
        }
        const M = dokumentDa ? modusWerte() : null;
        const L = dokumentDa ? leistungWerte() : null;
        markieren("modusNormal",     M && modus    !== null && enumGleich(modus, M.normal));
        markieren("modusVorschau",   M && modus    !== null && enumGleich(modus, M.vorschau));
        markieren("modusAnschnitt",  M && modus    !== null && enumGleich(modus, M.anschnitt));
        markieren("leistungSchnell", L && leistung !== null && enumGleich(leistung, L.schnell));
        markieren("leistungTypisch", L && leistung !== null && enumGleich(leistung, L.typisch));
        markieren("leistungHoch",    L && leistung !== null && enumGleich(leistung, L.hoch));

        // Das Eingabefeld nachziehen, solange niemand darin tippt.
        const feld = document.getElementById("zoomFeld");
        if (feld && document.activeElement !== feld) {
            feld.value = (zoomWert === null) ? "" : alsText(zoomWert);
            feld.classList.remove("ungueltig");
        }

        if (!dokumentDa) { statusLive("Kein Dokumentfenster offen."); return; }
        let text = (zoomWert === null) ? "" : alsText(zoomWert) + " %";
        try { text = "Seite " + fenster.activePage.name + " · " + text; } catch (e) { /* dann ohne Seite */ }
        statusLive(text);
    } catch (e) { /* der nächste Takt kommt bestimmt */ }
}

function anzeigeStarten() {
    if (taktUhr) return;
    taktUhr = setInterval(anzeigeTakt, 1000);
    anzeigeTakt();
}

function anzeigeAnhalten() {
    if (!taktUhr) return;
    clearInterval(taktUhr);
    taktUhr = null;
}

// ------------------------------------------------------------ Roll-Hinweise
// UXP zeichnet keine sichtbaren Rollbalken — dass ein Bereich unten (oder
// oben) weitergeht, sieht man sonst schlicht nicht. Jeder Rollbereich steckt
// in einem .rollrahmen mit zwei Pfeilzeilen (siehe stil.css), die nur bei
// verdecktem Inhalt erscheinen; ein Klick darauf rollt ein Stück weiter.

const rollBereiche = [];

function rollHinweiseAnbinden(bereich) {
    if (!bereich || bereich.dataset.rollt === "ja") return;
    bereich.dataset.rollt = "ja";
    const rahmen = bereich.parentElement;
    const oben  = rahmen ? rahmen.querySelector(".rollhinweis.oben")  : null;
    const unten = rahmen ? rahmen.querySelector(".rollhinweis.unten") : null;
    const zeigen = () => {
        // Ein unsichtbarer Bereich (geschlossener Dialog) meldet Höhe 0 —
        // dann bleiben beide Hinweise aus.
        const kannOben  = bereich.clientHeight > 0 && bereich.scrollTop > 2;
        const kannUnten = bereich.clientHeight > 0 &&
            bereich.scrollTop + bereich.clientHeight < bereich.scrollHeight - 2;
        if (oben)  oben.classList.toggle("sichtbar", kannOben);
        if (unten) unten.classList.toggle("sichtbar", kannUnten);
    };
    const rollen = (richtung) => {
        bereich.scrollTop += richtung * Math.max(40, Math.round(bereich.clientHeight * 0.8));
        zeigen();
    };
    bereich.addEventListener("scroll", zeigen);
    if (oben)  oben.addEventListener("click",  () => rollen(-1));
    if (unten) unten.addEventListener("click", () => rollen(1));
    rollBereiche.push(zeigen);
    zeigen();
}

// Beim Start festhalten, wie hoch der Inhalt wirklich ist — nur daraus lässt
// sich maximumSize im Manifest richtig setzen (Baulehre 20/23). Höhen gibt
// der Wirt heraus, Breiten nicht.
async function hoeheMessen(notiz) {
    try {
        const wand = document.getElementById("wandInhalt");
        if (!wand) return;
        const zeilen = [
            "Gemessen " + new Date().toLocaleString(),
            "Zustand: " + (notiz || "-"),
            "HÖHE nötig " + wand.scrollHeight + " · vorhanden " + wand.clientHeight,
            "BREITE " + wand.clientWidth
        ];
        const ordner = await require("uxp").storage.localFileSystem.getDataFolder();
        const datei  = await ordner.createFile("mess-hoehe.txt", { overwrite: true });
        await datei.write(zeilen.join("\n"));
    } catch (e) { /* Messung ist Beiwerk */ }
}

// Der Wirt gibt erst Maße heraus, wenn das Bedienfeld tatsächlich SICHTBAR ist.
// Bei "loadEvent": "startup" wird das Dokument lange vorher aufgebaut — eine
// Messung kurz nach dem Laden lieferte deshalb durchweg 0 (auch scrollHeight).
let messLauf = 0;
function messenWennBereit() {
    const lauf = ++messLauf;
    let versuche = 0;
    const takt = setInterval(() => {
        if (lauf !== messLauf) { clearInterval(takt); return; }
        versuche++;
        const wand = document.getElementById("wandInhalt");
        const da = wand && wand.clientHeight > 0;
        if (da || versuche >= 40) {
            clearInterval(takt);
            hoeheMessen(da ? "sichtbar nach " + (versuche * 500) + " ms"
                           : "NIE Maße bekommen (40 Versuche)");
        }
    }, 500);
}

// Die Bedienfeldknöpfe sind <div role="button"> (Baulehre 30): nur so kommen
// Füllung, Ecken und Höhe aus dem CSS an — ein <button> malt der Wirt selbst.
// Ein DIV kennt aber kein disabled. Deshalb: gesperrt = Attribut „disabled“
// (dafür greift das CSS), ein Wächter in der Fangphase lässt Klicks auf
// Gesperrte gar nicht erst ankommen, und Enter/Leertaste lösen aus wie beim
// echten Knopf (dispatchEvent — click() tut in UXP nichts, Baulehre 2).
function knopfGesperrt(element, aus) {
    if (!element) return;
    // Gesperrte DIV-Knöpfe auch aus der Tab-Reihe nehmen — ein <button disabled>
    // wäre von selbst unerreichbar, ein DIV mit tabindex 0 nicht.
    if (aus) { element.setAttribute("disabled", ""); element.setAttribute("tabindex", "-1"); }
    else     { element.removeAttribute("disabled");  element.setAttribute("tabindex", "0"); }
}
function knopfVon(ziel) {
    let el = ziel;
    while (el && el !== document) {
        if (el.classList && el.classList.contains("knopf")) return el;
        el = el.parentNode;
    }
    return null;
}
function knopfWaechterAnbinden(wurzel) {
    if (!wurzel || wurzel.getAttribute("data-waechter") === "ja") return;
    wurzel.setAttribute("data-waechter", "ja");
    wurzel.addEventListener("click", (e) => {
        const knopf = knopfVon(e && e.target);
        if (knopf && knopf.hasAttribute("disabled")) {
            if (e.stopPropagation) e.stopPropagation();
            if (e.preventDefault) e.preventDefault();
        }
    }, true);
    // Fangphase: läuft VOR dem keydown des Dialogs, und der Stopp sorgt dafür,
    // dass Enter auf einem DIV-Knopf nur diesen drückt — nicht zugleich als
    // „Eingabetaste = sichern“ des Fensters zählt.
    wurzel.addEventListener("keydown", (e) => {
        const taste = e && (e.key || e.code);
        if (taste !== "Enter" && taste !== "NumpadEnter" && taste !== " " && taste !== "Space") return;
        const knopf = knopfVon(e.target);
        if (!knopf) return;
        if (e.preventDefault) e.preventDefault();
        if (e.stopPropagation) e.stopPropagation();
        // Gesperrt: Taste schlucken — sonst zählte sie als Eingabetaste des
        // Fensters („sichern“), obwohl der Knopf sichtbar nichts tut.
        if (knopf.hasAttribute("disabled")) return;
        knopf.dispatchEvent(new Event("click"));
    }, true);
    // Fokus-Ring in Dialogen nur nach Tab, nie nach Mausklick (der sah aus wie
    // „aktiv“). Per Klasse, weil nur :focus im Wirt belegt ist; beim
    // unsichtbaren Absende-Knopf auf die Hülle gespiegelt. Feuert focusin im
    // Wirt nicht, passiert schlicht nichts.
    if (String(wurzel.tagName).toUpperCase() !== "DIALOG") return;
    const traeger = (ziel) => {
        const k = knopfVon(ziel);
        if (k) return k;
        const p = ziel && ziel.parentNode;
        return (p && p.classList && p.classList.contains("huelle")) ? p : null;
    };
    wurzel.addEventListener("keydown", (e) => {
        if ((e && (e.key || e.code)) === "Tab") wurzel.setAttribute("data-tastatur", "ja");
    }, true);
    wurzel.addEventListener("mousedown", () => wurzel.setAttribute("data-tastatur", ""), true);
    wurzel.addEventListener("focusin", (e) => {
        const t = traeger(e && e.target);
        if (t && wurzel.getAttribute("data-tastatur") === "ja") t.classList.add("fokus");
    }, true);
    wurzel.addEventListener("focusout", (e) => {
        const t = traeger(e && e.target);
        if (t) t.classList.remove("fokus");
    }, true);
}
// Wächter auf Bedienfeld UND Dialoge; dazu die Absende-Hüllen (Baulehre 31):
// greift die unsichtbare Schaltfläche den Klick nicht ab — etwa weil der
// Wirt ihre absolute Lage ignoriert —, reicht die sichtbare Fläche ihn an
// den echten Knopf weiter und schickt das Formular danach NATIV ab. Nur das
// schließt ein uxpShowModal-Fenster verlässlich; die Klick-Handler allein
// (Wunsch merken + close()) wären genau der Einfrier-Pfad aus Baulehre 11.
// Kennt der Wirt kein requestSubmit, tut der Rückfall lieber gar nichts.
function knopfWaechterAlle() {
    knopfWaechterAnbinden(document.getElementById("wandInhalt"));
    document.querySelectorAll("dialog").forEach(knopfWaechterAnbinden);
    document.querySelectorAll(".huelle").forEach((huelle) => {
        if (huelle.getAttribute("data-waechter") === "ja") return;
        huelle.setAttribute("data-waechter", "ja");
        const flaeche = huelle.querySelector(".knopf");
        const echt    = huelle.querySelector("button");
        if (!flaeche || !echt) return;
        flaeche.addEventListener("click", () => {
            let form = echt.form || null;
            if (!form) { let p = huelle.parentNode; while (p && String(p.tagName).toUpperCase() !== "FORM") p = p.parentNode; form = p || null; }
            if (!form || typeof form.requestSubmit !== "function") return;
            // Erst die Handler des echten Knopfs (Wunsch merken, Eingabe prüfen) —
            // cancelable, damit ein preventDefault („Anlegen“ bei ungültiger
            // Eingabe) ankommt und das Fenster offen bleibt.
            const ev = new Event("click", { cancelable: true });
            echt.dispatchEvent(ev);
            if (ev.defaultPrevented) return;
            let dialog = huelle.parentNode; while (dialog && String(dialog.tagName).toUpperCase() !== "DIALOG") dialog = dialog.parentNode;
            if (dialog && dialog.open === false) return;      // close() hat schon gegriffen
            try { form.requestSubmit(echt); } catch (e) { /* dann bleibt Enter/Esc */ }
        });
    });
}
if (document.getElementById("wandInhalt")) knopfWaechterAlle();
else document.addEventListener("DOMContentLoaded", knopfWaechterAlle);

function rollHinweiseAuffrischen() {
    for (const zeigen of rollBereiche) { try { zeigen(); } catch (e) {} }
}

// Die Wand auf die gemessene Fensterhöhe setzen. height:100% läuft in
// InDesigns UXP-Wirt ins Leere (html/body werden nicht auf die
// Bedienfeldhöhe gezwungen — die Wand wüchse mit dem Inhalt und nichts
// rollte, der Wirt schnitte unten ab). Aufruf bei Start, resize und im
// Sekundentakt, denn An- und Abdocken meldet nicht immer ein resize.
let wandHoeheZuletzt = 0;
function wandMasseSetzen() {
    const wand   = document.querySelector(".rollrahmen.wand");
    const inhalt = document.getElementById("wandInhalt");
    if (wand && inhalt) {
        let h = 0;
        try { h = window.innerHeight || 0; } catch (e) { h = 0; }
        if (!h) { try { h = document.documentElement.clientHeight || 0; } catch (e) {} }
        if (h > 40 && h !== wandHoeheZuletzt) {
            wandHoeheZuletzt = h;
            wand.style.height   = h + "px";
            inhalt.style.height = h + "px";
        }
    }
    rollHinweiseAuffrischen();
    knoepfeKuerzen(false);
}

// ------------------------------------------------------------- Dialoghöhe
// Dem Wirt ist die Fensterhöhe nicht zu überlassen: er baut Dialoge gern
// rund 30 px kürzer als den Inhalt (die Titelleiste geht zulasten des
// Fußes — beim Hilfslinien-Fenster fehlten so die Knöpfe). Eine
// AUSDRÜCKLICH angeforderte Höhe setzt er dagegen exakt um (Baulehre 8).
// Gemessen wird an einem KLON des Fensters, der unsichtbar an die Seite
// gehängt und gleich wieder entfernt wird — das echte Dialog-Element darf
// vor uxpShowModal() nicht per show()/close() berührt werden, sonst wirft
// der Wirt beim Öffnen einen InvalidStateError (live passiert).
// Beim Tippen in die Hilfslinien-Felder bricht die Eingabe nach zwei Zeichen
// ab. Weder das Markup (kein maxlength) noch masseZerlegen (keine Obergrenze)
// erklären das — also aufzeichnen, was der Wirt bei jedem Tastendruck mit Wert
// und Markierung macht. Landet beim Schließen in mess-hilfslinien.txt.
const tippZeilen = [];
function tippMitschrift(zeile) {
    if (tippZeilen.length < 200) tippZeilen.push(zeile);
}
async function tippMitschriftSchreiben() {
    if (!tippZeilen.length) return;
    try {
        const ordner = await require("uxp").storage.localFileSystem.getDataFolder();
        const datei  = await ordner.createFile("mess-hilfslinien.txt", { overwrite: true });
        await datei.write(["Aufgezeichnet " + new Date().toLocaleString()]
            .concat(tippZeilen).join("\n"));
    } catch (e) { /* Mitschrift ist Beiwerk */ }
    tippZeilen.length = 0;
}

function dialogHoeheMessen(fenster, messBreite) {
    let gemessen = 0, klon = null;
    try {
        klon = fenster.cloneNode(true);
        // Keine doppelten Kennungen im Baum — der Klon lebt nur einen Moment.
        try { klon.removeAttribute("id"); } catch (e) {}
        try { klon.querySelectorAll("[id]").forEach(el => el.removeAttribute("id")); } catch (e) {}
        klon.setAttribute("open", "");
        klon.style.display = "block";
        klon.style.position = "absolute";
        klon.style.left = "-4000px";
        klon.style.top = "0";
        // NICHT visibility:hidden — so versteckt misst der Wirt 0
        // (Baulehre 22), dialogHoeheMessen fiel dann auf den
        // Rückfallwert zurück und der Dialog ging viel zu hoch auf.
        klon.style.opacity = "0";
        klon.style.pointerEvents = "none";
        klon.style.width = messBreite + "px";
        klon.style.height = "auto";
        document.body.appendChild(klon);
        gemessen = Math.ceil(klon.getBoundingClientRect().height);
    } catch (e) { gemessen = 0; }
    try { if (klon && klon.parentNode) klon.parentNode.removeChild(klon); } catch (e) {}
    return gemessen;
}

// --------------------------------------------------- Knopfbeschriftungen
// UXP kennt auf Knöpfen kein text-overflow: bei zentriertem Text wird
// Übermaß an BEIDEN Seiten stumm abgeschnitten (aus „Newspaper“ wurde
// „ewspap“) — und scrollWidth meldet dabei KEINEN Überlauf, taugt also
// nicht als Prüfung (live gesehen). Deshalb misst ein unsichtbares
// Mess-Span die Textbreite selbst; gekürzt wird mit echtem „…“, der volle
// Text liegt im Tooltip nach, wenn der Knopf keinen eigenen hat.
// Läuft nach jedem Knopfbau und huckepack auf wandMasseSetzen (resize
// und Sekundentakt) — aber nur, wenn sich die Panelbreite geändert hat.
let kuerzenBreiteZuletzt = -1;
let messSpan = null;
// Breite eines Elements: getBoundingClientRect zuerst, dann offsetWidth,
// dann clientWidth. In InDesigns UXP ist window.innerWidth undefined
// (Baulehre 21) — auf einen einzigen Weg ist kein Verlass.
function elementBreite(el) {
    if (!el) return 0;
    try {
        const r = el.getBoundingClientRect();
        if (r && r.width > 0) return r.width;
    } catch (e) { /* weiter */ }
    try { if (el.offsetWidth > 0) return el.offsetWidth; } catch (e) { /* weiter */ }
    try { if (el.clientWidth > 0) return el.clientWidth; } catch (e) { /* weiter */ }
    return 0;
}
function textBreite(text, schriftGroesse) {
    if (!messSpan) {
        messSpan = document.createElement("span");
        messSpan.style.position = "absolute";
        messSpan.style.left = "-4000px";
        messSpan.style.top = "0";
        // NICHT visibility:hidden — ein so versteckter Knoten liefert im
        // UXP-Wirt keine Maße mehr, und dann hält die Kürzung jeden Text für
        // kurz genug (im Export-Feld blieb so „ewspap“ stehen).
        messSpan.style.opacity = "0";
        messSpan.style.pointerEvents = "none";
        messSpan.style.whiteSpace = "nowrap";
        document.body.appendChild(messSpan);
    }
    messSpan.style.fontSize = schriftGroesse;
    messSpan.textContent = text;
    const gemessen = elementBreite(messSpan);
    if (gemessen > 0) return gemessen;
    const px = parseFloat(schriftGroesse) || 11;
    return text.length * px * 0.55;
}
function knopfSchrift(knopf) {
    try {
        const stil = getComputedStyle(knopf);
        if (stil && stil.fontSize) return stil.fontSize;
    } catch (e) { /* dann nach Klasse */ }
    return knopf.classList.contains("segment") ? "10px" : "11px";
}
function knopfTextKuerzen(knopf) {
    // Kürzen ist in einem UXP-Bedienfeld prinzipiell unmöglich: der Wirt gibt
    // für Flex-Kinder keine Breite heraus (Baulehre 23, gemessen: alles 0), und
    // ohne verfügbare Breite gibt es nichts zu vergleichen. Auch element.dataset
    // trägt nichts über den Aufruf hinaus. Also nur noch der Weg, der ohne
    // Elementmaße auskommt: den Knopf so breit machen, dass die Aufschrift
    // hineinpasst — die Textbreite liefert der Wirt zuverlässig.
    knopfBreiteSichern(knopf);
}
// Der Wirt gibt für Flex-Kinder KEINE Breite heraus (Baulehre 23, gemessen:
// jeder Knopf 0 px, wandInhalt 0 px) — Kürzen ist damit unmöglich, denn ohne
// verfügbare Breite gibt es nichts zu vergleichen. Textbreiten liefert er
// dagegen (das Mess-Span steht absolut und schrumpft auf den Inhalt). Also
// andersherum: den Knopf so breit machen, dass die Aufschrift hineinpasst.
// Nur vergrößern, nie verkleinern — sonst kippt die bestehende Aufteilung.
const KNOPF_SONDER = ["breit", "schmal", "winzig", "segment", "klein"];
function knopfBreiteSichern(knopf) {
    if (!knopf) return;
    if (KNOPF_SONDER.some((k) => knopf.classList.contains(k))) return;
    const text = knopf.textContent;
    if (!text) return;
    const noetig = Math.ceil(textBreite(text, knopfSchrift(knopf))) + 18;
    if (!(noetig > 0)) return;
    let basis = "";
    try { basis = String(getComputedStyle(knopf).flexBasis || ""); } catch (e) { basis = ""; }
    // Steht die Grundbreite auf „auto“, richtet der Knopf sich schon nach
    // seiner Aufschrift und kann gar nicht abschneiden — Finger weg.
    if (!/^\d/.test(basis)) return;
    const grund = parseFloat(basis) || 0;
    if (noetig <= grund) return;
    knopf.style.flexBasis = noetig + "px";
    knopf.style.minWidth  = noetig + "px";
}

function knoepfeKuerzen(erzwingen) {
    let breite = 0;
    try {
        breite = elementBreite(document.getElementById("wandInhalt")) ||
                 elementBreite(document.body);
    } catch (e) { breite = 0; }
    // Meldet der Wirt gar keine Breite (0), darf der Vergleich nicht dauerhaft
    // blockieren — sonst liefe die Kürzung nach dem ersten Lauf nie wieder.
    if (!erzwingen && breite > 0 && breite === kuerzenBreiteZuletzt) return;
    kuerzenBreiteZuletzt = breite;
    document.querySelectorAll("#wandInhalt .knopf").forEach(knopfTextKuerzen);
}

// --------------------------------------------------------- Eigene Zoomstufen

async function datenOrdner() {
    return await require("uxp").storage.localFileSystem.getDataFolder();
}

function gueltigeStufe(wert, ersatz) {
    const n = parseFloat(String(wert).replace(",", "."));
    if (isNaN(n)) return ersatz;
    return Math.max(5, Math.min(4000, Math.round(n * 10) / 10));
}

function stufeNormalisieren(eintrag, ersatz) {
    if (eintrag && typeof eintrag === "object")
        return { name: String(eintrag.name || ""), wert: gueltigeStufe(eintrag.wert, ersatz) };
    return { name: "", wert: gueltigeStufe(eintrag, ersatz) };   // alte Form: nur eine Zahl
}

async function stufenLaden() {
    try {
        const ordner = await datenOrdner();
        let datei = null;
        try { datei = await ordner.getEntry(EINSTELLUNGSDATEI); } catch (e) { datei = null; }
        if (datei) {
            const gelesen = JSON.parse(await datei.read());
            if (gelesen && Array.isArray(gelesen.stufen))
                stufen = gelesen.stufen.map(e => stufeNormalisieren(e, 100));
        }
    } catch (e) { /* dann die Vorgabewerte */ }
    freieKnoepfeBauen();
}

async function stufenSichern() {
    try {
        const ordner = await datenOrdner();
        const datei = await ordner.createFile(EINSTELLUNGSDATEI, { overwrite: true });
        await datei.write(JSON.stringify({ stufen: stufen }, null, 2));
        return true;
    } catch (e) {
        statusFehler("Zoomstufen ließen sich nicht sichern.");
        return false;
    }
}

// Zahlen ohne unnötige Null hinter dem Komma: 50 %, nicht 50,0 %.
function alsText(wert) {
    return (Math.round(wert) === wert) ? String(wert) : String(wert).replace(".", ",");
}

function stufenAufschrift(stufe) {
    const name = String(stufe.name || "").replace(/^\s+|\s+$/g, "");
    return name.length ? name : (alsText(stufe.wert) + " %");
}

// Die eigenen Stufen entstehen aus der Liste — beliebig viele, auch keine.
function freieKnoepfeBauen() {
    const leiste = document.getElementById("freieLeiste");
    if (!leiste) return;
    leiste.innerHTML = "";
    stufen.forEach((stufe, i) => {
        const knopf = document.createElement("div");
        knopf.setAttribute("role", "button");
        knopf.setAttribute("tabindex", "0");
        knopf.className = "knopf frei";
        knopf.id = "frei" + i;
        knopf.textContent = stufenAufschrift(stufe);
        knopf.setAttribute("title",
            "Auf " + alsText(stufe.wert) + " % zoomen · bei einer Auswahl auf die Auswahl" +
            "  ·  Alt-Klick oder Rechtsklick: Stufen bearbeiten");
        knopf.addEventListener("click", (e) => {
            if (e && e.altKey) stufenFenster();
            else freieStufe(i);
        });
        knopf.addEventListener("contextmenu", (e) => {
            if (e && e.preventDefault) e.preventDefault();
            stufenFenster();
        });
        leiste.appendChild(knopf);
    });
    rollHinweiseAuffrischen();
    knoepfeKuerzen(true);
}

function freieStufe(index) {
    const fenster = layoutFenster();
    if (!fenster) { status("Kein Dokumentfenster offen."); return; }
    if (!stufen[index]) return;
    const wert = stufen[index].wert;
    zoomMerken(fenster);
    if (auswahlDa() && auswahlEinpassen(true)) {
        try { fenster.zoomPercentage = wert; } catch (e) {}
        status("Auswahl bei " + alsText(wert) + " %");
        return;
    }
    try {
        fenster.zoomPercentage = wert;
        status(alsText(wert) + " %");
    } catch (e) {
        statusFehler("Zoomstufe ging nicht: " + e);
    }
}

let stufenOffen = false;
// Siehe Export-Bedienfeld: der Rückgabewert von uxpShowModal() ist nicht
// verlässlich, der Klick merkt sich die Absicht selbst.
let stufenWunsch = "abbruch";

function neueStufe() { return { name: "", wert: 100 }; }

// Was in den Feldern steht, in den Entwurf zurückschreiben — sonst gehen
// Eingaben beim Hinzufügen oder Verschieben verloren.
function stufenAusFeldern() {
    stufenEntwurf.forEach((stufe, i) => {
        const name = document.getElementById("stufeName" + i);
        const wert = document.getElementById("stufeWert" + i);
        if (!wert) return;
        stufe.name = name ? name.value.replace(/^\s+|\s+$/g, "") : stufe.name;
        stufe.wert = gueltigeStufe(wert.value, stufe.wert);
    });
}

function stufenKleinKnopf(zeichen, hinweis, tun) {
    const knopf = document.createElement("div");
    knopf.setAttribute("role", "button");
    knopf.setAttribute("tabindex", "0");
    knopf.className = "knopf winzig";
    knopf.textContent = zeichen;
    knopf.setAttribute("title", hinweis);
    knopf.addEventListener("click", () => { stufenAusFeldern(); tun(); stufenZeilenBauen(); });
    return knopf;
}

function stufenZeilenBauen() {
    const behaelter = document.getElementById("stufenListe");
    if (!behaelter) return;
    behaelter.innerHTML = "";

    stufenEntwurf.forEach((stufe, i) => {
        const zeile = document.createElement("div");
        zeile.className = "stufenZeile";

        const name = document.createElement("input");
        name.type = "text"; name.className = "name"; name.id = "stufeName" + i;
        name.value = stufe.name || "";
        name.setAttribute("placeholder", "leer = Wert zeigen");

        const wert = document.createElement("input");
        wert.type = "text"; wert.className = "wert"; wert.id = "stufeWert" + i;
        wert.value = alsText(stufe.wert);
        // Pfeil hoch/runter schrittelt wie in InDesign-Feldern; die Eingabe
        // wird sofort geprüft — Ungültiges bekommt einen roten Rand, statt
        // beim Sichern stillschweigend auf den alten Wert zurückzufallen.
        wert.addEventListener("keydown", (e) => {
            const taste = e && (e.key || e.code);
            if (taste === "ArrowUp" || taste === "ArrowDown") {
                if (e.preventDefault) e.preventDefault();
                wertSchritt(wert, taste === "ArrowUp" ? 1 : -1, !!e.shiftKey);
            }
        });
        wert.addEventListener("input", () => wertPruefen(wert));

        const einheit = document.createElement("span");
        einheit.className = "einheit";
        einheit.textContent = "%";

        const rauf = stufenKleinKnopf("\u2191", "nach oben", () => {
            if (i > 0) { const x = stufenEntwurf[i - 1]; stufenEntwurf[i - 1] = stufenEntwurf[i]; stufenEntwurf[i] = x; }
        });
        const runter = stufenKleinKnopf("\u2193", "nach unten", () => {
            if (i < stufenEntwurf.length - 1) { const x = stufenEntwurf[i + 1]; stufenEntwurf[i + 1] = stufenEntwurf[i]; stufenEntwurf[i] = x; }
        });
        const weg = stufenKleinKnopf("\u2715", "diese Stufe löschen", () => {
            stufenEntwurf.splice(i, 1);
        });
        knopfGesperrt(rauf, i === 0);
        knopfGesperrt(runter, i === stufenEntwurf.length - 1);

        zeile.appendChild(name);
        zeile.appendChild(wert);
        zeile.appendChild(einheit);
        zeile.appendChild(rauf);
        zeile.appendChild(runter);
        zeile.appendChild(weg);
        behaelter.appendChild(zeile);
    });

    if (!stufenEntwurf.length) {
        const leer = document.createElement("div");
        leer.className = "hinweis";
        leer.textContent = "Keine eigenen Stufen — mit „+ Stufe“ eine anlegen.";
        behaelter.appendChild(leer);
    }
    rollHinweiseAuffrischen();
}

async function stufenFenster() {
    if (stufenOffen) return;
    stufenOffen = true;
    const fenster = document.getElementById("stufenFenster");
    try {
        stufenEntwurf = stufen.map(st => ({ name: st.name, wert: st.wert }));
        stufenZeilenBauen();
        stufenWunsch = "abbruch";
        // Höhe messen und ausdrücklich anfordern — wie beim
        // Hilfslinien-Fenster (dialogHoeheMessen), die Stufenliste deckelt
        // ihre Höhe selbst (max-height + eigener Rollbereich).
        const gemessen = dialogHoeheMessen(fenster, 380);
        const wunschHoehe = gemessen > 100 ? Math.min(560, gemessen + 56) : 500;
        // Falls ein früherer Fehler das Fenster halb offen hinterließ:
        // aufräumen, sonst wirft uxpShowModal einen InvalidStateError.
        try { fenster.close(); } catch (e) {}
        try { fenster.removeAttribute("open"); } catch (e) {}
        // Solange der Dialog zu ist, misst die Stufenliste 0 — die Hinweise
        // kurz nach dem Aufgehen nachziehen (uxpShowModal kehrt erst beim
        // Schließen zurück, deshalb vorab eingeplant).
        setTimeout(rollHinweiseAuffrischen, 150);
        setTimeout(rollHinweiseAuffrischen, 500);
        let ergebnis;
        if (typeof fenster.uxpShowModal === "function") {
            ergebnis = await fenster.uxpShowModal({
                title: "Ansicht dwb — Eigene Zoomstufen",
                resize: "both",
                size: { width: 380, height: wunschHoehe }
            });
        } else {
            ergebnis = await fenster.showModal();
        }
        if (stufenWunsch === "sichern" || ergebnis === "sichern") {
            stufenAusFeldern();
            stufen = stufenEntwurf;
            freieKnoepfeBauen();
            await stufenSichern();
            status(stufen.length + (stufen.length === 1 ? " eigene Stufe" : " eigene Stufen") + " gesichert.");
        } else {
            status("bereit");
        }
    } catch (e) {
        statusFehler("Fenster ging nicht auf: " + e);
    } finally {
        stufenOffen = false;
    }
}

function knoepfeVerdrahten() {
    const seite = document.getElementById("seite");
    if (!seite || seite.dataset.fertig === "ja") return;
    seite.dataset.fertig = "ja";

    // Rollbereiche anbinden: das Bedienfeld selbst und die Stufenliste im
    // Dialog. Beim Größerziehen des Bedienfelds werden die Hinweise nachgezogen.
    rollHinweiseAnbinden(document.getElementById("wandInhalt"));
    rollHinweiseAnbinden(document.getElementById("stufenListe"));
    rollHinweiseAnbinden(document.getElementById("hilfsRumpf"));
    window.addEventListener("resize", wandMasseSetzen);
    messenWennBereit();
    wandMasseSetzen();

    seite.addEventListener("click", (e) => {
        const Z = indesign().ZoomOptions;
        if (e && e.altKey) zoomen(Z.FIT_SPREAD, "Druckbogen eingepasst");
        else zoomen(Z.FIT_PAGE, "Seite eingepasst");
    });
    document.getElementById("hundert").addEventListener("click", () => originalgroesse());
    document.getElementById("objekt").addEventListener("click", () => auswahlEinpassen(false));
    document.getElementById("montage").addEventListener("click", () => {
        zoomen(indesign().ZoomOptions.SHOW_PASTEBOARD, "Montagefläche");
    });
    const importKnopf = document.getElementById("importoptionen");
    if (importKnopf) importKnopf.addEventListener("click", () => importoptionen());

    // Hilfslinien: Knopf, Live-Prüfung der Felder, Tastatur und die beiden
    // Fenster-Knöpfe — gleiche Bauart wie beim Zoomstufen-Fenster.
    const hilfsKnopf = document.getElementById("hilfslinien");
    if (hilfsKnopf) hilfsKnopf.addEventListener("click", () => hilfsFensterOeffnen());
    ["hilfsH", "hilfsV"].forEach(id => {
        const feld = document.getElementById(id);
        if (!feld) return;
        feld.addEventListener("keydown", (e) => {
            tippMitschrift(id + " keydown " + (e && e.key) +
                " · vorher \"" + feld.value + "\" (" + feld.value.length + ")" +
                " · Markierung " + feld.selectionStart + "-" + feld.selectionEnd);
        });
        feld.addEventListener("input", () => {
            tippMitschrift(id + " input    · jetzt \"" + feld.value + "\" (" +
                feld.value.length + ") · Markierung " +
                feld.selectionStart + "-" + feld.selectionEnd);
            hilfsFeldPruefen(feld);
            const meldung = document.getElementById("hilfsMeldung");
            // Ebenfalls nur bei echter Änderung — sonst schreibt jeder
            // Tastendruck in den Baum.
            if (meldung && meldung.textContent) meldung.textContent = "";
        });
    });
    // Bestandsblock: Einheitenwechsel rechnet die Anzeige um, „In die Felder
    // übernehmen“ stellt die vorhandenen Werte in die Eingabefelder.
    const hilfsEinheitFeld = document.getElementById("hilfsEinheit");
    if (hilfsEinheitFeld) hilfsEinheitFeld.addEventListener("change", () => hilfsBestandZeigen());
    const hilfsUebernehmen = document.getElementById("hilfsUebernehmen");
    if (hilfsUebernehmen) {
        hilfsUebernehmen.addEventListener("click", () => {
            const einheit = auswahlWert(hilfsEinheitFeld, "mm");
            const feldH = document.getElementById("hilfsH");
            const feldV = document.getElementById("hilfsV");
            if (feldH) { feldH.value = hilfsBestand.h.map(wert => massAlsText(wert, einheit)).join("  "); hilfsFeldPruefen(feldH); }
            if (feldV) { feldV.value = hilfsBestand.v.map(wert => massAlsText(wert, einheit)).join("  "); hilfsFeldPruefen(feldV); }
            const meldung = document.getElementById("hilfsMeldung");
            if (meldung) meldung.textContent = "";
        });
    }
    const hilfsElement = document.getElementById("hilfsFenster");
    if (hilfsElement) {
        hilfsElement.addEventListener("keydown", (e) => {
            const taste = e && (e.key || e.code);
            // Auf einem gewöhnlichen Knopf (Übernehmen) heißt die Eingabetaste
            // „diesen Knopf drücken“, nicht „Anlegen“.
            const ziel = e && e.target;
            // Auf dem fokussierten Abbrechen-Knopf heißt Enter „abbrechen“: keine
            // Eingabeprüfung, kein preventDefault — das native Absenden schließt.
            // „abbruch!“ überstimmt auch ein ergebnis === "anlegen", falls der
            // Wirt Enter trotzdem über den ERSTEN Absende-Knopf schickt (Baulehre 13).
            if (ziel && ziel.id === "hilfsAbbruch") { hilfsWunsch = "abbruch!"; return; }
            if (taste === "Enter" || taste === "NumpadEnter") {
                // Ungültiges oder Leeres nicht per Eingabetaste absenden —
                // roter Rand und Meldung bleiben, das Fenster auch.
                if (hilfsEingabeSchlecht()) {
                    if (e.preventDefault) e.preventDefault();
                    return;
                }
                hilfsWunsch = "anlegen";
            }
            if (taste === "Escape" || taste === "Esc") hilfsWunsch = "abbruch";
        });
    }
    const hilfsAnlegen = document.getElementById("hilfsAnlegen");
    if (hilfsAnlegen) {
        hilfsAnlegen.addEventListener("click", (e) => {
            if (hilfsEingabeSchlecht()) {
                if (e && e.preventDefault) e.preventDefault();
                return;
            }
            hilfsWunsch = "anlegen";
            try {
                document.getElementById("hilfsFenster").close("anlegen");
            } catch (e2) { /* das Formular schließt dann von selbst */ }
        });
    }
    const hilfsAbbruch = document.getElementById("hilfsAbbruch");
    if (hilfsAbbruch) {
        hilfsAbbruch.addEventListener("click", () => {
            hilfsWunsch = "abbruch";
            try {
                document.getElementById("hilfsFenster").close("abbruch");
            } catch (e2) { /* das Formular schließt dann von selbst */ }
        });
    }

    // Zoomleiste: Minus, Eingabefeld, Plus, Zurück.
    const minus = document.getElementById("zoomMinus");
    if (minus) minus.addEventListener("click", () => zoomSchritt(-1));
    const plus = document.getElementById("zoomPlus");
    if (plus) plus.addEventListener("click", () => zoomSchritt(1));
    const zurueckZoom = document.getElementById("zoomZurueck");
    if (zurueckZoom) zurueckZoom.addEventListener("click", () => zoomZurueck());

    const zoomFeld = document.getElementById("zoomFeld");
    if (zoomFeld) {
        zoomFeld.addEventListener("keydown", (e) => {
            const taste = e && (e.key || e.code);
            if (taste === "Enter" || taste === "NumpadEnter") zoomFeldAnwenden();
            if (taste === "ArrowUp" || taste === "ArrowDown") {
                if (e.preventDefault) e.preventDefault();
                wertSchritt(zoomFeld, taste === "ArrowUp" ? 1 : -1, !!e.shiftKey);
            }
            // Esc verwirft das Getippte und zeigt wieder den echten Wert.
            if (taste === "Escape" || taste === "Esc") {
                const fenster = layoutFenster();
                try { zoomFeld.value = fenster ? alsText(Math.round(fenster.zoomPercentage * 10) / 10) : ""; } catch (e2) {}
                zoomFeld.classList.remove("ungueltig");
            }
        });
        zoomFeld.addEventListener("input", () => wertPruefen(zoomFeld));
    }

    // Bildschirmmodus und Anzeigeleistung — je Knopf ein fester Griff.
    [["modusNormal", "normal", "Normal"],
     ["modusVorschau", "vorschau", "Vorschau"],
     ["modusAnschnitt", "anschnitt", "Anschnitt"]].forEach(eintrag => {
        const knopf = document.getElementById(eintrag[0]);
        if (knopf) knopf.addEventListener("click", () => bildschirmmodus(eintrag[1], eintrag[2]));
    });
    [["leistungSchnell", "schnell", "Schnelle Anzeige"],
     ["leistungTypisch", "typisch", "Typische Anzeige"],
     ["leistungHoch", "hoch", "Hohe Qualität"]].forEach(eintrag => {
        const knopf = document.getElementById(eintrag[0]);
        if (knopf) knopf.addEventListener("click", () => anzeigeleistung(eintrag[1], eintrag[2]));
    });

    const hinzu = document.getElementById("stufeHinzu");
    if (hinzu) {
        hinzu.addEventListener("click", () => {
            stufenAusFeldern();
            stufenEntwurf.push(neueStufe());
            stufenZeilenBauen();
            // Die neue Zeile steht ganz unten — dorthin rollen, sonst wirkt
            // der Klick wie verpufft.
            const liste = document.getElementById("stufenListe");
            if (liste) liste.scrollTop = liste.scrollHeight;
            rollHinweiseAuffrischen();
        });
    }

    // Zurück auf die Auslieferung: 50 % und 200 %. Wirkt nur in den Feldern —
    // „Sichern“ übernimmt es, „Abbrechen“ verwirft es.
    const zurueck = document.getElementById("stufenZurueck");
    if (zurueck) {
        zurueck.addEventListener("click", () => {
            stufenEntwurf = [{ name: "", wert: 50 }, { name: "", wert: 200 }];
            stufenZeilenBauen();
        });
    }

    // Zweite Sicherung für die Tastatur: Eingabetaste heißt sichern,
    // Esc heißt abbrechen.
    const stufenElement = document.getElementById("stufenFenster");
    if (stufenElement) {
        stufenElement.addEventListener("keydown", (e) => {
            const taste = e && (e.key || e.code);
            const ziel = e && e.target;
            if (taste === "Enter" || taste === "NumpadEnter")
                stufenWunsch = (ziel && ziel.id === "stufenAbbruch") ? "abbruch" : "sichern";
            if (taste === "Escape" || taste === "Esc") stufenWunsch = "abbruch";
        });
    }

    // Die beiden Knöpfe im Fenster schließen es selbst; das native
    // Absenden des Formulars tut dasselbe, falls close() einmal nicht greift.
    ["stufenAbbruch", "stufenSichern"].forEach(id => {
        const knopf = document.getElementById(id);
        if (!knopf) return;
        knopf.addEventListener("click", () => {
            stufenWunsch = (id === "stufenSichern") ? "sichern" : "abbruch";
            try {
                document.getElementById("stufenFenster").close(stufenWunsch);
            } catch (e) { /* das Formular schließt dann von selbst */ }
        });
    });
}

try {
    const { entrypoints } = require("uxp");
    entrypoints.setup({
        panels: {
            dwbAnsicht: {
                show() {
                    helligkeitUebernehmen();
                    messenWennBereit();
                    knoepfeVerdrahten();
                    freieKnoepfeBauen();
                    stufenLaden();
                    anzeigeStarten();
                    status("bereit");
                },
                // Versteckt (zugeklappt, anderer Reiter) ruht der Taktgeber.
                hide() {
                    anzeigeAnhalten();
                },
                menuItems: [
                    { id: "stufen",      label: "Zoomstufen festlegen…" },
                    { id: "hilfslinien", label: "Hilfslinien anlegen…" },
                    { id: "selbsttest",  label: "Selbsttest" }
                ],
                invokeMenu(id) {
                    if (id === "stufen") stufenFenster();
                    if (id === "hilfslinien") hilfsFensterOeffnen();
                    if (id === "selbsttest") selbsttest();
                }
            }
        }
    });
} catch (e) {
    statusFehler("Bedienfeld konnte sich nicht anmelden: " + e);
}

// Wird das Bedienfeld beim Start schon gezeigt, kommt show() vor dem
// Aufbau der Seite — deshalb zusätzlich hier verdrahten.
document.addEventListener("DOMContentLoaded", () => {
    helligkeitUebernehmen();
    knoepfeVerdrahten();
    stufenLaden();
    anzeigeStarten();
});
knoepfeVerdrahten();


// ============================================================================
//  Selbsttest
// ----------------------------------------------------------------------------
// Legt ein Testdokument an, drückt jeden der vier Knöpfe und schreibt, welche
// Zoomstufe dabei herauskam. Aufruf über das Bedienfeldmenü — oder beim
// Öffnen, wenn im Datenordner des Plugins eine Datei „selbsttest.txt“ liegt.
// ============================================================================

async function selbsttest() {
    const zeilen = [];
    const merke = (t) => { zeilen.push(String(t)); status("Selbsttest: " + t); };
    let doc = null;
    try {
        const idsn = indesign(), app = idsn.app;
        merke("InDesign " + app.version);
        doc = app.documents.add();
        doc.documentPreferences.pagesPerDocument = 2;
        const r = doc.pages.item(0).rectangles.add();
        r.geometricBounds = [20, 20, 60, 80];
        knoepfeVerdrahten();
        const probe = document.getElementById("seite");
        merke("Knopf da: " + !!probe + ", click=" + (probe ? typeof probe.click : "-") +
              ", dataset=" + (probe && probe.dataset ? "ja" : "nein") +
              ", verdrahtet=" + (probe ? probe.dataset && probe.dataset.fertig : "-"));

        const druecken = (id) => {
            const knopf = document.getElementById(id);
            if (!knopf) return "Knopf fehlt";
            let weg = "";
            try { knopf.dispatchEvent(new Event("click")); weg = "dispatchEvent"; }
            catch (e) {
                try { knopf.click(); weg = "click()"; } catch (e2) { weg = "kein Weg: " + e2; }
            }
            let zoom = "?";
            try { zoom = Math.round(app.activeWindow.zoomPercentage) + " %"; } catch (e) {}
            return zoom + " · " + document.getElementById("status").textContent + " [" + weg + "]";
        };

        merke("Seite: " + druecken("seite"));
        merke("Montage: " + druecken("montage"));
        app.select(r);
        merke("Objekt: " + druecken("objekt"));
        merke("100 % mit Auswahl: " + druecken("hundert"));
        app.select(null);
        merke("100 % ohne Auswahl: " + druecken("hundert"));
        merke("Objekt ohne Auswahl: " + druecken("objekt"));
        stufen.forEach((st, i) => {
            merke("eigene Stufe " + (i + 1) + " (" + stufenAufschrift(st) + "): " + druecken("frei" + i));
        });
        merke("Zoomleiste: minus=" + druecken("zoomMinus") + " | plus=" + druecken("zoomPlus") +
              " | zurück=" + druecken("zoomZurueck"));
        merke("Modus Vorschau: " + druecken("modusVorschau"));
        merke("Modus Normal: " + druecken("modusNormal"));
        merke("Leistung Hoch: " + druecken("leistungHoch"));
        merke("Leistung Typisch: " + druecken("leistungTypisch"));
        // Der Hilfslinien-Knopf öffnet ein modales Fenster — im Selbsttest
        // wird stattdessen die Kernfunktion direkt gerufen und nachgezählt.
        merke("Hilfslinien: " + (function () {
            try {
                const seite = app.activeWindow.activePage;
                const vorher = seite.guides.length;
                hilfslinienAnlegen({ h: [28.35], v: [56.7], alleSeiten: false, druckbogen: false, loeschen: false });
                return (seite.guides.length - vorher) + " neu (soll 2) · " +
                       document.getElementById("status").textContent;
            } catch (e) { return "FEHLER: " + e; }
        })());
        merke("Hilfslinien lesen: " + (function () {
            try {
                const bestand = hilfslinienLesen();
                return bestand.h.length + " waagrecht / " + bestand.v.length +
                       " senkrecht, Ebene „" + bestand.ebene + "“, " +
                       bestand.andere + " fremde · H=" +
                       bestand.h.map(w => Math.round(w * 100) / 100).join(",") +
                       " V=" + bestand.v.map(w => Math.round(w * 100) / 100).join(",") +
                       " (soll H≈28,35 V≈56,7)";
            } catch (e) { return "FEHLER: " + e; }
        })());
        const gemessen = [];
        ["seite", "hundert", "objekt", "montage", "frei0", "frei1",
         "zoomMinus", "zoomFeld", "zoomPlus", "zoomZurueck",
         "modusNormal", "modusVorschau", "modusAnschnitt",
         "leistungSchnell", "leistungTypisch", "leistungHoch",
         "hilfslinien", "importoptionen"].forEach(id => {
            const knopf = document.getElementById(id);
            if (!knopf) return;
            const rechteck = knopf.getBoundingClientRect();
            gemessen.push(id + " " + Math.round(rechteck.width) + "x" + Math.round(rechteck.height) +
                          (knopf.scrollWidth > knopf.clientWidth + 1 ? " ABGESCHNITTEN" : ""));
        });
        const importKnopf = document.getElementById("importoptionen");
        const befehl = importbefehlFinden();
        merke("Importoptionen: Knopf " + (importKnopf ? "da" : "FEHLT") +
              ", Menübefehl " + (befehl ? "gefunden (" + befehl.name + ")" : "fehlt — Menue-Startup.jsx prüfen"));
        merke("Knöpfe: " + gemessen.join(" | "));
        merke("Bedienfeld: " + document.body.clientWidth + "x" + document.body.clientHeight);
        merke("fertig");
    } catch (fehler) {
        zeilen.push("ABBRUCH: " + fehler + (fehler && fehler.stack ? " | " + fehler.stack : ""));
    }
    try { if (doc) doc.close(indesign().SaveOptions.NO); } catch (e) { zeilen.push("Schließen: " + e); }
    try {
        const ordner = await datenOrdner();
        const datei = await ordner.createFile("selbsttest-protokoll.txt", { overwrite: true });
        await datei.write(zeilen.join("\n"));
    } catch (e) { /* dann eben nicht */ }
    status("Selbsttest fertig — Protokoll im Datenordner.");
}

setTimeout(async () => {
    try {
        const ordner = await datenOrdner();
        let marke = null;
        try { marke = await ordner.getEntry("selbsttest.txt"); } catch (e) { marke = null; }
        if (marke) { await marke.delete(); await selbsttest(); }
    } catch (e) { /* kein Selbsttest */ }
}, 12000);
