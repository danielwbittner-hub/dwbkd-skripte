#!/bin/bash
# ============================================================================
#  dwb-Bedienfelder für InDesign einrichten
# ----------------------------------------------------------------------------
#  Legt die UXP-Plugins (Ansicht, Export, Prüfung) im Ordner an, in dem
#  InDesign nach fremden Bedienfeldern sucht, und trägt sie in dessen
#  Verzeichnisdatei ein. Danach InDesign neu starten — die Bedienfelder
#  stehen unter Plug-ins ▸ Ansicht dwb / Export dwb / Prüfung dwb.
#
#  Aufruf: Doppelklick (fragt: Einrichten / Entfernen / Prüfen), oder Terminal:
#          ./installieren.command                    richtet ein
#          ./installieren.command --entfernen        nimmt sie wieder heraus
#          ./installieren.command --entfernen-alles  löscht auch Einstellungen
#          ./installieren.command --pruefen          prüft, ohne zu ändern
#          ./installieren.command --ausfuehrlich     zeigt jeden Pfad einzeln
# ============================================================================
set -e
QUELLE="$(cd "$(dirname "$0")" && pwd)"
ZIEL="$HOME/Library/Application Support/Adobe/UXP/Plugins/External"
VERZEICHNIS="$HOME/Library/Application Support/Adobe/UXP/PluginsInfo/v1/ID.json"

MODUS="einrichten"
AUSFUEHRLICH=0
for ARG in "$@"; do
    case "$ARG" in
        --einrichten)      MODUS="einrichten" ;;
        --entfernen)       MODUS="entfernen" ;;
        --entfernen-alles) MODUS="entfernen-alles" ;;
        --pruefen)         MODUS="pruefen" ;;
        --ausfuehrlich)    AUSFUEHRLICH=1 ;;
        *) echo "Unbekannter Schalter: $ARG"; exit 2 ;;
    esac
done

# Ohne Argumente und mit Terminal davor (Doppelklick im Finder): kurz fragen —
# sonst wäre das Entfernen nur über das Terminal zu erreichen.
# Der Gesamtinstaller ruft mit --einrichten auf und landet nicht hier.
if [ $# -eq 0 ] && [ -t 0 ]; then
    echo "  [1] Einrichten   [2] Entfernen   [3] Prüfen"
    printf "  Auswahl (Eingabetaste = Einrichten): "
    read -r WAHL
    case "$WAHL" in
        2) MODUS="entfernen" ;;
        3) MODUS="pruefen" ;;
        *) MODUS="einrichten" ;;
    esac
    echo
fi

# Der ganze JSON-Teil läuft über python3 — das bringt macOS erst mit den
# Command Line Tools mit. Ohne Vorprüfung bräche der Lauf kryptisch mittendrin ab.
if ! command -v python3 >/dev/null 2>&1; then
    echo "✗ python3 fehlt auf diesem Rechner. Einmal im Terminal ausführen:"
    echo "      xcode-select --install"
    echo "  die Installation der Command Line Tools bestätigen und dieses"
    echo "  Skript danach erneut starten."
    exit 1
fi
if [ "$(command -v python3)" = "/usr/bin/python3" ] && ! xcode-select -p >/dev/null 2>&1; then
    echo "✗ python3 ist nur Apples Platzhalter — die Command Line Tools fehlen."
    echo "  Einmal im Terminal ausführen:"
    echo "      xcode-select --install"
    echo "  und dieses Skript danach erneut starten."
    exit 1
fi

# Läuft InDesign gerade, greift nichts davon vor dem Neustart — deutlich sagen.
# Nur auf das Hauptprogramm prüfen: das lose Muster traf auch Helfer, die nach
# dem Beenden noch stehen (Adobe Crash Processor liegt im selben .app-Ordner).
# Ruft der Gesamtinstaller (DWB_ELTERN), sagt er es selbst schon an.
if [ -z "${DWB_ELTERN:-}" ] && [ "$MODUS" != "pruefen" ] \
   && pgrep -f "Adobe InDesign [0-9]*\.app/Contents/MacOS/Adobe InDesign" >/dev/null 2>&1; then
    echo "⚠ InDesign läuft gerade — bitte beenden und neu starten,"
    echo "  vorher wird von den Änderungen nichts sichtbar."
    echo
fi

[ "$MODUS" = "pruefen" ] || mkdir -p "$ZIEL" "$(dirname "$VERZEICHNIS")"

FEHLER=0
python3 - "$QUELLE" "$ZIEL" "$VERZEICHNIS" "$MODUS" "$AUSFUEHRLICH" <<'PY' || FEHLER=$?
import glob, json, os, plistlib, re, shutil, sys

quelle, ziel, verzeichnis, modus = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
ausfuehrlich = (sys.argv[5] == "1")
entfernen = modus in ("entfernen", "entfernen-alles")
pruefen = (modus == "pruefen")
speicher = os.path.expanduser("~/Library/Application Support/Adobe/UXP/PluginsStorage/IDSN")

# Bilanz: eine Häkchenzeile je Baustein — volle Pfade nur mit --ausfuehrlich
# oder im Fehlerfall.
haken, fehler = [], []
def gut(text): haken.append("✓ " + text)
def hinweis(text): haken.append("· " + text)
def schlecht(text):
    haken.append("✗ " + text)
    fehler.append(text)
def einzel(text):
    if ausfuehrlich:
        print(text)

plugins = []
for unterordner in ("ansicht", "export", "pruefung"):
    pfad = os.path.join(quelle, unterordner, "manifest.json")
    with open(pfad, encoding="utf-8") as f:
        m = json.load(f)
    plugins.append({
        "quelle": os.path.join(quelle, unterordner),
        "id": m["id"],
        "name": m["name"],
        "version": m["version"],
        "minVersion": m["host"]["minVersion"],
    })

# Alte Kennungen (de.dwbkd.*) — das Plugin hieß früher so
alt_ids = ["de.dwbkd.ansicht", "de.dwbkd.export", "dwbkdtest"]

# Installierte InDesign-Version aus dem Programmpaket lesen — für die
# Mindestversionsprüfung und die Übernahme der Einstellungen.
def zahlen(text):
    return tuple(int(t) for t in re.findall(r"\d+", text)[:3])

indesign = None
for plist in glob.glob("/Applications/Adobe InDesign*/Adobe InDesign*.app/Contents/Info.plist"):
    try:
        with open(plist, "rb") as f:
            v = plistlib.load(f).get("CFBundleShortVersionString", "")
    except Exception:
        continue
    if v and (indesign is None or zahlen(v) > zahlen(indesign)):
        indesign = v

# UXP-Bedienfelder gibt es erst seit InDesign 18.5 — auf einem älteren Rechner
# liefe die Installation scheinbar durch, die Bedienfelder erschienen aber nie.
if not entfernen:
    if indesign is None:
        hinweis("InDesign-Version nicht feststellbar (kein Programmpaket unter /Applications)")
    else:
        zu_alt = [p for p in plugins if zahlen(indesign) < zahlen(p["minVersion"])]
        if zu_alt:
            schlecht("InDesign %s ist älter als die nötige Version %s — die Bedienfelder erscheinen dort nie. Rückfallebene: die Palette in ../Zoom-Export/" % (indesign, zu_alt[0]["minVersion"]))
        else:
            gut("InDesign %s erfüllt die Mindestversion %s" % (indesign, plugins[0]["minVersion"]))

if pruefen:
    # 1. Liegen die Plugin-Ordner samt manifest.json am Platz?
    for p in plugins:
        ordner = os.path.join(ziel, "%s_%s" % (p["id"], p["version"]))
        if os.path.isdir(ordner) and os.path.isfile(os.path.join(ordner, "manifest.json")):
            gut("Plugin-Ordner %s_%s samt manifest.json" % (p["id"], p["version"]))
            einzel("in Ordnung: %s" % ordner)
        else:
            schlecht("Plugin-Ordner fehlt oder ohne manifest.json: %s" % ordner)

    # 2. Stehen beide Einträge richtig in der Verzeichnisdatei?
    if not os.path.exists(verzeichnis):
        schlecht("Verzeichnisdatei fehlt: %s" % verzeichnis)
    else:
        try:
            with open(verzeichnis, encoding="utf-8") as f:
                daten = json.load(f)
            if not isinstance(daten, dict):
                raise ValueError("oberste Ebene ist kein JSON-Objekt")
        except Exception as e:
            schlecht("Verzeichnisdatei ist kein lesbares JSON (%s): %s" % (e, verzeichnis))
        else:
            for p in plugins:
                soll = "$localPlugins/External/%s_%s" % (p["id"], p["version"])
                treffer = [e for e in daten.get("plugins", []) if isinstance(e, dict) and e.get("pluginId") == p["id"]]
                if len(treffer) == 1 and treffer[0].get("path") == soll and treffer[0].get("status") == "enabled":
                    gut("Eintrag in ID.json: %s (enabled)" % p["id"])
                elif treffer:
                    schlecht("Eintrag in ID.json passt nicht (Pfad, Status oder doppelt): %s" % p["id"])
                else:
                    schlecht("Eintrag fehlt in ID.json: %s" % p["id"])

    # 3. Das jüngste UXP-Log über ALLE Jahresordner hinweg nach dwb-Fehlern
    #    durchsuchen — der Jahresordner im Pfad wächst nicht mit der Version mit.
    logs = glob.glob(os.path.expanduser("~/Library/Logs/Adobe/Adobe InDesign */UXPLogs_*.log"))
    if not logs:
        hinweis("kein UXP-Log gefunden — InDesign seit der Einrichtung noch nicht gestartet?")
    else:
        juengstes = max(logs, key=os.path.getmtime)
        treffer = []
        with open(juengstes, encoding="utf-8", errors="replace") as f:
            for zeile in f:
                if "dwb" in zeile.lower() and re.search(r"error|fail|exception|denied|invalid", zeile, re.I):
                    treffer.append(zeile.strip())
        if treffer:
            schlecht("%d dwb-Fehlerzeile(n) im jüngsten UXP-Log (%s)" % (len(treffer), os.path.basename(juengstes)))
            for zeile in treffer[-5:]:
                print("    " + zeile[:200])
        else:
            gut("keine dwb-Fehler im jüngsten UXP-Log (%s)" % os.path.basename(juengstes))
        einzel("gelesen: %s" % juengstes)

else:
    # 0. Verzeichnisdatei zuerst nur LESEN. Ist sie kaputt, brechen wir ab,
    #    BEVOR irgendetwas angefasst ist — sonst gingen die Einträge ALLER
    #    fremden Plugins stillschweigend verloren (und die Plugin-Ordner wären
    #    schon umgebaut).
    daten = {"plugins": []}
    if os.path.exists(verzeichnis):
        try:
            with open(verzeichnis, encoding="utf-8") as f:
                daten = json.load(f)
            if not isinstance(daten, dict):
                raise ValueError("oberste Ebene ist kein JSON-Objekt")
        except Exception as e:
            sys.stderr.write(
                "✗ Abbruch, nichts wurde geändert: die Verzeichnisdatei\n"
                "  %s\n"
                "  ist kein lesbares JSON (%s).\n"
                "  Bitte die Datei prüfen — oder beiseitelegen und InDesign einmal\n"
                "  starten (es legt sie neu an), dann erneut installieren.\n" % (verzeichnis, e))
            sys.exit(1)
    if "plugins" not in daten or not isinstance(daten["plugins"], list):
        daten["plugins"] = []

    # 1. Erst alles Eigene abräumen — auch ÄLTERE Versionsordner (id_*), die
    #    nach einem Update sonst als Leichen liegen blieben, und die alten
    #    Kennungen aus der Anfangszeit. Gemeldet wird nur, was wirklich da war.
    aktuelle = set("%s_%s" % (p["id"], p["version"]) for p in plugins)
    praefixe = [p["id"] + "_" for p in plugins] + [aid + "_" for aid in alt_ids]
    abgeraeumt, alte = 0, 0
    for eintrag in sorted(os.listdir(ziel)):
        if not any(eintrag.startswith(pfx) for pfx in praefixe):
            continue
        pfad = os.path.join(ziel, eintrag)
        if os.path.islink(pfad):
            os.unlink(pfad)
        else:
            shutil.rmtree(pfad, ignore_errors=True)
        einzel("abgeräumt: %s" % pfad)
        abgeraeumt += 1
        if eintrag not in aktuelle:
            alte += 1

    # 2. Ordner anlegen (Kopie – Symlinks mag der Plugin-Lader nicht immer)
    if not entfernen:
        for p in plugins:
            ordner = os.path.join(ziel, "%s_%s" % (p["id"], p["version"]))
            shutil.copytree(p["quelle"], ordner)
            einzel("angelegt: %s" % ordner)
        gut("%d Bedienfelder angelegt" % len(plugins))
        if alte:
            hinweis("%d alte Fassung(en) abgeräumt" % alte)
    elif abgeraeumt:
        gut("%d Plugin-Ordner entfernt" % abgeraeumt)
    else:
        hinweis("kein Plugin-Ordner vorhanden — nichts zu entfernen")

    # 3. Verzeichnisdatei ergänzen (in Schritt 0 gelesen und geprüft),
    #    fremde Einträge bleiben stehen.
    eigene = set(p["id"] for p in plugins) | set(alt_ids)
    daten["plugins"] = [e for e in daten["plugins"] if not (isinstance(e, dict) and e.get("pluginId") in eigene)]

    if not entfernen:
        for p in plugins:
            daten["plugins"].append({
                "hostMinVersion": p["minVersion"],
                "name": p["name"],
                "path": "$localPlugins/External/%s_%s" % (p["id"], p["version"]),
                "pluginId": p["id"],
                "status": "enabled",
                "type": "uxp",
                "versionString": p["version"],
            })

    # Abgesichert schreiben: Sicherungskopie, dann Temporärdatei und atomarer
    # Tausch — eine halb geschriebene ID.json gibt es so nie.
    sicherung = os.path.exists(verzeichnis)
    if sicherung:
        shutil.copy2(verzeichnis, verzeichnis + ".bak")
    temporaer = verzeichnis + ".neu"
    with open(temporaer, "w", encoding="utf-8") as f:
        json.dump(daten, f, ensure_ascii=False)
    os.replace(temporaer, verzeichnis)
    gut("Verzeichnisdatei geschrieben: %d %s%s" % (len(daten["plugins"]),
        "Eintrag" if len(daten["plugins"]) == 1 else "Einträge",
        " · Sicherung: ID.json.bak" if sicherung else ""))
    einzel("geschrieben: %s" % verzeichnis)

    # 4. Einstellungen beim InDesign-Versionswechsel mitnehmen: die
    #    einstellungen.json liegt je Hauptversion getrennt (IDSN/21, IDSN/22 …) —
    #    nach einem Update schaute das Plugin sonst in einen leeren Ordner.
    if not entfernen and indesign and os.path.isdir(speicher):
        haupt = zahlen(indesign)[0]
        for p in plugins:
            neu = os.path.join(speicher, str(haupt), "External", p["id"], "PluginData", "einstellungen.json")
            if os.path.exists(neu):
                continue
            aeltere = [int(d) for d in os.listdir(speicher) if d.isdigit() and int(d) < haupt
                       and os.path.isfile(os.path.join(speicher, d, "External", p["id"], "PluginData", "einstellungen.json"))]
            if aeltere:
                alt_json = os.path.join(speicher, str(max(aeltere)), "External", p["id"], "PluginData", "einstellungen.json")
                os.makedirs(os.path.dirname(neu), exist_ok=True)
                shutil.copy2(alt_json, neu)
                gut("Einstellungen aus InDesign %d übernommen: %s" % (max(aeltere), p["id"]))
                einzel("kopiert: %s → %s" % (alt_json, neu))

    # 5. Beim Entfernen bleibt der Datenordner stehen — sagen, was bleibt;
    #    --entfernen-alles räumt auch ihn ab.
    if modus == "entfernen-alles":
        geleert = 0
        for kennung in [p["id"] for p in plugins] + alt_ids:
            for ordner in glob.glob(os.path.join(speicher, "*", "External", kennung)):
                shutil.rmtree(ordner, ignore_errors=True)
                einzel("entfernt: %s" % ordner)
                geleert += 1
        if geleert:
            gut("%d Datenordner (Einstellungen, Protokolle) entfernt" % geleert)
        else:
            hinweis("keine Datenordner vorhanden")
    elif entfernen:
        hinweis("Einstellungen und Protokolle bleiben erhalten (PluginsStorage) — --entfernen-alles räumt auch sie ab")

print()
for zeile in haken:
    print("  " + zeile)
sys.exit(1 if fehler else 0)
PY

echo
if [ "$FEHLER" != "0" ]; then
    echo "✗ Nicht alles in Ordnung — Einzelheiten stehen oben."
    exit "$FEHLER"
fi
if [ -z "${DWB_ELTERN:-}" ]; then
    if [ "$MODUS" = "pruefen" ]; then
        echo "Prüfung abgeschlossen — alles in Ordnung."
    elif [ "$MODUS" = "entfernen" ] || [ "$MODUS" = "entfernen-alles" ]; then
        echo "Fertig. InDesign neu starten, dann sind die Bedienfelder weg."
    else
        echo "Fertig. InDesign neu starten — danach unter"
        echo "Plug-ins ▸ Ansicht dwb, Export dwb und Prüfung dwb."
    fi
fi
