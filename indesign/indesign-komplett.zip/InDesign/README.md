# InDesign — Bedienfelder und Skripte

Alles, was hier liegt, erweitert Adobe InDesign 2026 (21.5.1) auf diesem Mac.
Zwei Sorten, weil InDesign zwei Wege kennt:

| | Was | Wo es danach auftaucht |
|---|---|---|
| **Bedienfelder** | drei UXP-Plugins (Ansicht, Export, Prüfung), andockbar wie InDesigns eigene Bedienfelder | **Plug-ins ▸ …** |
| **Skripte** | acht klassische JSX-Skripte, Doppelklick startet sie | **Fenster ▸ Hilfsprogramme ▸ Skripte ▸ Benutzer** |
| **Startskript** | hängt „Importoptionen ändern …“ fest ins Menü | **Objekt ▸ Importoptionen ändern …** |

---

## Installation — ein Befehl für alles

```bash
"/Users/danielbittner/Claude Code/InDesign/installieren.command"
```

Doppelklick auf die Datei tut dasselbe — sie fragt dann kurz, ob sie
einrichten, entfernen oder prüfen soll (Eingabetaste = Einrichten).
Eingerichtet wird dreierlei:

* kopiert die drei Bedienfelder dorthin, wo InDesign nach fremden Plugins
  sucht, und trägt sie in dessen Verzeichnisdatei ein;
* legt Verknüpfungen aller Skripte im Skriptbedienfeld an — in **jedem**
  Sprach- und Versionsordner, den InDesign auf dem Rechner angelegt hat;
* verknüpft das Startskript, das „Importoptionen ändern …“ fest ins Menü
  **Objekt** hängt (dort lässt sich unter Bearbeiten ▸ Tastaturbefehle auch ein
  Kürzel vergeben).

**Danach InDesign einmal neu starten.** Dann steht alles bereit:

    Plug-ins ▸ Ansicht dwb  ▸ Ansicht dwb
    Plug-ins ▸ Export dwb   ▸ Export dwb
    Plug-ins ▸ Prüfung dwb  ▸ Prüfung dwb
    Fenster ▸ Hilfsprogramme ▸ Skripte ▸ Benutzer ▸ Importoptionen.jsx · Zoom-Export.jsx
        · Typo-Putz.jsx · Aufraeumen.jsx · Version-sichern.jsx
        · Neues-Dokument.jsx · Kontaktabzug.jsx · Bilder-in-Rahmen.jsx
    Objekt ▸ Importoptionen ändern …

Am Ende steht eine kompakte Häkchen-Bilanz; die vollen Pfade zeigt erst
`--ausfuehrlich`. Läuft InDesign während der Installation, sagt der Installer
das deutlich an — vor dem Neustart wird nichts sichtbar. Alle Schalter:

| Schalter | Wirkung |
|---|---|
| `--entfernen` | nimmt alles wieder heraus — Einstellungen bleiben erhalten |
| `--entfernen-alles` | löscht auch Einstellungen und Selbsttest-Protokolle |
| `--pruefen` | prüft die Installation, ohne etwas zu ändern |
| `--ausfuehrlich` | zeigt jeden einzelnen Pfad statt nur der Bilanz |

Nach einer Änderung am Quelltext: denselben Befehl noch einmal, InDesign neu
starten. Ein Entwicklerwerkzeug von Adobe wird nicht gebraucht.

### Ohne Installer

Darf oder kann auf dem Rechner kein Skript laufen — gesperrter Firmen-Mac,
fremdes Notebook, blockierte PowerShell —, geht alles auch von Hand mit Finder
bzw. Explorer und einem Texteditor: **[Handinstallation.md](Handinstallation.md)**
führt Schritt für Schritt durch dieselben vier Handgriffe (Ordner kopieren,
`ID.json` ergänzen, Skripte ablegen, Startskript ablegen) und enthält den
fertigen JSON-Block zum Einsetzen.

### Windows

Bedienfelder und Skripte selbst sind plattformunabhängig — UXP und
ExtendScript laufen unter Windows genauso. Nur der Installer oben ist ein
macOS-Shellskript; für Windows liegt daneben:

```powershell
.\installieren.ps1
```

Rechtsklick ▸ *Mit PowerShell ausführen* genügt meist. Wehrt Windows sich,
hilft im PowerShell-Fenster:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\installieren.ps1
```

Wieder herausnehmen: `.\installieren.ps1 -Entfernen`

Die Windows-Fassung legt dieselben Dinge an, nur an den dortigen Orten:

| | macOS | Windows |
|---|---|---|
| Bedienfelder | `~/Library/Application Support/Adobe/UXP/Plugins/External/` | `%APPDATA%\Adobe\UXP\Plugins\External\` |
| Verzeichnisdatei | `…/UXP/PluginsInfo/v1/ID.json` | `%APPDATA%\Adobe\UXP\PluginsInfo\v1\ID.json` |
| Skripte | `~/Library/Preferences/Adobe InDesign/Version */*/Scripts/` | `%APPDATA%\Adobe\InDesign\Version *\*\Scripts\` |

**Ein Unterschied:** Unter macOS werden die beiden `.jsx` *verknüpft* — eine
Änderung am Quelltext wirkt sofort. Unter Windows werden sie **kopiert**
(Verknüpfungen brauchen dort Administratorrechte oder den Entwicklermodus).
Nach jeder Änderung also `installieren.ps1` erneut laufen lassen.

**Ungetestet:** Auf diesem Rechner gibt es kein Windows. Das PowerShell-Skript
ist sorgfältig geschrieben, aber nicht ausprobiert — beim ersten Lauf also auf
die Ausgabe schauen. Falls das Plugin nicht erscheint, verrät der Grund sich
im UXP-Log unter
`%LOCALAPPDATA%\Temp\` bzw. `%APPDATA%\..\Local\Adobe\...\UXPLogs_*.log`
(dieselbe Datei wie unter macOS, nur an anderer Stelle).

---

## Was drin ist

### Bedienfelder ▸ **Ansicht dwb**
Vier feste Zoomknöpfe — Seite (Alt-Klick: Druckbogen), 100 %, Objekt,
Montagefläche — dazu **beliebig viele eigene Stufen**, die du selbst anlegst,
benennst, sortierst und wieder löschst (Alt- oder Rechtsklick auf einen der
Knöpfe). Der Knopf **Hilfslinien …** legt Hilfslinien an genau eingetippten
Positionen an — horizontal wie vertikal, mehrere auf einmal, wahlweise für
alle Seiten; beim Öffnen zeigt das Fenster die vorhandenen Linien der Seite
(aktive Ebene) und übernimmt sie auf Wunsch in die Felder. Und der Knopf
**Importoptionen …**, der das gleichnamige Script aufruft.
Details: [Bedienfelder/README.md](Bedienfelder/README.md)

### Bedienfelder ▸ **Export dwb**
Beliebig viele selbst angelegte **PDF-Knöpfe** (ab Werk Print · Newspaper ·
Web) plus **JPG** und **PNG** — jeder Knopf ein fertiger Export ohne Dialog.
Zielordner, Dateiname mit Platzhaltern, Umfang, Farbraum und Größe stehen im
Fenster „Export einstellen“ — die Bildgröße wahlweise in ppi oder als
**Pixelmaß** (Breite/Höhe in Bildpunkten, der höhere Wunsch bestimmt die
Auflösung). Details: [Bedienfelder/README.md](Bedienfelder/README.md)

### Skripte ▸ **Importoptionen.jsx**
Ändert nachträglich, was InDesign sonst nur beim Platzieren fragt: PDF-Seite,
„Zuschneiden auf“, transparenter Hintergrund, PSD-Ebenen, Beschnittpfad — für
einen Rahmen, eine Auswahl oder das ganze Dokument.
Details: [Importoptionen/README.md](Importoptionen/README.md)

### Bedienfelder ▸ **Prüfung dwb**
Die Reinzeichnungs-Ampel: ein Klick prüft das Dokument auf Übersatztext,
fehlende und geänderte Verknüpfungen, RGB-Bilder, zu geringe Bildauflösung,
Haarlinien und Objekte, die nicht in den Anschnitt reichen. Jeder Fund ist
eine Zeile — ein Klick darauf wählt das Objekt aus und passt es ins Fenster
ein. Details: [Bedienfelder/README.md](Bedienfelder/README.md)

### Skripte ▸ **Zoom-Export.jsx**
Dieselben Zoom- und Exportfunktionen wie die Bedienfelder, aber als
schwebende Palette — die Rückfallebene für InDesign vor 18.5, wo es noch keine
UXP-Bedienfelder gab. Details: [Zoom-Export/README.md](Zoom-Export/README.md)

### Skripte ▸ **Werkzeuge/**
Sechs Alltagshelfer, jeder ein Doppelklick — Details:
[Werkzeuge/README.md](Werkzeuge/README.md)

* **Typo-Putz.jsx** — typografische Reinigung DE („…“ statt "…", Apostroph,
  Auslassungszeichen, Leerzeichenputz, schmale geschützte Leerzeichen vor
  Einheiten), jede Regel abwählbar, ein Rückgängig-Schritt, Bericht am Ende.
* **Aufraeumen.jsx** — unbenutzte Absatz-/Zeichenformate, Farbfelder und
  leere Ebenen finden; erst Bericht, dann Löschen auf Wunsch.
* **Version-sichern.jsx** — sichert und legt eine datierte Kopie in den
  Unterordner „Versionen“.
* **Neues-Dokument.jsx** — neues Dokument aus Vorlagen (Visitenkarte bis
  Plakat A1) mit Anschnitt, Rändern, Reichschwarz und Grundformaten.
* **Kontaktabzug.jsx** — alle Seiten als Miniaturen-Übersicht (A4 quer)
  als PDF neben der Dokumentdatei, für Freigaben per Mail.
* **Bilder-in-Rahmen.jsx** — markierten Rahmen mit vielen Bildern füllen: eine
  Seite je Bild (dahinter, am Dokumentende oder in vorhandene Folgeseiten),
  Übersicht mit Vorschau zum Umsortieren, ganze Ordner, Doppelte erkennen,
  PDF-Seiten, effektive ppi, Ausrichtung je Bild, Titel, Stadt, „Foto: Autor“
  (IPTC-Ersteller) und Bildunterschrift aus den Metadaten in gleichnamige
  Textrahmen — gleiche Texte einmal auf die Musterseite, vorhandenen Text
  lässt es auf Wunsch stehen —, Tastenkürzel.

---

## Aufbau

```
InDesign/
├── installieren.command      richtet alles ein (macOS)
├── installieren.ps1          dasselbe für Windows
├── README.md                 diese Übersicht
├── Handinstallation.md       alles von Hand, ohne Installer
│
├── Bedienfelder/             die drei UXP-Plugins
│   ├── installieren.command  nur die Bedienfelder
│   ├── README.md             Bedienung + alle technischen Fallstricke
│   ├── ansicht/              Ansicht dwb  (manifest, index.html, stil.css, index.js)
│   ├── export/               Export dwb
│   └── pruefung/             Prüfung dwb
│
├── Importoptionen/
│   ├── Importoptionen.jsx    die Palette
│   ├── Menue-Startup.jsx     hängt sie ins Menü Objekt (startup script)
│   └── README.md
│
├── Werkzeuge/                fünf Alltagshelfer als JSX
│   ├── Typo-Putz.jsx · Aufraeumen.jsx · Version-sichern.jsx
│   ├── Neues-Dokument.jsx · Kontaktabzug.jsx
│   └── README.md
│
└── Zoom-Export/
    ├── Zoom-Export.jsx
    └── README.md
```

---

## Wenn etwas nicht auftaucht

**Erster Griff: der Prüfmodus.** Er kontrolliert Plugin-Ordner,
Verzeichnisdatei und alle Verknüpfungen und durchsucht das jüngste UXP-Log
nach dwb-Fehlern — je Baustein ein Häkchen oder ein klarer Befund:

```bash
"/Users/danielbittner/Claude Code/InDesign/installieren.command" --pruefen
```

**Bedienfeld fehlt im Plug-ins-Menü.** InDesign sagt nicht, warum ein Plugin
nicht lädt — es steht im Log:

```bash
tail -50 ~/Library/Logs/Adobe/Adobe\ InDesign\ */UXPLogs_*.log | grep -i dwb
```

(Der Jahresordner unter `~/Library/Logs/Adobe/` wächst nicht mit der
InDesign-Version mit — deshalb der Stern.) Zur Kontrolle stehen alle drei
unter **Plug-ins ▸ Plug-ins verwalten** als *Ansicht dwb*, *Export dwb* und
*Prüfung dwb*, jeweils „enabled“.

**Skript fehlt im Skriptbedienfeld.** Die Verknüpfungen liegen in
`~/Library/Preferences/Adobe InDesign/Version */*/Scripts/Scripts Panel/`
(je InDesign-Version und Sprache ein Ordner). Nach einem
InDesign-Versionswechsel gibt es dort einen neuen Ordner — dann den Installer
noch einmal laufen lassen; er nimmt dabei auch die gesicherten Einstellungen
(`einstellungen.json`) aus dem alten Versionsordner mit.

**Alle Bedienfelder haben einen Selbsttest** im Bedienfeldmenü (das kleine
Symbol rechts oben im Bedienfeld). Er legt ein Testdokument an, probiert alles
durch und schreibt ein Protokoll in den Datenordner des Plugins:

```
~/Library/Application Support/Adobe/UXP/PluginsStorage/IDSN/<Versionsnummer>/External/de.dwb.export/PluginData/
```

Dort liegen auch die gesicherten Einstellungen (`einstellungen.json`).

---

**Stand:** 2026-09-13 · geprüft mit InDesign 21.5.1 (2026), macOS
