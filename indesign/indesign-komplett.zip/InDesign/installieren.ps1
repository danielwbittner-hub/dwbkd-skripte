# ============================================================================
#  Alles für InDesign einrichten — Windows
# ----------------------------------------------------------------------------
#  Gegenstück zu installieren.command (macOS). Richtet ein:
#    • die beiden Bedienfelder „Ansicht dwb“ und „Export dwb“ (UXP-Plugins)
#    • die beiden Skripte im Skriptbedienfeld
#    • das Startskript für den Menüeintrag „Importoptionen ändern …“
#
#  Aufruf (Rechtsklick ▸ „Mit PowerShell ausführen“ genügt meist). Blockt
#  Windows die Ausführung, hilft im PowerShell-Fenster:
#
#      Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
#      .\installieren.ps1
#
#  Wieder herausnehmen:   .\installieren.ps1 -Entfernen
#
#  Danach InDesign neu starten.
#
#  ACHTUNG: Anders als unter macOS werden die Skripte KOPIERT, nicht
#  verknüpft (Verknüpfungen brauchen unter Windows Administratorrechte oder
#  den Entwicklermodus). Nach jeder Änderung am Quelltext dieses Skript also
#  erneut laufen lassen.
# ============================================================================
param([switch]$Entfernen)

$ErrorActionPreference = "Stop"
$Hier = Split-Path -Parent $MyInvocation.MyCommand.Path

$PluginOrdner = Join-Path $env:APPDATA "Adobe\UXP\Plugins\External"
$Verzeichnis  = Join-Path $env:APPDATA "Adobe\UXP\PluginsInfo\v1\ID.json"
$AltIds       = @("de.dwbkd.ansicht", "de.dwbkd.export", "dwbkdtest")

function Zeile($text) { Write-Host $text }

Zeile "════════════════════════════════════════════════════════════"
Zeile "  Bedienfelder (UXP-Plugins)"
Zeile "════════════════════════════════════════════════════════════"

New-Item -ItemType Directory -Force -Path $PluginOrdner | Out-Null
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Verzeichnis) | Out-Null

# Angaben aus den Manifesten holen
$Plugins = @()
foreach ($unter in @("ansicht", "export", "pruefung")) {
    $manifest = Get-Content (Join-Path $Hier "Bedienfelder\$unter\manifest.json") -Raw -Encoding UTF8 | ConvertFrom-Json
    $Plugins += [pscustomobject]@{
        Quelle     = Join-Path $Hier "Bedienfelder\$unter"
        Id         = $manifest.id
        Name       = $manifest.name
        Version    = $manifest.version
        MinVersion = $manifest.host.minVersion
    }
}

# Alte Kennungen aufräumen — das Plugin hieß früher de.dwbkd.*
foreach ($aid in $AltIds) {
    Get-ChildItem -Path $PluginOrdner -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like "$aid`_*" } |
        ForEach-Object {
            Remove-Item $_.FullName -Recurse -Force
            Zeile "alte Fassung entfernt: $($_.Name)"
        }
}

foreach ($p in $Plugins) {
    $ziel = Join-Path $PluginOrdner ("{0}_{1}" -f $p.Id, $p.Version)
    if (Test-Path $ziel) { Remove-Item $ziel -Recurse -Force }
    if (-not $Entfernen) {
        Copy-Item $p.Quelle $ziel -Recurse
        Zeile "angelegt:  $ziel"
    } else {
        Zeile "entfernt:  $ziel"
    }
}

# Verzeichnisdatei ergänzen, fremde Einträge bleiben stehen
$daten = $null
if (Test-Path $Verzeichnis) {
    try { $daten = Get-Content $Verzeichnis -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $daten = $null }
}
$liste = @()
if ($daten -and $daten.plugins) { $liste = @($daten.plugins) }

$eigene = @($Plugins | ForEach-Object { $_.Id }) + $AltIds
$liste  = @($liste | Where-Object { $eigene -notcontains $_.pluginId })

if (-not $Entfernen) {
    foreach ($p in $Plugins) {
        $liste += [pscustomobject]@{
            hostMinVersion = $p.MinVersion
            name           = $p.Name
            path           = ('$localPlugins/External/{0}_{1}' -f $p.Id, $p.Version)
            pluginId       = $p.Id
            status         = "enabled"
            type           = "uxp"
            versionString  = $p.Version
        }
    }
}

# Ohne Byte-Order-Mark schreiben — sonst stolpert der Plugin-Lader darüber
$json = ([pscustomobject]@{ plugins = $liste } | ConvertTo-Json -Depth 6 -Compress)
[System.IO.File]::WriteAllText($Verzeichnis, $json, (New-Object System.Text.UTF8Encoding($false)))
Zeile "Verzeichnis: $Verzeichnis ($($liste.Count) Einträge)"

Zeile ""
Zeile "════════════════════════════════════════════════════════════"
Zeile "  Skripte im Skriptbedienfeld"
Zeile "════════════════════════════════════════════════════════════"

# InDesign legt je Version und Sprache einen eigenen Skriptordner an.
$Skripte = @(
    (Join-Path $Hier "Importoptionen\Importoptionen.jsx"),
    (Join-Path $Hier "Zoom-Export\Zoom-Export.jsx"),
    (Join-Path $Hier "Werkzeuge\Typo-Putz.jsx"),
    (Join-Path $Hier "Werkzeuge\Aufraeumen.jsx"),
    (Join-Path $Hier "Werkzeuge\Version-sichern.jsx"),
    (Join-Path $Hier "Werkzeuge\Neues-Dokument.jsx"),
    (Join-Path $Hier "Werkzeuge\Kontaktabzug.jsx"),
    (Join-Path $Hier "Werkzeuge\Bilder-in-Rahmen.jsx")
)
$Startskript = Join-Path $Hier "Importoptionen\Menue-Startup.jsx"

$Basis = Join-Path $env:APPDATA "Adobe\InDesign"
$gefunden = 0
if (Test-Path $Basis) {
    Get-ChildItem $Basis -Directory -Filter "Version *" | ForEach-Object {
        Get-ChildItem $_.FullName -Directory | ForEach-Object {
            $panel = Join-Path $_.FullName "Scripts\Scripts Panel"
            $start = Join-Path $_.FullName "Scripts\startup scripts"
            if (-not (Test-Path (Split-Path -Parent $panel))) { return }
            $gefunden = 1

            foreach ($skript in $Skripte) {
                $ziel = Join-Path $panel (Split-Path $skript -Leaf)
                if ($Entfernen) {
                    if (Test-Path $ziel) { Remove-Item $ziel -Force; Zeile "entfernt:  $ziel" }
                } else {
                    New-Item -ItemType Directory -Force -Path $panel | Out-Null
                    Copy-Item $skript $ziel -Force
                    Zeile "kopiert:   $ziel"
                }
            }

            $zielStart = Join-Path $start (Split-Path $Startskript -Leaf)
            if ($Entfernen) {
                if (Test-Path $zielStart) { Remove-Item $zielStart -Force; Zeile "entfernt:  $zielStart" }
            } else {
                New-Item -ItemType Directory -Force -Path $start | Out-Null
                Copy-Item $Startskript $zielStart -Force
                Zeile "kopiert:   $zielStart"
            }
        }
    }
}
if ($gefunden -eq 0) { Zeile "Kein Skriptordner gefunden. Lief InDesign auf diesem Rechner schon einmal?" }

Zeile ""
Zeile "════════════════════════════════════════════════════════════"
if ($Entfernen) {
    Zeile "  Fertig. InDesign neu starten — dann ist alles wieder weg."
} else {
    Zeile "  Fertig. InDesign neu starten. Danach:"
    Zeile ""
    Zeile "    Plug-ins > Ansicht dwb > Ansicht dwb"
    Zeile "    Plug-ins > Export dwb  > Export dwb"
    Zeile "    Fenster > Hilfsprogramme > Skripte > Benutzer"
    Zeile "        > Importoptionen.jsx, Zoom-Export.jsx"
    Zeile "        > Typo-Putz.jsx, Aufraeumen.jsx, Version-sichern.jsx"
    Zeile "        > Neues-Dokument.jsx, Kontaktabzug.jsx, Bilder-in-Rahmen.jsx"
    Zeile "    Objekt > Importoptionen aendern ...   (kommt vom Startskript)"
}
Zeile "════════════════════════════════════════════════════════════"
