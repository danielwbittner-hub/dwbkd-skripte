# Zoom & Export — ScriptUI-Palette (Rückfallebene)

Eine schwebende Palette mit denselben Funktionen wie die beiden Bedienfelder
in `../Bedienfelder/`, aber als klassisches Skript: vier Zoomknöpfe, drei
Exportknöpfe (PDF, JPG, PNG) und beliebig viele benannte Exportvorgaben.

**Gedacht für InDesign vor 18.5** — davor gab es keine UXP-Bedienfelder.
Ab InDesign 18.5 sind die Plugins die bessere Wahl: sie lassen sich andocken
und sind nach jedem Programmstart da.

**Stand:** 2026-08-29 · Version 1.0 · geprüft mit InDesign 21.5.1 (2026), macOS

---

## Start

Die Verknüpfung ins Skriptbedienfeld legt der Installer an — in jedem
Versions- und Sprachordner, den InDesign auf dem Rechner angelegt hat:

```bash
"/Users/danielbittner/Claude Code/InDesign/installieren.command"
```

Von Hand ginge auch eine Verknüpfung nach
`~/Library/Preferences/Adobe InDesign/Version <x>/<Sprache>/Scripts/Scripts Panel/`.
Dann Doppelklick:

    Fenster ▸ Hilfsprogramme ▸ Skripte ▸ Benutzer ▸ Zoom-Export.jsx

Die Palette darf offen bleiben, während weitergearbeitet wird — sie ist kein
modaler Dialog. Sie lebt bis zum Neustart von InDesign.

---

## Unterschied zu den Bedienfeldern

* **Eine Vorgabe je Export statt drei fester PDF-Knöpfe.** Oben steht eine
  Liste benannter Vorgaben („Druck“, „Zeitung“, „Web“ …), darunter die drei
  Formatknöpfe. Jede Vorgabe hält Ziel, Dateiname, Umfang und alle
  Formateinstellungen zusammen.
* **Alles in einer Palette** statt in zwei getrennten Bedienfeldern.
* Vorgaben liegen in
  `~/Library/Application Support/dwbkd/InDesign/zoom-export.json`.

Bedienung sonst wie bei den Bedienfeldern: Alt-Klick auf „Seite“ passt den
Druckbogen ein, Alt-Klick auf einen Exportknopf öffnet die Vorgaben beim
passenden Reiter. Die Platzhalter im Dateinamen heißen hier
`{dok} {vorgabe} {seite} {nr} {datum} {zeit} {format}`.

---

## Prüfung

```bash
python3 "../../PDF-UA/pruefe-jsx.py" Zoom-Export.jsx
```

Findet die ExtendScript-Falle, die Klick-Handler wortlos sterben lässt: eine
Variable, die benutzt wird, bevor ihr `var` steht.

Die technischen Fallstricke (Menü-ID 118790 fürs Einpassen der Auswahl,
`pngSuffix`, ungültige Seitenbereiche, absolute Seitenangaben) sind in
`../Bedienfelder/README.md` beschrieben — sie gelten hier genauso.
